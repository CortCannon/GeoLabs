@echo off
setlocal
cd /d "%~dp0"
echo WorldGeoLabs setup
where py >nul 2>nul
if errorlevel 1 (
  echo ERROR: Python launcher ^(py.exe^) was not found.
  echo Install Python 3.11 or newer, then run this file again.
  pause
  exit /b 1
)
if not exist ".venv\Scripts\python.exe" (
  echo Creating local Python environment...
  py -3 -m venv .venv
  if errorlevel 1 goto :fail
)
echo Installing/updating required packages...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :fail
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :fail
echo.
echo Setup complete. Run RUN_WORLDGEOLABS.bat.
pause
exit /b 0
:fail
echo.
echo Setup failed. Copy the error above and send it to ChatGPT.
pause
exit /b 1
