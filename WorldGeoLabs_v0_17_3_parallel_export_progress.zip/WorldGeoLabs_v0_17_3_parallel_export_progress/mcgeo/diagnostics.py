from __future__ import annotations

import argparse
import gzip
import importlib.util
import platform
import re
import sys
from pathlib import Path

from . import __version__
from .world.anvil_reader import AnvilWorld
from .world.nbt import read_nbt
from .world.region import RegionFile, probe_region_file
from .world.blockstates_decode import decode_blockstates, encode_blockstates
from .world.dimensions import discover_dimensions, resolve_dimension_storage
from .worldpainter.bridge import find_bridge_jar, find_wpscript
from .rendering.distant_horizons import (
    find_distant_horizons_database,
    inspect_distant_horizons_database,
    _list_selected_rows,
    _build_dh_tile_mesh,
)


def _status(ok: bool, label: str, detail: str = "") -> bool:
    mark = "PASS" if ok else "FAIL"
    tail = f" — {detail}" if detail else ""
    print(f"[{mark}] {label}{tail}")
    return ok


def _check_dependencies() -> bool:
    ok = True
    for module, label in (("numpy", "NumPy"), ("PySide6", "PySide6"), ("OpenGL", "PyOpenGL"), ("zstandard", "Zstandard (DH LOD)"), ("lz4", "LZ4 (DH LOD)")):
        found = importlib.util.find_spec(module) is not None
        ok &= _status(found, f"Dependency: {label}", "installed" if found else "missing; run SETUP_WORLDGEOLABS.bat")
    return ok


def _check_bitstorage() -> bool:
    indices = [(i * 7 + i // 11) % 31 for i in range(4096)]
    encoded = encode_blockstates(indices, 31)
    decoded = decode_blockstates(encoded, 31)
    return _status(decoded == indices, "Block-state encode/decode round trip", f"{len(encoded)} longs")


def _parse_region_coords(path: Path) -> tuple[int, int] | None:
    m = re.fullmatch(r"r\.(-?\d+)\.(-?\d+)\.mca", path.name)
    if not m:
        return None
    return int(m.group(1)), int(m.group(2))


def _check_world(world: Path) -> bool:
    world = world.expanduser().resolve()
    ok = _status(world.is_dir(), "Minecraft world folder", str(world))
    if not ok:
        return False
    try:
        storage = resolve_dimension_storage(world, "minecraft:overworld")
        region_dir = storage.region_dir
        ok &= _status(True, "Overworld region directory", f"{region_dir} [{storage.layout}]")
    except Exception as exc:
        region_dir = world / "region"
        ok &= _status(False, "Overworld region directory", str(exc))
    level = world / "level.dat"
    if level.is_file():
        try:
            root = read_nbt(gzip.decompress(level.read_bytes()))
            ok &= _status(root.tag_id == 10, "level.dat NBT", "readable")
        except Exception as exc:
            ok &= _status(False, "level.dat NBT", str(exc))
    else:
        ok &= _status(False, "level.dat NBT", "missing")
    dims = discover_dimensions(world)
    if dims:
        detail = ", ".join(f"{d.dimension_id}={d.region_relative_path}" for d in dims)
        ok &= _status(True, "Dimension discovery", detail)
    else:
        ok &= _status(False, "Dimension discovery", "no Anvil dimension region folders found")

    if not region_dir.is_dir():
        return bool(ok)

    regions = sorted(region_dir.glob("r.*.*.mca"))
    probes = [(rp, probe_region_file(rp)) for rp in regions]
    usable_regions = [(rp, pr) for rp, pr in probes if pr.usable]
    void_regions = [(rp, pr) for rp, pr in probes if pr.void]
    invalid_regions = [(rp, pr) for rp, pr in probes if not pr.usable and not pr.void]
    ok &= _status(bool(usable_regions), "Region files",
                  f"{len(usable_regions):,} usable; {len(void_regions):,} void ignored; {len(invalid_regions):,} invalid ignored")
    sample = None
    for rp, probe in usable_regions[:64]:
        coords = _parse_region_coords(rp)
        if coords is None:
            continue
        rx, rz = coords
        try:
            with RegionFile(rp) as reg:
                for x, z in probe.present_chunks:
                    raw = reg.read_chunk_nbt_bytes(x, z)
                    if raw is None:
                        continue
                    cx, cz = rx * 32 + x, rz * 32 + z
                    sample = AnvilWorld(world).decode_chunk_bytes(raw, cx, cz)
                    break
        except Exception:
            # A bad region is treated as void/unusable by GeoLabs rather than
            # making whole-world analysis fail.
            continue
        if sample is not None:
            break
    if sample is None:
        ok &= _status(False, "Sample chunk decode", "no readable chunk found in first 64 regions")
    else:
        ys = sorted(sample.sections)
        detail = f"chunk {sample.cx},{sample.cz}; {len(ys)} sections"
        if ys:
            detail += f"; section Y {ys[0]}..{ys[-1]}"
        ok &= _status(True, "Sample chunk decode", detail)

    # DH is optional, so absence is informational rather than a failed world diagnostic.
    try:
        db = find_distant_horizons_database(world, "minecraft:overworld")
        if db is None:
            _status(True, "Distant Horizons LOD", "not found (optional; GeoLabs surface fallback will be used)")
        else:
            # Use actual present chunk slots, not placeholder region filenames.
            chunk_coords = []
            for rp, probe in usable_regions:
                rc = _parse_region_coords(rp)
                if rc is None:
                    continue
                rx, rz = rc
                chunk_coords.extend((rx * 32 + lx, rz * 32 + lz) for lx, lz in probe.present_chunks)
            if chunk_coords:
                cb = (
                    min(c[0] for c in chunk_coords), max(c[0] for c in chunk_coords),
                    min(c[1] for c in chunk_coords), max(c[1] for c in chunk_coords),
                )
                info = inspect_distant_horizons_database(db, cb)
                detail = info.message + f"; {db}"
                dh_ok = _status(bool(info.compatible), "Distant Horizons LOD", detail)
                if info.compatible and info.selected_detail is not None:
                    try:
                        keys = _list_selected_rows(db, info.selected_detail, cb)
                        decoded = None
                        errors = []
                        # Test several real rows because incomplete edge tiles can legitimately
                        # be absent around the edge of a partially generated DH map.
                        world_min_y = min(sample.sections) * 16 if sample is not None and sample.sections else -64
                        for key in keys[:8]:
                            result = _build_dh_tile_mesh(
                                str(db), key.detail, key.pos_x, key.pos_z,
                                int(world_min_y), int(info.sample_stride),
                            )
                            if bool(result.get("ok")):
                                decoded = result
                                break
                            errors.append(str(result.get("err") or "unknown decode failure"))
                        if decoded is not None:
                            mesh = decoded.get("mesh")
                            verts = int(getattr(mesh, "vertex_count", 0)) if mesh is not None else 0
                            ok &= _status(True, "DH FullData sample decode", f"format {','.join(map(str, info.format_versions))}; {verts:,} vertices")
                        else:
                            err = errors[0] if errors else "no DH rows available to decode"
                            ok &= _status(False, "DH FullData sample decode", err)
                    except Exception as exc:
                        ok &= _status(False, "DH FullData sample decode", str(exc))
                elif not dh_ok:
                    ok = False
            else:
                _status(True, "Distant Horizons LOD", f"database found: {db}")
    except Exception as exc:
        _status(True, "Distant Horizons LOD", f"optional check skipped: {exc}")
    return bool(ok)


def _check_worldpainter() -> bool:
    wpscript = find_wpscript()
    jar = find_bridge_jar(Path.cwd())
    if wpscript:
        return _status(True, "WorldPainter bridge", f"wpscript: {wpscript}")
    if jar:
        return _status(True, "WorldPainter bridge", f"custom JAR: {jar}")
    return _status(False, "WorldPainter bridge", "not found; Minecraft-world editing still works without it")


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="WorldGeoLabs non-GUI diagnostics")
    parser.add_argument("--world", type=Path, help="Minecraft Java world folder to test")
    parser.add_argument("--no-deps", action="store_true", help="skip GUI dependency checks")
    args = parser.parse_args(argv)

    print(f"WorldGeoLabs diagnostics — {__version__}")
    print(f"Python {platform.python_version()} | {platform.system()} {platform.release()} | {platform.machine()}")
    print()
    checks = []
    checks.append(_status(sys.version_info >= (3, 10), "Python version", sys.version.split()[0]))
    if not args.no_deps:
        checks.append(_check_dependencies())
    checks.append(_check_bitstorage())
    checks.append(_check_worldpainter())
    if args.world:
        checks.append(_check_world(args.world))
    print()
    passed = all(checks)
    print("RESULT:", "PASS" if passed else "ATTENTION NEEDED")
    return 0 if passed else 2


if __name__ == "__main__":
    raise SystemExit(main())
