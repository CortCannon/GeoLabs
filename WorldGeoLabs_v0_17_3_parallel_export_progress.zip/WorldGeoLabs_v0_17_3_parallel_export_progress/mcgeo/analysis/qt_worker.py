from __future__ import annotations

from threading import Event
from PySide6 import QtCore

from .engine import AnalysisOptions, GeologicalAnalyzer, GeologicalAnalysisCancelled


class GeologicalAnalysisWorker(QtCore.QObject):
    progress = QtCore.Signal(int, str)
    finished = QtCore.Signal(object)
    failed = QtCore.Signal(str)
    cancelled = QtCore.Signal()

    def __init__(self, options: AnalysisOptions, cancel_event: Event) -> None:
        super().__init__()
        self.options = options
        self.cancel_event = cancel_event

    @QtCore.Slot()
    def run(self) -> None:
        try:
            analyzer = GeologicalAnalyzer(
                self.options,
                progress=lambda pct, msg: self.progress.emit(int(pct), str(msg)),
                cancelled=self.cancel_event.is_set,
            )
            report = analyzer.run()
        except GeologicalAnalysisCancelled:
            self.cancelled.emit()
        except Exception as exc:
            self.failed.emit(str(exc))
        else:
            self.finished.emit(report)
