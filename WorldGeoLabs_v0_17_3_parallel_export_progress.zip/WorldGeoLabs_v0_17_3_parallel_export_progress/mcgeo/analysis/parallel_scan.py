from __future__ import annotations

"""Process-pool helpers for whole-world geological verification.

This module deliberately avoids constructing full ``ChunkModel`` objects.  The
geology pass needs sparse columns plus per-section category histograms, not
4,096 Python block indices for every 16x16x16 section.  Workers therefore read
modern chunk NBT directly, keep packed block-state longs packed, and only
vectorise a 4,096-value palette-index array while calculating one section's
histogram.

The functions are module-level so Windows ``spawn`` multiprocessing can import
and execute them safely from the Qt analysis worker thread.
"""

from pathlib import Path
from typing import Any
import math
import sqlite3

import numpy as np

from .block_categories import BlockCategoryCatalog
from ..world.blockstates_decode import bits_needed
from ..world.nbt import read_nbt, TAG_Compound, TAG_List, TAG_Long_Array
from ..world.palette import is_air
from ..world.region import RegionFile, RegionError, probe_region_file


SECTION_SCHEMA = """
CREATE TABLE IF NOT EXISTS section_summary (
    cx INTEGER NOT NULL,
    sy INTEGER NOT NULL,
    cz INTEGER NOT NULL,
    dominant_category TEXT NOT NULL,
    air_fraction REAL NOT NULL,
    water_fraction REAL NOT NULL,
    lava_fraction REAL NOT NULL,
    ore_blocks INTEGER NOT NULL,
    protected_blocks INTEGER NOT NULL,
    block_count INTEGER NOT NULL,
    PRIMARY KEY (cx, sy, cz)
)
"""


def _sections_from_raw(raw: bytes, catalog: BlockCategoryCatalog) -> list[dict[str, Any]]:
    root = read_nbt(raw).value
    data = root.get("Level").value if "Level" in root and root["Level"].tag_id == TAG_Compound else root
    sections_tag = data.get("sections") or data.get("Sections")
    if not sections_tag or sections_tag.tag_id != TAG_List:
        return []
    _elem, sections_list = sections_tag.value
    out: list[dict[str, Any]] = []
    for sec_comp in sections_list:
        y_tag = sec_comp.get("Y") or sec_comp.get("y")
        if not y_tag:
            continue
        bs = sec_comp.get("block_states") or sec_comp.get("BlockStates")
        if not bs or bs.tag_id != TAG_Compound:
            continue
        bs_comp = bs.value
        pal_tag = bs_comp.get("palette") or bs_comp.get("Palette")
        if not pal_tag or pal_tag.tag_id != TAG_List:
            continue
        _pal_elem, pal_list = pal_tag.value
        palette: list[str] = []
        categories: list[str] = []
        for p in pal_list:
            name_tag = p.get("Name") if isinstance(p, dict) else None
            name = str(name_tag.value if name_tag else "minecraft:air")
            palette.append(name)
            categories.append(catalog.classify(name))
        data_tag = bs_comp.get("data") or bs_comp.get("Data")
        longs = tuple(data_tag.value) if data_tag and data_tag.tag_id == TAG_Long_Array else ()
        out.append({"sy": int(y_tag.value), "palette": palette, "categories": categories, "longs": longs})
    out.sort(key=lambda item: int(item["sy"]))
    return out


def _palette_index(section: dict[str, Any], block_index: int) -> int:
    palette_len = len(section["palette"])
    if palette_len <= 1:
        return 0
    bits = max(4, bits_needed(palette_len))
    vpl = 64 // bits
    long_index = int(block_index) // vpl
    slot = int(block_index) % vpl
    longs = section["longs"]
    if long_index < 0 or long_index >= len(longs):
        return 0
    value = int(longs[long_index]) & ((1 << 64) - 1)
    return int((value >> (slot * bits)) & ((1 << bits) - 1))


def _category_at(section_map: dict[int, dict[str, Any]], x: int, y: int, z: int) -> str:
    sec = section_map.get(int(y) // 16)
    if sec is None:
        return "air"
    ly = int(y) & 15
    idx = (ly * 16 + (int(z) & 15)) * 16 + (int(x) & 15)
    pi = _palette_index(sec, idx)
    categories = sec["categories"]
    if 0 <= pi < len(categories):
        return str(categories[pi])
    return "air"


def _surface_at(sections: list[dict[str, Any]], x: int, z: int) -> tuple[int, str]:
    for sec in reversed(sections):
        sy = int(sec["sy"])
        palette = sec["palette"]
        categories = sec["categories"]
        for ly in range(15, -1, -1):
            idx = (ly * 16 + (int(z) & 15)) * 16 + (int(x) & 15)
            pi = _palette_index(sec, idx)
            if pi < 0 or pi >= len(palette):
                continue
            name = str(palette[pi]).split("[", 1)[0]
            if not is_air(name):
                return sy * 16 + ly, str(categories[pi]) if pi < len(categories) else "unknown"
    return 0, "air"


def _palette_counts(section: dict[str, Any]) -> np.ndarray:
    palette_len = len(section["palette"])
    if palette_len <= 0:
        return np.zeros(0, dtype=np.int64)
    if palette_len == 1:
        return np.asarray([4096], dtype=np.int64)
    longs = section["longs"]
    if not longs:
        counts = np.zeros(palette_len, dtype=np.int64)
        counts[0] = 4096
        return counts
    bits = max(4, bits_needed(palette_len))
    vpl = 64 // bits
    mask = np.uint64((1 << bits) - 1)
    signed = np.asarray(longs, dtype=np.int64)
    values = signed.view(np.uint64)
    # Long-major/slot-minor layout matches Minecraft's fixed-width bit storage.
    decoded = np.empty((values.size, vpl), dtype=np.uint16 if bits <= 16 else np.uint32)
    for slot in range(vpl):
        decoded[:, slot] = ((values >> np.uint64(slot * bits)) & mask).astype(decoded.dtype, copy=False)
    flat = decoded.reshape(-1)[:4096]
    valid = flat[flat < palette_len]
    return np.bincount(valid.astype(np.int64, copy=False), minlength=palette_len).astype(np.int64, copy=False)


def _create_shard(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        path.unlink()
    con = sqlite3.connect(path)
    con.execute("PRAGMA journal_mode=OFF")
    con.execute("PRAGMA synchronous=OFF")
    con.execute("PRAGMA temp_store=MEMORY")
    con.execute(SECTION_SCHEMA)
    return con


def scan_region_batch(payload: dict[str, Any]) -> dict[str, Any]:
    """Scan one balanced region batch in a child process.

    Returns sparse surface/host samples via normal IPC and writes the potentially
    large per-section summary table into a worker-local SQLite shard for the
    parent to merge.  This keeps IPC bounded even on 2,500-block-tall worlds.
    """
    block_profile = Path(str(payload["block_profile"]))
    catalog = BlockCategoryCatalog.load(block_profile)
    category_to_index = dict(catalog.category_to_index)
    regions = list(payload.get("regions") or [])
    min_cx, max_cx, min_cz, max_cz = [int(v) for v in payload["bounds"]]
    min_x, max_x, min_z, max_z = [int(v) for v in payload["block_bounds"]]
    stride = max(1, int(payload["stride_chunks"]))
    step = max(1, int(payload["step"]))
    fill_height = bool(payload["fill_height"])
    shard_path = Path(str(payload["shard_path"]))

    cover_categories = {
        "organic_soil", "soil", "loose_sediment", "clay_mud",
        "ice_snow", "vegetation", "water",
    }
    rock_categories = {
        "sedimentary", "carbonate", "intrusive_igneous", "volcanic",
        "metamorphic_deep", "generic_rock",
        "ore_coal", "ore_iron", "ore_copper", "ore_gold",
        "ore_lapis", "ore_redstone", "ore_diamond", "ore_emerald",
    }
    ore_categories = {name for name in catalog.categories if name.startswith("ore_")}

    con = _create_shard(shard_path)
    section_rows: list[tuple[Any, ...]] = []
    samples: list[tuple[int, int, int, int, int, int, int, int]] = []
    sampled_chunks = 0
    sampled_sections = 0
    skipped_chunks = 0

    try:
        for record in regions:
            path = Path(str(record["path"]))
            rx = int(record["rx"])
            rz = int(record["rz"])
            probe = probe_region_file(path)
            if not probe.usable:
                continue
            present = set(probe.present_chunks)
            try:
                with RegionFile(path) as region:
                    for lz in range(32):
                        cz = rz * 32 + lz
                        if cz < min_cz or cz > max_cz or (cz - min_cz) % stride:
                            continue
                        for lx in range(32):
                            cx = rx * 32 + lx
                            if cx < min_cx or cx > max_cx or (cx - min_cx) % stride:
                                continue
                            if (lx, lz) not in present:
                                continue
                            try:
                                raw = region.read_chunk_nbt_bytes(lx, lz)
                                if raw is None:
                                    continue
                                sections = _sections_from_raw(raw, catalog)
                            except Exception:
                                skipped_chunks += 1
                                continue
                            if not sections:
                                continue
                            sampled_chunks += 1
                            section_map = {int(sec["sy"]): sec for sec in sections}
                            local_positions = list(range(0, 16, min(16, step))) if fill_height else [8]
                            for local_z in local_positions:
                                for local_x in local_positions:
                                    wx = cx * 16 + local_x
                                    wz = cz * 16 + local_z
                                    if not (min_x <= wx <= max_x and min_z <= wz <= max_z):
                                        continue
                                    top_y, top_cat = _surface_at(sections, local_x, local_z)
                                    cover = 0
                                    host: str | None = None
                                    for y in range(int(top_y), int(top_y) - 64, -1):
                                        category = _category_at(section_map, local_x, y, local_z)
                                        if category in cover_categories:
                                            cover += 1
                                            continue
                                        if category in rock_categories:
                                            host = category
                                            break
                                        if category == "air":
                                            continue
                                        break
                                    samples.append((
                                        int(cx), int(cz), int(local_x), int(local_z), int(top_y),
                                        int(category_to_index.get(top_cat, -1)), int(cover),
                                        int(category_to_index.get(host, -1) if host is not None else -1),
                                    ))

                            for sec in sections:
                                counts = _palette_counts(sec)
                                if counts.size <= 0:
                                    continue
                                category_counts: dict[str, int] = {}
                                protected_count = 0
                                ore_count = 0
                                for pi, count_value in enumerate(counts):
                                    count = int(count_value)
                                    if count <= 0 or pi >= len(sec["categories"]):
                                        continue
                                    category_id = str(sec["categories"][pi])
                                    category_counts[category_id] = category_counts.get(category_id, 0) + count
                                    category = catalog.category(category_id)
                                    if category.protected:
                                        protected_count += count
                                    if category_id in ore_categories:
                                        ore_count += count
                                if not category_counts:
                                    continue
                                dominant = max(category_counts.items(), key=lambda item: item[1])[0]
                                total_blocks = int(sum(category_counts.values()))
                                # Empty upper atmosphere sections add no geological value and
                                # can dominate SQLite size in custom-height worlds.
                                if dominant == "air" and category_counts.get("air", 0) >= int(total_blocks * 0.98) and ore_count == 0 and protected_count == 0:
                                    continue
                                section_rows.append((
                                    int(cx), int(sec["sy"]), int(cz), dominant,
                                    category_counts.get("air", 0) / total_blocks,
                                    category_counts.get("water", 0) / total_blocks,
                                    category_counts.get("lava", 0) / total_blocks,
                                    int(ore_count), int(protected_count), int(total_blocks),
                                ))
                                sampled_sections += 1
                                if len(section_rows) >= 4000:
                                    con.executemany(
                                        "INSERT OR REPLACE INTO section_summary "
                                        "(cx, sy, cz, dominant_category, air_fraction, water_fraction, lava_fraction, ore_blocks, protected_blocks, block_count) "
                                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                                        section_rows,
                                    )
                                    section_rows.clear()
            except (RegionError, OSError):
                continue
        if section_rows:
            con.executemany(
                "INSERT OR REPLACE INTO section_summary "
                "(cx, sy, cz, dominant_category, air_fraction, water_fraction, lava_fraction, ore_blocks, protected_blocks, block_count) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
                section_rows,
            )
        con.commit()
    finally:
        con.close()

    return {
        "shard_path": str(shard_path),
        "samples": samples,
        "sampled_chunks": int(sampled_chunks),
        "sampled_sections": int(sampled_sections),
        "skipped_chunks": int(skipped_chunks),
        "unknown_blocks": sorted(catalog.unknown_blocks),
        "region_count": int(len(regions)),
    }
