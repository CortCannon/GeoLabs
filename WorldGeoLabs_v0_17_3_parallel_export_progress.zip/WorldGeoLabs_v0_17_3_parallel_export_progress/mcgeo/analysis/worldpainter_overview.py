from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterator
import gzip
import io
import json
import struct
import zipfile


MAGIC = 0x57474C57


@dataclass(frozen=True)
class OverviewTile:
    tile_x: int
    tile_z: int
    sample_step: int
    samples_per_axis: int
    heights: tuple[float, ...]
    water_levels: tuple[int, ...]
    terrain_ids: tuple[int, ...]


class WorldPainterOverviewError(RuntimeError):
    pass


class PackageReader:
    def __init__(self, source: Path) -> None:
        self.source = Path(source)

    def read_bytes(self, relative: str) -> bytes:
        relative = relative.replace("\\", "/").lstrip("/")
        if self.source.is_dir():
            return (self.source / relative).read_bytes()
        if self.source.is_file() and self.source.suffix.lower() in {".zip", ".wglwp"}:
            with zipfile.ZipFile(self.source, "r") as archive:
                names = {name.replace("\\", "/"): name for name in archive.namelist()}
                actual = names.get(relative)
                if actual is None:
                    matches = [value for key, value in names.items() if key.endswith("/" + relative)]
                    if len(matches) == 1:
                        actual = matches[0]
                if actual is None:
                    raise FileNotFoundError(relative)
                return archive.read(actual)
        raise FileNotFoundError(relative)

    def read_json(self, relative: str) -> dict:
        return json.loads(self.read_bytes(relative).decode("utf-8"))


def iter_overview_tiles(package_path: Path, index_relative: str) -> Iterator[OverviewTile]:
    reader = PackageReader(package_path)
    index = reader.read_json(index_relative)
    for record in index.get("tiles") or []:
        raw = reader.read_bytes(str(record["path"]))
        try:
            data = gzip.decompress(raw)
        except OSError:
            data = raw
        stream = io.BytesIO(data)
        header = stream.read(24)
        if len(header) != 24:
            raise WorldPainterOverviewError("Truncated WorldPainter overview tile")
        magic, version, tile_x, tile_z, sample_step, samples_per_axis = struct.unpack(">6i", header)
        if magic != MAGIC or version != 1:
            raise WorldPainterOverviewError(
                f"Unsupported WorldPainter overview tile header: magic={magic:#x} version={version}"
            )
        count = samples_per_axis * samples_per_axis
        heights: list[float] = []
        water: list[int] = []
        terrains: list[int] = []
        for _ in range(count):
            record_bytes = stream.read(10)
            if len(record_bytes) != 10:
                raise WorldPainterOverviewError("Truncated WorldPainter overview record")
            height, water_level, terrain_id = struct.unpack(">fih", record_bytes)
            heights.append(float(height))
            water.append(int(water_level))
            terrains.append(int(terrain_id))
        yield OverviewTile(
            tile_x=tile_x,
            tile_z=tile_z,
            sample_step=sample_step,
            samples_per_axis=samples_per_axis,
            heights=tuple(heights),
            water_levels=tuple(water),
            terrain_ids=tuple(terrains),
        )
