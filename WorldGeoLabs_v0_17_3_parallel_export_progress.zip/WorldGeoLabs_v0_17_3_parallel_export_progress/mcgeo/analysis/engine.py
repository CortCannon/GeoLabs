from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable
import concurrent.futures as cf
import math
import multiprocessing as mp
import os
import sqlite3
import time

import numpy as np

from .block_categories import BlockCategoryCatalog
from .cache import AnalysisCache
from .worldpainter_overview import PackageReader, iter_overview_tiles
from .worldpainter_mapping import load_or_create_worldpainter_mapping
from .parallel_scan import SECTION_SCHEMA, scan_region_batch
from ..world.region import probe_region_file
from ..world.dimensions import resolve_dimension_storage
from ..geology.profile import WorldGeologyProfile
from ..geology.world_model import build_world_geology_fields


ProgressCallback = Callable[[int, str], None]
CancelCallback = Callable[[], bool]


@dataclass(frozen=True)
class AnalysisOptions:
    world_path: Path
    chunk_bounds: tuple[int, int, int, int]
    height_range: tuple[int, int]
    scope_name: str = "full_world"
    requested_step: int = 8
    verification_step: int = 32
    source_mode: str = "auto"
    worldpainter_package: Path | None = None
    block_profile: Path | None = None
    geology_profile: Path | None = None
    force_rebuild: bool = False
    workers: int = 0  # 0 = all logical CPUs


@dataclass(frozen=True)
class AnalysisReport:
    manifest_path: Path
    cache_dir: Path
    reused_cache: bool
    effective_step: int
    grid_shape: tuple[int, int]
    source_summary: str
    sampled_chunks: int
    sampled_sections: int
    unknown_blocks: int
    elapsed_seconds: float
    summary: dict[str, Any]


class GeologicalAnalysisCancelled(RuntimeError):
    pass


class GeologicalAnalyzer:
    def __init__(
        self,
        options: AnalysisOptions,
        *,
        progress: ProgressCallback | None = None,
        cancelled: CancelCallback | None = None,
    ) -> None:
        self.options = options
        self.progress = progress or (lambda _pct, _message: None)
        self.cancelled = cancelled or (lambda: False)
        app_root = Path(__file__).resolve().parents[2]
        self.block_profile = Path(
            options.block_profile
            or app_root / "config" / "geology" / "minecraft_26_2_block_categories.toml"
        )
        self.catalog = BlockCategoryCatalog.load(self.block_profile)
        self.geology_profile_path = Path(
            options.geology_profile
            or app_root / "config" / "geology" / "world_geology_profile.toml"
        )
        self.geology_profile = WorldGeologyProfile.load(self.geology_profile_path)

    def _check_cancel(self) -> None:
        if self.cancelled():
            raise GeologicalAnalysisCancelled("Geological analysis cancelled")

    def _emit(self, percent: int, message: str) -> None:
        self._check_cancel()
        self.progress(max(0, min(100, int(percent))), str(message))

    @staticmethod
    def _world_fingerprint(world_path: Path) -> dict[str, Any]:
        world_path = Path(world_path)
        level = world_path / "level.dat"
        try:
            storage = resolve_dimension_storage(world_path, "minecraft:overworld")
            region_dir = storage.region_dir
            layout = storage.layout
        except FileNotFoundError:
            region_dir = world_path / "region"
            layout = "missing"
        all_region_files = list(region_dir.glob("r.*.*.mca")) if region_dir.is_dir() else []
        usable_probes = [probe_region_file(p) for p in all_region_files]
        usable = [pr for pr in usable_probes if pr.usable]
        return {
            "path": str(world_path.resolve()),
            "level_size": level.stat().st_size if level.exists() else 0,
            "level_mtime": level.stat().st_mtime_ns if level.exists() else 0,
            "region_count": len(usable),
            "region_bytes": sum(pr.size_bytes for pr in usable),
            "region_latest_mtime": max((pr.path.stat().st_mtime_ns for pr in usable), default=0),
            "void_region_count": sum(1 for pr in usable_probes if pr.void),
            "invalid_region_count": sum(1 for pr in usable_probes if not pr.usable and not pr.void),
            "present_chunk_count": sum(len(pr.present_chunks) for pr in usable),
            "dimension_region": str(region_dir.relative_to(world_path)) if region_dir.is_absolute() and region_dir.is_relative_to(world_path) else str(region_dir),
            "storage_layout": layout,
        }

    @staticmethod
    def _file_fingerprint(path: Path | None) -> dict[str, Any] | None:
        if path is None:
            return None
        path = Path(path)
        if not path.exists():
            return {"path": str(path), "missing": True}
        if path.is_dir():
            manifest = path / "world_info.json"
            stat_path = manifest if manifest.exists() else path
        else:
            stat_path = path
        stat = stat_path.stat()
        return {
            "path": str(path.resolve()),
            "size": stat.st_size,
            "mtime": stat.st_mtime_ns,
        }

    def _worldpainter_info(self) -> tuple[dict[str, Any] | None, dict[str, Any] | None, int | None]:
        package = self.options.worldpainter_package
        if package is None or not Path(package).exists():
            return None, None, None
        reader = PackageReader(Path(package))
        info = reader.read_json("world_info.json")
        dimensions = info.get("dimensions") or []
        dimension = None
        for candidate in dimensions:
            if str(candidate.get("anchor")) == "minecraft:overworld":
                dimension = candidate
                break
        if dimension is None and dimensions:
            dimension = dimensions[0]
        if not isinstance(dimension, dict):
            return info, None, None
        datasets = dict(dimension.get("datasets") or {})
        index_rel = datasets.get("overview") or datasets.get("height")
        source_step = None
        if index_rel:
            try:
                index = reader.read_json(str(index_rel))
                source_step = int(index.get("sample_step") or 0) or None
            except Exception:
                source_step = None
        return info, dimension, source_step

    def run(self) -> AnalysisReport:
        started = time.monotonic()
        self._emit(0, "Preparing geological analysis…")

        wp_info, wp_dimension, wp_step = self._worldpainter_info()
        use_wp = (
            self.options.source_mode in {"auto", "worldpainter"}
            and wp_dimension is not None
            and self.options.worldpainter_package is not None
        )
        if self.options.source_mode == "worldpainter" and not use_wp:
            raise RuntimeError("WorldPainter analysis was requested, but no overview dataset is available.")

        requested_step = max(1, int(self.options.requested_step))
        effective_step = max(requested_step, int(wp_step or 0)) if use_wp else requested_step

        min_cx, max_cx, min_cz, max_cz = (int(v) for v in self.options.chunk_bounds)
        min_x, max_x = min_cx * 16, (max_cx + 1) * 16 - 1
        min_z, max_z = min_cz * 16, (max_cz + 1) * 16 - 1
        width = ((max_x - min_x) // effective_step) + 1
        height = ((max_z - min_z) // effective_step) + 1
        if width <= 0 or height <= 0:
            raise RuntimeError("Invalid analysis bounds")

        cache_payload = {
            "world": self._world_fingerprint(self.options.world_path),
            "worldpainter": self._file_fingerprint(self.options.worldpainter_package),
            "bounds": [min_cx, max_cx, min_cz, max_cz],
            "height_range": list(self.options.height_range),
            "step": effective_step,
            "verification_step": int(self.options.verification_step),
            "source_mode": self.options.source_mode,
            "block_profile": self.catalog.fingerprint(),
            "geology_profile": self.geology_profile.fingerprint(),
            "engine_version": 4,
        }
        cache_key = AnalysisCache.make_key(cache_payload)
        cache_root = Path(self.options.world_path) / ".worldgeolabs" / "analysis"
        cache = AnalysisCache(cache_root, cache_key)
        existing = cache.load_manifest()
        if existing and existing.get("complete") and not self.options.force_rebuild:
            self._emit(100, "Using cached geological analysis.")
            summary = dict(existing.get("summary") or {})
            return AnalysisReport(
                manifest_path=cache.manifest_path,
                cache_dir=cache.root,
                reused_cache=True,
                effective_step=int(existing.get("effective_step", effective_step)),
                grid_shape=tuple(existing.get("grid_shape") or [height, width]),
                source_summary=str(existing.get("source_summary") or "Cached"),
                sampled_chunks=int(summary.get("sampled_chunks", 0)),
                sampled_sections=int(summary.get("sampled_sections", 0)),
                unknown_blocks=int(summary.get("unknown_blocks", 0)),
                elapsed_seconds=time.monotonic() - started,
                summary=summary,
            )

        shape = (height, width)
        surface_height = cache.create_array("surface_height", shape, "float32", fill=np.nan, nodata="nan")
        water_level = cache.create_array("water_level", shape, "int16", fill=-32768, nodata=-32768)
        wp_terrain = cache.create_array("worldpainter_terrain", shape, "int16", fill=-1, nodata=-1)
        wp_category = cache.create_array("worldpainter_category", shape, "int16", fill=-1, nodata=-1)
        surface_category = cache.create_array("surface_category", shape, "int16", fill=-1, nodata=-1)
        soil_depth = cache.create_array("soil_depth", shape, "int16", fill=-1, nodata=-1)
        host_category = cache.create_array("host_category", shape, "int16", fill=-1, nodata=-1)
        minecraft_presence = cache.create_array("minecraft_presence", shape, "uint8", fill=0, nodata=0)
        presence_summary = self._fill_minecraft_presence(
            bounds=(min_cx, max_cx, min_cz, max_cz),
            block_bounds=(min_x, max_x, min_z, max_z),
            step=effective_step,
            target=minecraft_presence,
        )

        source_parts: list[str] = []
        mapping_path: Path | None = None
        if use_wp:
            self._emit(4, "Reading WorldPainter height, water, and terrain tiles…")
            self._fill_worldpainter(
                package=Path(self.options.worldpainter_package),
                dimension=wp_dimension,
                bounds=(min_x, max_x, min_z, max_z),
                step=effective_step,
                arrays=(surface_height, water_level, wp_terrain),
            )
            mapping, mapping_path = load_or_create_worldpainter_mapping(
                package_path=Path(self.options.worldpainter_package),
                config_path=(
                    Path(self.options.world_path)
                    / ".worldgeolabs"
                    / "config"
                    / "worldpainter_terrain_mapping.toml"
                ),
                catalog=self.catalog,
            )
            for terrain_id, category_id in mapping.items():
                category_index = self.catalog.category_to_index.get(category_id, -1)
                if category_index >= 0:
                    wp_category[np.asarray(wp_terrain) == int(terrain_id)] = np.int16(category_index)
            wp_category.flush()
            source_parts.append(f"WorldPainter overview ({effective_step}-block grid)")

        sampled_chunks = 0
        sampled_sections = 0
        section_db = cache.root / "sections.sqlite"
        if self.options.source_mode != "worldpainter":
            self._emit(30 if use_wp else 5, "Sampling Minecraft blocks and 16×16×16 sections…")
            sampled_chunks, sampled_sections = self._scan_minecraft(
                bounds=(min_cx, max_cx, min_cz, max_cz),
                block_bounds=(min_x, max_x, min_z, max_z),
                step=effective_step,
                fill_height=not use_wp,
                arrays=(surface_height, water_level, surface_category, soil_depth, host_category),
                section_db=section_db,
                progress_start=30 if use_wp else 5,
                progress_end=62,
            )
            source_parts.append(
                f"Minecraft Anvil verification ({max(16, int(self.options.verification_step))}-block spacing)"
            )

        # Clip *all* analysis inputs to chunks that physically exist in the
        # Minecraft world. WorldPainter may contain design tiles beyond the
        # exported terrain, and 26.x exports can leave zero-byte .mca border
        # placeholders. Those void areas must not influence geology/resources.
        present_mask = np.asarray(minecraft_presence) > 0
        surface_height[~present_mask] = np.nan
        water_level[~present_mask] = np.int16(-32768)
        wp_terrain[~present_mask] = np.int16(-1)
        wp_category[~present_mask] = np.int16(-1)
        surface_category[~present_mask] = np.int16(-1)
        soil_depth[~present_mask] = np.int16(-1)
        host_category[~present_mask] = np.int16(-1)
        for arr in (surface_height, water_level, wp_terrain, wp_category, surface_category, soil_depth, host_category, minecraft_presence):
            arr.flush()

        self._emit(62, "Combining WorldPainter terrain and Minecraft host-rock evidence…")
        geology_category = cache.create_array("geology_category", shape, "int16", fill=-1, nodata=-1)
        geology_category[...] = np.asarray(wp_category)
        surface_values_for_merge = np.asarray(surface_category)
        host_values_for_merge = np.asarray(host_category)
        surface_mask = surface_values_for_merge >= 0
        geology_category[surface_mask] = surface_values_for_merge[surface_mask]
        host_mask = host_values_for_merge >= 0
        geology_category[host_mask] = host_values_for_merge[host_mask]
        geology_category.flush()

        valid = np.isfinite(np.asarray(surface_height))
        if not np.any(valid):
            raise RuntimeError("Analysis found no surface-height samples in the selected bounds.")

        self._emit(64, "Calculating slope, aspect, and terrain form…")
        slope, aspect = self._derive_slope(surface_height, effective_step)
        slope_out = cache.create_array("slope_degrees", shape, "float32", fill=np.nan, nodata="nan")
        aspect_out = cache.create_array("aspect_degrees", shape, "float32", fill=np.nan, nodata="nan")
        slope_out[...] = slope
        aspect_out[...] = aspect
        slope_out.flush()
        aspect_out.flush()

        self._emit(72, "Calculating drainage direction and flow accumulation…")
        flow_direction, flow_accumulation = self._derive_hydrology(surface_height)
        flow_dir_out = cache.create_array("flow_direction", shape, "int8", fill=-1, nodata=-1)
        flow_acc_out = cache.create_array("flow_accumulation", shape, "float32", fill=0.0, nodata=0.0)
        flow_dir_out[...] = flow_direction
        flow_acc_out[...] = flow_accumulation
        flow_dir_out.flush()
        flow_acc_out.flush()

        self._emit(86, "Interpreting uplift, basins, folds, faults, erosion, and paleo-environments…")
        structural_summary = build_world_geology_fields(
            cache=cache,
            surface_height=surface_height,
            slope_degrees=slope_out,
            flow_accumulation=flow_acc_out,
            water_level=water_level,
            geology_category=geology_category,
            categories=self.catalog.serializable_categories(),
            effective_step=effective_step,
            origin=(min_x, min_z),
            profile=self.geology_profile,
        )

        self._emit(94, "Writing geological analysis report…")
        for array in (
            surface_height, water_level, wp_terrain, wp_category, surface_category,
            soil_depth, host_category, geology_category, minecraft_presence,
        ):
            array.flush()

        category_counts: dict[str, int] = {}
        surface_values = np.asarray(geology_category)
        for index, category_id in self.catalog.index_to_category.items():
            count = int(np.count_nonzero(surface_values == index))
            if count:
                category_counts[category_id] = count

        finite_heights = np.asarray(surface_height)[valid]
        finite_slopes = np.asarray(slope)[np.isfinite(slope)]
        summary = {
            "sampled_chunks": sampled_chunks,
            "sampled_sections": sampled_sections,
            "unknown_blocks": len(self.catalog.unknown_blocks),
            "surface_sample_count": int(valid.sum()),
            "height_min": float(np.nanmin(finite_heights)),
            "height_max": float(np.nanmax(finite_heights)),
            "height_mean": float(np.nanmean(finite_heights)),
            "slope_mean_degrees": float(np.nanmean(finite_slopes)) if finite_slopes.size else 0.0,
            "slope_max_degrees": float(np.nanmax(finite_slopes)) if finite_slopes.size else 0.0,
            "surface_category_counts": category_counts,
            "section_database": str(section_db.name) if section_db.exists() else "",
            "structural_model": structural_summary,
            "minecraft_presence": presence_summary,
            "void_cells_ignored": int(np.count_nonzero(~present_mask)),
            "present_cells": int(np.count_nonzero(present_mask)),
        }
        self.catalog.write_unknown_report(cache.root / "unknown_blocks.json")

        source_summary = " + ".join(source_parts) or "Unknown source"
        manifest_payload = {
            "cache_key": cache_key,
            "world_path": str(Path(self.options.world_path).resolve()),
            "worldpainter_package": (
                str(Path(self.options.worldpainter_package).resolve())
                if self.options.worldpainter_package else ""
            ),
            "source_summary": source_summary,
            "chunk_bounds": [min_cx, max_cx, min_cz, max_cz],
            "block_bounds": [min_x, max_x, min_z, max_z],
            "height_range": list(self.options.height_range),
            "origin": [min_x, min_z],
            "effective_step": effective_step,
            "verification_step": int(self.options.verification_step),
            "grid_shape": [height, width],
            "categories": self.catalog.serializable_categories(),
            "block_profile": str(self.block_profile),
            "geology_profile": str(self.geology_profile_path),
            "geology_profile_id": self.geology_profile.profile_id,
            "geology_profile_fingerprint": self.geology_profile.fingerprint(),
            "resource_deposits": self.geology_profile.serializable_deposits(),
            "worldpainter_terrain_mapping": str(mapping_path or ""),
            "summary": summary,
        }
        manifest = cache.write_manifest(manifest_payload, complete=True)
        self._emit(100, "Geological analysis complete.")

        return AnalysisReport(
            manifest_path=manifest,
            cache_dir=cache.root,
            reused_cache=False,
            effective_step=effective_step,
            grid_shape=shape,
            source_summary=source_summary,
            sampled_chunks=sampled_chunks,
            sampled_sections=sampled_sections,
            unknown_blocks=len(self.catalog.unknown_blocks),
            elapsed_seconds=time.monotonic() - started,
            summary=summary,
        )

    def _fill_minecraft_presence(
        self,
        *,
        bounds: tuple[int, int, int, int],
        block_bounds: tuple[int, int, int, int],
        step: int,
        target: np.memmap,
    ) -> dict[str, int]:
        """Rasterize real Anvil chunk presence onto the analysis grid.

        This is header-only and deliberately treats zero-byte/short/header-only
        region files as void.  It also masks absent chunk slots inside otherwise
        valid region files, so geological generation never paints outside the
        exported Minecraft terrain.
        """
        min_cx, max_cx, min_cz, max_cz = [int(v) for v in bounds]
        min_x, max_x, min_z, max_z = [int(v) for v in block_bounds]
        step = max(1, int(step))
        storage = resolve_dimension_storage(Path(self.options.world_path), "minecraft:overworld")
        region_dir = storage.region_dir
        usable_regions = void_regions = invalid_regions = present_chunks = 0
        target[...] = 0
        for p in region_dir.glob("r.*.*.mca"):
            parts = p.name.split('.')
            if len(parts) != 4:
                continue
            try:
                rx, rz = int(parts[1]), int(parts[2])
            except ValueError:
                continue
            probe = probe_region_file(p)
            if not probe.usable:
                if probe.void:
                    void_regions += 1
                else:
                    invalid_regions += 1
                continue
            usable_regions += 1
            for lx, lz in probe.present_chunks:
                cx = rx * 32 + int(lx)
                cz = rz * 32 + int(lz)
                if cx < min_cx or cx > max_cx or cz < min_cz or cz > max_cz:
                    continue
                present_chunks += 1
                x0, x1 = cx * 16, cx * 16 + 15
                z0, z1 = cz * 16, cz * 16 + 15
                c0 = max(0, (x0 - min_x) // step)
                c1 = min(target.shape[1] - 1, (x1 - min_x) // step)
                r0 = max(0, (z0 - min_z) // step)
                r1 = min(target.shape[0] - 1, (z1 - min_z) // step)
                if c1 >= c0 and r1 >= r0:
                    target[r0:r1+1, c0:c1+1] = 1
        target.flush()
        return {
            "usable_regions": int(usable_regions),
            "void_regions_ignored": int(void_regions),
            "invalid_regions_ignored": int(invalid_regions),
            "present_chunks": int(present_chunks),
        }

    def _fill_worldpainter(
        self,
        *,
        package: Path,
        dimension: dict[str, Any],
        bounds: tuple[int, int, int, int],
        step: int,
        arrays: tuple[np.memmap, np.memmap, np.memmap],
    ) -> None:
        """Fill WorldPainter overview rasters using vectorised tile copies.

        The old implementation visited every sample in nested Python loops. On a
        16k world that kept one core busy for millions of iterations before the
        Minecraft verification stage even began.  The tile payload is already a
        regular raster, so NumPy can select/copy the aligned samples in bulk.
        """
        surface_height, water_level, terrain = arrays
        datasets = dict(dimension.get("datasets") or {})
        index_relative = datasets.get("overview") or datasets.get("height")
        if not index_relative:
            raise RuntimeError("The WorldPainter package has no overview dataset.")
        min_x, max_x, min_z, max_z = [int(v) for v in bounds]
        step = max(1, int(step))
        reader = PackageReader(package)
        index_document = reader.read_json(str(index_relative))
        total = max(1, len(index_document.get("tiles") or []))
        for tile_number, tile in enumerate(iter_overview_tiles(package, str(index_relative)), 1):
            self._check_cancel()
            n = int(tile.samples_per_axis)
            source_step = int(tile.sample_step)
            x_world = tile.tile_x * 128 + np.arange(n, dtype=np.int64) * source_step
            z_world = tile.tile_z * 128 + np.arange(n, dtype=np.int64) * source_step
            x_mask = (x_world >= min_x) & (x_world <= max_x) & (((x_world - min_x) % step) == 0)
            z_mask = (z_world >= min_z) & (z_world <= max_z) & (((z_world - min_z) % step) == 0)
            x_src = np.flatnonzero(x_mask)
            z_src = np.flatnonzero(z_mask)
            if x_src.size and z_src.size:
                x_dst = ((x_world[x_src] - min_x) // step).astype(np.int64)
                z_dst = ((z_world[z_src] - min_z) // step).astype(np.int64)
                valid_x = (x_dst >= 0) & (x_dst < surface_height.shape[1])
                valid_z = (z_dst >= 0) & (z_dst < surface_height.shape[0])
                x_src, x_dst = x_src[valid_x], x_dst[valid_x]
                z_src, z_dst = z_src[valid_z], z_dst[valid_z]
                if x_src.size and z_src.size:
                    h = np.asarray(tile.heights, dtype=np.float32).reshape(n, n)
                    w = np.asarray(tile.water_levels, dtype=np.int32).reshape(n, n)
                    t = np.asarray(tile.terrain_ids, dtype=np.int32).reshape(n, n)
                    src_ix = np.ix_(z_src, x_src)
                    dst_ix = np.ix_(z_dst, x_dst)
                    surface_height[dst_ix] = h[src_ix]
                    water_level[dst_ix] = np.clip(w[src_ix], -32767, 32767).astype(np.int16)
                    terrain[dst_ix] = np.clip(t[src_ix], -32768, 32767).astype(np.int16)
            if tile_number == total or tile_number % 64 == 0:
                pct = 4 + int(24 * tile_number / total)
                self._emit(pct, f"WorldPainter overview: {tile_number:,}/{total:,} tiles (vectorised)")
        surface_height.flush()
        water_level.flush()
        terrain.flush()

    def _scan_minecraft(
        self,
        *,
        bounds: tuple[int, int, int, int],
        block_bounds: tuple[int, int, int, int],
        step: int,
        fill_height: bool,
        arrays: tuple[np.memmap, np.memmap, np.memmap, np.memmap, np.memmap],
        section_db: Path,
        progress_start: int,
        progress_end: int,
    ) -> tuple[int, int]:
        """Parallel Minecraft verification using balanced region batches.

        CPU-heavy NBT parsing, packed block-state histogramming and sparse host
        sampling run in child processes.  Workers write section summaries to
        private SQLite shards; the GUI process only merges completed shards and
        applies compact surface samples to the memmaps.
        """
        surface_height, water_level, surface_category, soil_depth, host_category = arrays
        min_cx, max_cx, min_cz, max_cz = [int(v) for v in bounds]
        min_x, max_x, min_z, max_z = [int(v) for v in block_bounds]
        verification_step = max(16, int(self.options.verification_step))
        stride_chunks = max(1, verification_step // 16)
        estimated = (((max_cx - min_cx) // stride_chunks + 1) * ((max_cz - min_cz) // stride_chunks + 1))

        requested_workers = int(getattr(self.options, "workers", 0) or 0)
        workers = max(1, requested_workers or (os.cpu_count() or 4))
        storage = resolve_dimension_storage(Path(self.options.world_path), "minecraft:overworld")
        region_specs: list[dict[str, Any]] = []
        for p in storage.region_dir.glob("r.*.*.mca"):
            parts = p.name.split('.')
            if len(parts) != 4:
                continue
            try:
                rx, rz = int(parts[1]), int(parts[2])
            except ValueError:
                continue
            if rx * 32 + 31 < min_cx or rx * 32 > max_cx or rz * 32 + 31 < min_cz or rz * 32 > max_cz:
                continue
            probe = probe_region_file(p)
            if probe.usable:
                region_specs.append({"path": str(p), "rx": rx, "rz": rz})
        if not region_specs:
            for array in arrays:
                array.flush()
            return 0, 0

        workers = min(workers, len(region_specs))
        # Two jobs per worker gives good load balancing without creating hundreds
        # of SQLite shards on large worlds.
        job_count = min(len(region_specs), max(workers, workers * 2))
        batches: list[list[dict[str, Any]]] = [[] for _ in range(job_count)]
        # Balance by round-robin after sorting by file size (large regions spread out).
        region_specs.sort(key=lambda r: Path(r["path"]).stat().st_size if Path(r["path"]).exists() else 0, reverse=True)
        for i, spec in enumerate(region_specs):
            batches[i % job_count].append(spec)
        batches = [b for b in batches if b]

        section_db = Path(section_db)
        section_db.parent.mkdir(parents=True, exist_ok=True)
        if section_db.exists():
            section_db.unlink()
        connection = sqlite3.connect(section_db)
        connection.execute("PRAGMA journal_mode=WAL")
        connection.execute("PRAGMA synchronous=NORMAL")
        connection.execute(SECTION_SCHEMA)
        connection.execute("DELETE FROM section_summary")
        connection.commit()

        sampled_chunks = 0
        sampled_sections = 0
        completed_regions = 0
        cluster_cells = max(1, int(math.ceil(verification_step / step)))
        tmp_root = cache_tmp = section_db.parent / "parallel_scan_tmp"
        tmp_root.mkdir(parents=True, exist_ok=True)
        # Remove stale shards from an interrupted previous analysis.
        for old in tmp_root.glob("sections_*.sqlite*"):
            try:
                old.unlink()
            except OSError:
                pass

        payloads = []
        for job_id, regions in enumerate(batches):
            payloads.append({
                "regions": regions,
                "bounds": tuple(bounds),
                "block_bounds": tuple(block_bounds),
                "stride_chunks": int(stride_chunks),
                "step": int(step),
                "fill_height": bool(fill_height),
                "block_profile": str(self.block_profile),
                "shard_path": str(tmp_root / f"sections_{job_id:03d}.sqlite"),
            })

        self._emit(progress_start, f"Minecraft verification: starting {workers} worker processes across {len(region_specs):,} usable regions…")
        executor = None
        try:
            ctx = mp.get_context("spawn") if os.name == "nt" else mp.get_context()
            executor = cf.ProcessPoolExecutor(max_workers=workers, mp_context=ctx)
            futures = {executor.submit(scan_region_batch, payload): payload for payload in payloads}
            for future in cf.as_completed(futures):
                self._check_cancel()
                result = future.result()
                sampled_chunks += int(result.get("sampled_chunks", 0))
                sampled_sections += int(result.get("sampled_sections", 0))
                completed_regions += int(result.get("region_count", 0))
                self.catalog.unknown_blocks.update(str(x) for x in (result.get("unknown_blocks") or []))

                for cx, cz, local_x, local_z, top_y, top_cat_idx, cover, host_idx in result.get("samples") or []:
                    world_x = int(cx) * 16 + int(local_x)
                    world_z = int(cz) * 16 + int(local_z)
                    grid_x = min(surface_height.shape[1] - 1, max(0, (world_x - min_x) // step))
                    grid_z = min(surface_height.shape[0] - 1, max(0, (world_z - min_z) // step))
                    if fill_height:
                        target_rows = slice(grid_z, grid_z + 1)
                        target_cols = slice(grid_x, grid_x + 1)
                    else:
                        cluster_world_x = int(cx) * 16
                        cluster_world_z = int(cz) * 16
                        start_col = max(0, (cluster_world_x - min_x) // step)
                        start_row = max(0, (cluster_world_z - min_z) // step)
                        end_col = min(surface_height.shape[1], start_col + cluster_cells)
                        end_row = min(surface_height.shape[0], start_row + cluster_cells)
                        target_rows = slice(start_row, end_row)
                        target_cols = slice(start_col, end_col)
                    if fill_height:
                        surface_height[target_rows, target_cols] = float(top_y)
                    surface_category[target_rows, target_cols] = np.int16(top_cat_idx)
                    if int(top_cat_idx) == self.catalog.category_to_index.get("water", -999):
                        water_level[target_rows, target_cols] = np.int16(max(-32767, min(32767, int(top_y))))
                    soil_depth[target_rows, target_cols] = np.int16(min(32767, int(cover)))
                    if int(host_idx) >= 0:
                        host_category[target_rows, target_cols] = np.int16(host_idx)

                shard = Path(str(result.get("shard_path") or ""))
                if shard.is_file():
                    # ATTACH is much faster than moving millions of Python tuples
                    # through multiprocessing IPC.
                    alias = "wgl_shard"
                    escaped = str(shard).replace("'", "''")
                    connection.execute(f"ATTACH DATABASE '{escaped}' AS {alias}")
                    connection.execute(
                        f"INSERT OR REPLACE INTO section_summary SELECT * FROM {alias}.section_summary"
                    )
                    connection.commit()
                    connection.execute(f"DETACH DATABASE {alias}")
                    try:
                        shard.unlink()
                    except OSError:
                        pass

                fraction = min(1.0, completed_regions / max(1, len(region_specs)))
                pct = progress_start + int((progress_end - progress_start) * fraction)
                self._emit(
                    pct,
                    f"Minecraft verification: {completed_regions:,}/{len(region_specs):,} regions; "
                    f"{sampled_chunks:,}/{estimated:,} sampled chunks; {sampled_sections:,} solid section summaries; {workers} workers",
                )
        finally:
            if executor is not None:
                executor.shutdown(wait=True, cancel_futures=True)
            connection.close()
            try:
                if tmp_root.is_dir() and not any(tmp_root.iterdir()):
                    tmp_root.rmdir()
            except OSError:
                pass

        for array in arrays:
            array.flush()
        return sampled_chunks, sampled_sections

    @staticmethod
    def _derive_slope(height_array: np.memmap, step: int) -> tuple[np.ndarray, np.ndarray]:
        height = np.asarray(height_array, dtype=np.float32)
        valid = np.isfinite(height)
        if not np.any(valid):
            return (
                np.full(height.shape, np.nan, dtype=np.float32),
                np.full(height.shape, np.nan, dtype=np.float32),
            )
        fill_value = float(np.nanmedian(height[valid]))
        working = np.where(valid, height, fill_value)
        dz, dx = np.gradient(working, float(step), float(step))
        slope = np.degrees(np.arctan(np.hypot(dx, dz))).astype(np.float32)
        aspect = (np.degrees(np.arctan2(-dx, dz)) + 360.0) % 360.0
        aspect = aspect.astype(np.float32)
        slope[~valid] = np.nan
        aspect[~valid] = np.nan
        return slope, aspect

    def _derive_hydrology(self, height_array: np.memmap) -> tuple[np.ndarray, np.ndarray]:
        heights = np.asarray(height_array, dtype=np.float32)
        valid = np.isfinite(heights)
        shape = heights.shape
        sentinel = np.iinfo(np.int32).min
        quantized = np.full(shape, sentinel, dtype=np.int32)
        quantized[valid] = np.floor(heights[valid] * 4.0).astype(np.int32)

        directions = np.full(shape, -1, dtype=np.int8)
        best = quantized.copy()
        offsets = [
            (-1, 0), (-1, 1), (0, 1), (1, 1),
            (1, 0), (1, -1), (0, -1), (-1, -1),
        ]
        rows, cols = shape

        for direction, (dr, dc) in enumerate(offsets):
            neighbour = np.full(shape, sentinel, dtype=np.int32)
            target_r0 = max(0, -dr)
            target_r1 = min(rows, rows - dr)
            target_c0 = max(0, -dc)
            target_c1 = min(cols, cols - dc)
            source_r0 = target_r0 + dr
            source_r1 = target_r1 + dr
            source_c0 = target_c0 + dc
            source_c1 = target_c1 + dc
            neighbour[target_r0:target_r1, target_c0:target_c1] = (
                quantized[source_r0:source_r1, source_c0:source_c1]
            )
            mask = valid & (neighbour != sentinel) & (neighbour < best)
            best[mask] = neighbour[mask]
            directions[mask] = direction

        accumulation = np.ones(shape, dtype=np.float32)
        accumulation[~valid] = 0.0
        flat_valid_flow = np.flatnonzero(valid.ravel() & (directions.ravel() >= 0))
        if flat_valid_flow.size:
            qflat = quantized.ravel()
            order = flat_valid_flow[np.argsort(qflat[flat_valid_flow], kind="stable")[::-1]]
            direction_flat = directions.ravel()
            accumulation_flat = accumulation.ravel()
            offset_flat = np.asarray(
                [dr * cols + dc for dr, dc in offsets],
                dtype=np.int64,
            )
            ordered_heights = qflat[order]
            boundaries = np.flatnonzero(np.diff(ordered_heights)) + 1
            starts = np.concatenate(([0], boundaries))
            ends = np.concatenate((boundaries, [order.size]))
            total_groups = max(1, len(starts))
            for group_number, (start, end) in enumerate(zip(starts, ends), 1):
                self._check_cancel()
                sources = order[start:end]
                destinations = sources + offset_flat[direction_flat[sources]]
                np.add.at(accumulation_flat, destinations, accumulation_flat[sources])
                if group_number % 1024 == 0:
                    self._emit(
                        73 + int(14 * group_number / total_groups),
                        f"Hydrology: processed {group_number:,}/{total_groups:,} elevation bands",
                    )

        return directions, accumulation
