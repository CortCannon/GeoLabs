from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
import hashlib
import json
try:
    import tomllib
except ImportError:  # Python 3.10
    import tomli as tomllib


@dataclass(frozen=True)
class Category:
    id: str
    label: str
    formation: str
    permeability: float = 0.0
    strength: float = 0.5
    solubility: float = 0.0
    cave_score: float = 0.0
    ore_host_score: float = 0.0
    protected: bool = False


class BlockCategoryCatalog:
    """Editable Minecraft-block to real-world geology classifier.

    Exact rules win over prefix/suffix/contains rules. Unknown blocks are
    recorded during analysis so users can extend the TOML profile rather than
    having the program silently guess.
    """

    def __init__(
        self,
        *,
        source_path: Path,
        categories: dict[str, Category],
        exact: dict[str, str],
        prefixes: list[tuple[str, str]],
        suffixes: list[tuple[str, str]],
        contains: list[tuple[str, str]],
        default_category: str,
    ) -> None:
        self.source_path = Path(source_path)
        self.categories = categories
        self.exact = exact
        self.prefixes = prefixes
        self.suffixes = suffixes
        self.contains = contains
        self.default_category = default_category
        self.unknown_blocks: set[str] = set()
        self.category_ids = tuple(categories)
        self.category_to_index = {name: i for i, name in enumerate(self.category_ids)}
        self.index_to_category = {i: name for name, i in self.category_to_index.items()}

    @classmethod
    def load(cls, path: Path) -> "BlockCategoryCatalog":
        path = Path(path)
        raw = tomllib.loads(path.read_text(encoding="utf-8"))
        categories: dict[str, Category] = {}
        for category_id, values in dict(raw.get("categories") or {}).items():
            values = dict(values or {})
            categories[str(category_id)] = Category(
                id=str(category_id),
                label=str(values.get("label") or category_id.replace("_", " ").title()),
                formation=str(values.get("formation") or ""),
                permeability=float(values.get("permeability", 0.0)),
                strength=float(values.get("strength", 0.5)),
                solubility=float(values.get("solubility", 0.0)),
                cave_score=float(values.get("cave_score", 0.0)),
                ore_host_score=float(values.get("ore_host_score", 0.0)),
                protected=bool(values.get("protected", False)),
            )
        if not categories:
            raise ValueError(f"No categories found in {path}")

        rules = dict(raw.get("rules") or {})
        exact: dict[str, str] = {}
        for category_id, names in dict(rules.get("exact") or {}).items():
            for name in names or []:
                exact[cls._normalise(name)] = str(category_id)

        def parse_pattern_table(key: str) -> list[tuple[str, str]]:
            parsed: list[tuple[str, str]] = []
            for category_id, patterns in dict(rules.get(key) or {}).items():
                for pattern in patterns or []:
                    parsed.append((str(pattern).lower(), str(category_id)))
            parsed.sort(key=lambda item: len(item[0]), reverse=True)
            return parsed

        default_category = str(raw.get("profile", {}).get("default_category", "unknown"))
        if default_category not in categories:
            default_category = next(iter(categories))
        return cls(
            source_path=path,
            categories=categories,
            exact=exact,
            prefixes=parse_pattern_table("prefix"),
            suffixes=parse_pattern_table("suffix"),
            contains=parse_pattern_table("contains"),
            default_category=default_category,
        )

    @staticmethod
    def _normalise(block_name: Any) -> str:
        name = str(block_name or "minecraft:air").split("[", 1)[0].strip().lower()
        return name if ":" in name else f"minecraft:{name}"

    def classify(self, block_name: Any) -> str:
        name = self._normalise(block_name)
        exact = self.exact.get(name)
        if exact in self.categories:
            return exact

        path = name.split(":", 1)[-1]
        for prefix, category_id in self.prefixes:
            if path.startswith(prefix) and category_id in self.categories:
                return category_id
        for suffix, category_id in self.suffixes:
            if path.endswith(suffix) and category_id in self.categories:
                return category_id
        for token, category_id in self.contains:
            if token in path and category_id in self.categories:
                return category_id

        self.unknown_blocks.add(name)
        return self.default_category

    def classify_index(self, block_name: Any) -> int:
        return self.category_to_index[self.classify(block_name)]

    def category(self, category_id: str) -> Category:
        return self.categories.get(category_id, self.categories[self.default_category])

    def fingerprint(self) -> str:
        digest = hashlib.sha256(self.source_path.read_bytes()).hexdigest()
        return digest[:24]

    def serializable_categories(self) -> list[dict[str, Any]]:
        result = []
        for index, category_id in enumerate(self.category_ids):
            category = self.categories[category_id]
            result.append({
                "index": index,
                "id": category.id,
                "label": category.label,
                "formation": category.formation,
                "permeability": category.permeability,
                "strength": category.strength,
                "solubility": category.solubility,
                "cave_score": category.cave_score,
                "ore_host_score": category.ore_host_score,
                "protected": category.protected,
            })
        return result

    def write_unknown_report(self, path: Path) -> None:
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(
            json.dumps({"unknown_blocks": sorted(self.unknown_blocks)}, indent=2),
            encoding="utf-8",
        )
