from __future__ import annotations

import tempfile
from pathlib import Path

from .engine import AnalysisOptions, GeologicalAnalyzer
from ..world.tests_exporter_roundtrip import _make_world


def run() -> None:
    with tempfile.TemporaryDirectory(prefix="wgl_analysis_test_") as td:
        world = _make_world(Path(td))
        report = GeologicalAnalyzer(AnalysisOptions(
            world_path=world,
            chunk_bounds=(0, 0, 0, 0),
            height_range=(0, 16),
            scope_name="smoke_test",
            requested_step=8,
            verification_step=16,
            source_mode="minecraft",
            force_rebuild=True,
        )).run()
        assert report.grid_shape == (2, 2)
        assert report.sampled_chunks == 1
        assert report.sampled_sections >= 1
        assert report.manifest_path.is_file()
    print("Geological analysis smoke test OK")


if __name__ == "__main__":
    run()
