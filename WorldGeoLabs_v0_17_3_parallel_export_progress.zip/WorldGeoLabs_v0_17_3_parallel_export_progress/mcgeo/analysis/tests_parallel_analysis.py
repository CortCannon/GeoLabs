from __future__ import annotations

import shutil
import tempfile
from pathlib import Path

from .engine import AnalysisOptions, GeologicalAnalyzer
from ..world.dimensions import resolve_dimension_storage
from ..world.tests_exporter_roundtrip import _make_world


def run() -> None:
    with tempfile.TemporaryDirectory(prefix="wgl_parallel_analysis_") as td:
        world = _make_world(Path(td), modern=True)
        region_dir = resolve_dimension_storage(world).region_dir
        source = region_dir / "r.0.0.mca"
        # Four independent region files force the process-pool path even though
        # the synthetic test world contains only one present chunk per region.
        for name in ("r.1.0.mca", "r.0.1.mca", "r.1.1.mca"):
            shutil.copy2(source, region_dir / name)
        messages: list[str] = []
        report = GeologicalAnalyzer(
            AnalysisOptions(
                world_path=world,
                chunk_bounds=(0, 32, 0, 32),
                height_range=(0, 16),
                scope_name="parallel_smoke",
                requested_step=16,
                verification_step=16,
                source_mode="minecraft",
                force_rebuild=True,
                workers=4,
            ),
            progress=lambda _pct, msg: messages.append(str(msg)),
        ).run()
        assert report.sampled_chunks == 4, report.sampled_chunks
        assert report.sampled_sections >= 4, report.sampled_sections
        assert any("4 workers" in msg for msg in messages), messages[-10:]
    print("Parallel geological analysis test OK (4 workers)")


if __name__ == "__main__":
    run()
