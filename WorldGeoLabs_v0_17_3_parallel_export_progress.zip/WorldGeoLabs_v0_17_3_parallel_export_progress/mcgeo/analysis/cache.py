from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any
import hashlib
import json
import os
import time

import numpy as np


@dataclass(frozen=True)
class ArraySpec:
    name: str
    dtype: str
    shape: tuple[int, ...]
    file: str
    nodata: float | int | None = None


class AnalysisCache:
    def __init__(self, root: Path, key: str) -> None:
        self.root = Path(root) / key
        self.root.mkdir(parents=True, exist_ok=True)
        self.arrays_dir = self.root / "arrays"
        self.arrays_dir.mkdir(exist_ok=True)
        self.manifest_path = self.root / "manifest.json"
        self._specs: dict[str, ArraySpec] = {}

    @staticmethod
    def make_key(payload: dict[str, Any]) -> str:
        encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
        return hashlib.sha256(encoded).hexdigest()[:24]

    def create_array(
        self,
        name: str,
        shape: tuple[int, ...],
        dtype: str,
        *,
        fill: float | int = 0,
        nodata: float | int | None = None,
    ) -> np.memmap:
        safe = "".join(ch if ch.isalnum() or ch in "._-" else "_" for ch in name)
        file_name = f"{safe}.dat"
        path = self.arrays_dir / file_name
        array = np.memmap(path, mode="w+", dtype=np.dtype(dtype), shape=shape)
        array[...] = fill
        array.flush()
        self._specs[name] = ArraySpec(
            name=name,
            dtype=np.dtype(dtype).str,
            shape=tuple(int(v) for v in shape),
            file=str(Path("arrays") / file_name),
            nodata=nodata,
        )
        return array

    def open_array(self, spec: ArraySpec | dict[str, Any], mode: str = "r") -> np.memmap:
        if isinstance(spec, dict):
            spec = ArraySpec(
                name=str(spec["name"]),
                dtype=str(spec["dtype"]),
                shape=tuple(int(v) for v in spec["shape"]),
                file=str(spec["file"]),
                nodata=spec.get("nodata"),
            )
        return np.memmap(
            self.root / spec.file,
            mode=mode,
            dtype=np.dtype(spec.dtype),
            shape=spec.shape,
        )

    def write_manifest(self, payload: dict[str, Any], *, complete: bool) -> Path:
        doc = dict(payload)
        doc["schema"] = "worldgeolabs.geological-analysis.v1"
        doc["complete"] = bool(complete)
        doc["updated_unix"] = time.time()
        doc["arrays"] = {
            name: {
                "name": spec.name,
                "dtype": spec.dtype,
                "shape": list(spec.shape),
                "file": spec.file,
                "nodata": spec.nodata,
            }
            for name, spec in self._specs.items()
        }
        temp = self.manifest_path.with_suffix(".json.tmp")
        temp.write_text(json.dumps(doc, indent=2), encoding="utf-8")
        os.replace(temp, self.manifest_path)
        return self.manifest_path

    def load_manifest(self) -> dict[str, Any] | None:
        try:
            raw = json.loads(self.manifest_path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None
        return raw if isinstance(raw, dict) else None
