from __future__ import annotations

from pathlib import Path
from typing import Any
try:
    import tomllib
except ImportError:  # Python 3.10
    import tomli as tomllib

from .block_categories import BlockCategoryCatalog
from .worldpainter_overview import PackageReader


def _infer_category(name: str, catalog: BlockCategoryCatalog) -> str:
    value = str(name or "").strip().lower()
    checks = [
        (("granite", "diorite"), "intrusive_igneous"),
        (("andesite", "basalt", "tuff", "volcan", "obsidian"), "volcanic"),
        (("calcite", "limestone", "carbonate", "dripstone", "chalk"), "carbonate"),
        (("deepslate", "slate", "metamorph"), "metamorphic_deep"),
        (("sandstone", "sediment", "siltstone", "shale"), "sedimentary"),
        (("sand", "gravel", "alluv", "beach"), "loose_sediment"),
        (("clay", "mud"), "clay_mud"),
        (("dirt", "grass", "soil", "earth"), "soil"),
        (("podzol", "mycel", "peat", "organic"), "organic_soil"),
        (("snow", "ice", "frozen"), "ice_snow"),
        (("water", "ocean", "river", "lake"), "water"),
        (("lava", "magma"), "lava"),
        (("stone", "rock", "cobble"), "generic_rock"),
    ]
    for tokens, category in checks:
        if any(token in value for token in tokens) and category in catalog.categories:
            return category
    return catalog.default_category


def load_or_create_worldpainter_mapping(
    *,
    package_path: Path,
    config_path: Path,
    catalog: BlockCategoryCatalog,
) -> tuple[dict[int, str], Path]:
    package_path = Path(package_path)
    config_path = Path(config_path)
    reader = PackageReader(package_path)
    try:
        materials = reader.read_json("materials.json")
    except Exception:
        materials = {}

    terrain_records = list(materials.get("terrains") or []) if isinstance(materials, dict) else []
    known_names: dict[int, str] = {}
    for record in terrain_records:
        try:
            known_names[int(record.get("ordinal"))] = str(record.get("name") or f"terrain_{record.get('ordinal')}")
        except Exception:
            continue

    existing: dict[int, str] = {}
    if config_path.is_file():
        try:
            raw = tomllib.loads(config_path.read_text(encoding="utf-8"))
            table = dict(raw.get("terrain") or {})
            for key, value in table.items():
                category = str(value)
                if category in catalog.categories:
                    existing[int(key)] = category
        except Exception:
            existing = {}

    mapping: dict[int, str] = {}
    for ordinal, name in sorted(known_names.items()):
        mapping[ordinal] = existing.get(ordinal) or _infer_category(name, catalog)

    # Keep manual entries even if the source package did not list that terrain
    # during this extraction.
    mapping.update({key: value for key, value in existing.items() if key not in mapping})

    config_path.parent.mkdir(parents=True, exist_ok=True)
    lines = [
        "# WorldGeoLabs WorldPainter terrain-to-geology mapping",
        "# Edit the category values, then force-rebuild Geological Analysis.",
        "",
        "[terrain_names]",
    ]
    for ordinal, name in sorted(known_names.items()):
        escaped = name.replace("\\", "\\\\").replace('"', '\\"')
        lines.append(f'"{ordinal}" = "{escaped}"')
    lines.extend(["", "[terrain]"])
    for ordinal, category in sorted(mapping.items()):
        lines.append(f'"{ordinal}" = "{category}"')
    lines.append("")
    config_path.write_text("\n".join(lines), encoding="utf-8")
    return mapping, config_path
