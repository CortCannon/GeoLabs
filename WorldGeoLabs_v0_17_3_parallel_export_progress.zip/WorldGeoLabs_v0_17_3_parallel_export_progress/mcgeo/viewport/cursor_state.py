from __future__ import annotations

from dataclasses import dataclass, field
import math

Vec3 = tuple[float, float, float]
BlockPos = tuple[int, int, int]


def clamp_point_to_edit_volume(
    point: Vec3,
    *,
    chunk_bounds: tuple[int, int, int, int] | None,
    height_range: tuple[int, int],
) -> Vec3:
    """Clamp a world-space point to the selected edit volume.

    X/Z are clamped to selected chunks. Y is clamped to the world's real block
    height range. This keeps free 3D cursor movement valid without snapping it
    back to terrain heightmaps or top surfaces.
    """
    x, y, z = float(point[0]), float(point[1]), float(point[2])
    if chunk_bounds is not None:
        min_cx, max_cx, min_cz, max_cz = (int(v) for v in chunk_bounds)
        min_x = float(min_cx * 16)
        max_x = float((max_cx + 1) * 16) - 1.0
        min_z = float(min_cz * 16)
        max_z = float((max_cz + 1) * 16) - 1.0
        x = max(min_x, min(max_x, x))
        z = max(min_z, min(max_z, z))
    ymin, ymax = int(height_range[0]), int(height_range[1])
    y = max(float(ymin), min(float(ymax), y))
    return (x, y, z)


def quantize_block(point: Vec3, *, height_range: tuple[int, int]) -> BlockPos:
    """Quantize a floating 3D cursor point to a block coordinate."""
    ymin, ymax = int(height_range[0]), int(height_range[1])
    x, y, z = float(point[0]), float(point[1]), float(point[2])
    yi = max(ymin, min(ymax, int(round(y))))
    return (int(round(x)), yi, int(round(z)))


def dist3(a: Vec3, b: Vec3) -> float:
    dx = float(a[0]) - float(b[0])
    dy = float(a[1]) - float(b[1])
    dz = float(a[2]) - float(b[2])
    return math.sqrt(dx * dx + dy * dy + dz * dz)


@dataclass(slots=True)
class BrushCursorState:
    """Persistent, surface-independent state for the 3D brush cursor.

    The OpenGL widget owns rendering and picking, but this model owns the user
    tool state: cursor depth, current/hover block, stroke samples, normal lock,
    and quick-control settings. Keeping this as a separate object makes it much
    harder for future features to accidentally become surface-painters again.
    """

    enabled: bool = False
    settings: dict = field(default_factory=dict)

    hover_world: Vec3 | None = None
    hover_quantized: BlockPos | None = None
    hover_normal: Vec3 | None = None
    hover_resolved_pick: str = "free"

    cursor_world: Vec3 | None = None
    cursor_normal: Vec3 | None = None
    cursor_resolved_pick: str = "free"
    cursor_distance: float | None = None
    last_surface_hit_distance: float | None = None
    last_target_hit: dict | None = None

    locked_normal: Vec3 | None = None
    realign_requested: bool = False
    last_align_mode: str = ""

    def merge_settings(self, incoming: dict | None) -> dict:
        """Merge UI settings while preserving viewport quick adjustments.

        The painter panel can emit slightly stale values during a burst of wheel
        or key adjustments. Preserve locally changed size/depth/roll when the
        caller did not actually change those values.
        """
        merged = dict(incoming or {})
        old = self.settings
        if old and merged.get("enabled", None) == old.get("enabled", None):
            try:
                if int(merged.get("size_blocks", 0)) == int(old.get("size_blocks", 0)):
                    merged["size_blocks"] = int(old.get("size_blocks", merged.get("size_blocks", 1)))
            except Exception:
                pass
            for key, cast, default in (
                ("brush_offset_blocks", float, 0.0),
                ("brush_roll_deg", float, 0.0),
            ):
                try:
                    if cast(merged.get(key, default)) == cast(old.get(key, default)):
                        merged[key] = cast(old.get(key, merged.get(key, default)))
                except Exception:
                    pass
        self.settings = merged
        self.enabled = bool(merged.get("enabled", False))
        return merged

    def clear_hover(self) -> None:
        self.hover_world = None
        self.hover_quantized = None
        self.hover_normal = None
        self.hover_resolved_pick = "free"

    def clear_cursor(self, *, keep_distance: bool = False) -> None:
        self.cursor_world = None
        self.cursor_normal = None
        self.cursor_resolved_pick = "free"
        self.last_target_hit = None
        self.last_surface_hit_distance = None
        if not keep_distance:
            self.cursor_distance = None

    def clear_for_disabled_tool(self) -> None:
        self.clear_hover()
        self.clear_cursor(keep_distance=False)
        self.locked_normal = None
        self.realign_requested = False

    def update_hover_from_hit(self, hit: dict, *, height_range: tuple[int, int]) -> BlockPos:
        point = hit.get("point")
        if point is None:
            raise ValueError("hit does not contain a point")
        p = (float(point[0]), float(point[1]), float(point[2]))
        q = quantize_block(p, height_range=height_range)
        normal = hit.get("normal")
        resolved = str(hit.get("resolved_pick", "free") or "free")

        self.hover_world = p
        self.hover_quantized = q
        self.hover_normal = tuple(float(v) for v in normal) if normal is not None else None
        self.hover_resolved_pick = resolved
        self.last_target_hit = dict(hit)
        return q

    def commit_cursor_from_hit(self, hit: dict, *, height_range: tuple[int, int]) -> BlockPos:
        q = self.update_hover_from_hit(hit, height_range=height_range)
        self.cursor_world = self.hover_world
        if self.hover_normal is not None:
            self.cursor_normal = self.hover_normal
        self.cursor_resolved_pick = self.hover_resolved_pick
        return q

    def apply_alignment_policy(self) -> None:
        align_mode = str(self.settings.get("align_mode", "Follow hit normal (auto)"))
        mode_l = align_mode.lower()
        if mode_l.startswith("lock") and self.hover_normal is not None and self.hover_resolved_pick in ("surface", "volume"):
            if self.locked_normal is None or self.realign_requested:
                self.locked_normal = self.hover_normal
                self.realign_requested = False
        elif not mode_l.startswith("lock"):
            self.locked_normal = None
        self.last_align_mode = align_mode

    def current_hit(self) -> dict | None:
        if self.cursor_world is None:
            return None
        return {
            "point": tuple(float(v) for v in self.cursor_world),
            "normal": tuple(float(v) for v in (self.cursor_normal or self.hover_normal or (0.0, 1.0, 0.0))),
            "resolved_pick": str(self.cursor_resolved_pick or self.hover_resolved_pick or "free"),
        }

    def distance_from_eye(self, eye: Vec3, fallback_distance: float) -> float:
        if self.cursor_distance is not None:
            return max(1.0, min(8192.0, float(self.cursor_distance)))
        if self.cursor_world is not None:
            return max(1.0, min(8192.0, dist3(eye, self.cursor_world)))
        if self.hover_world is not None:
            return max(1.0, min(8192.0, dist3(eye, self.hover_world)))
        return max(8.0, min(4096.0, float(fallback_distance)))

    def brush_offset_step(self) -> float:
        try:
            size_blocks = max(1.0, float(self.settings.get("size_blocks", 1)))
        except Exception:
            size_blocks = 1.0
        dist = self.cursor_distance
        if dist is None:
            dist = self.last_surface_hit_distance
        if dist is None:
            dist = 32.0
        return max(size_blocks * 0.35, min(24.0, max(1.0, float(dist) * 0.05)))

    def hover_payload(self, *, height_range: tuple[int, int]) -> dict:
        if self.hover_world is None:
            return {"valid": False}
        q = self.hover_quantized or quantize_block(self.hover_world, height_range=height_range)
        return {
            "valid": True,
            "x": q[0],
            "y": q[1],
            "z": q[2],
            "target_mode": "volume",
            "resolved_pick": self.hover_resolved_pick,
            "normal": list(self.hover_normal) if self.hover_normal is not None else None,
            "brush_size": int(self.settings.get("size_blocks", 1)),
            "brush_roll_deg": float(self.settings.get("brush_roll_deg", 0.0)),
            "brush_offset_blocks": float(self.settings.get("brush_offset_blocks", 0.0)),
            "align_mode": str(self.settings.get("align_mode", "Follow hit normal (auto)")),
        }


@dataclass(slots=True)
class StrokeRecorder:
    """Spacing-aware capture of a paint stroke's 3D sample points."""

    spacing_blocks: float = 1.0
    points: list[Vec3] = field(default_factory=list)
    last_world: Vec3 | None = None

    def reset(self, spacing_blocks: float) -> None:
        self.spacing_blocks = max(0.001, float(spacing_blocks))
        self.points.clear()
        self.last_world = None

    def add(self, point: Vec3) -> bool:
        p = (float(point[0]), float(point[1]), float(point[2]))
        if self.last_world is not None and dist3(p, self.last_world) < self.spacing_blocks:
            return False
        self.points.append(p)
        self.last_world = p
        return True

    def snapshot(self) -> list[Vec3]:
        return list(self.points)
