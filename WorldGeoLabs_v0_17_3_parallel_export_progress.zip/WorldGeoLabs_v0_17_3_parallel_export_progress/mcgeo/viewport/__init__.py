"""Viewport interaction models.

This package intentionally owns cursor/tool state that used to live directly in
the OpenGL widget. Rendering code can still draw and pick, but persistent edit
state should live here so the app does not regress into surface-only painter
logic.
"""

from .cursor_state import BrushCursorState, StrokeRecorder, clamp_point_to_edit_volume

__all__ = ["BrushCursorState", "StrokeRecorder", "clamp_point_to_edit_volume"]
