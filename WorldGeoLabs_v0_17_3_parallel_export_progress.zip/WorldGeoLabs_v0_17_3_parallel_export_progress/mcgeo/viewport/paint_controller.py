from __future__ import annotations

from dataclasses import dataclass
import math

from .cursor_state import clamp_point_to_edit_volume

Vec2 = tuple[float, float]
Vec3 = tuple[float, float, float]
Ray = tuple[Vec3, Vec3]


def _dot(a: Vec3, b: Vec3) -> float:
    return (float(a[0]) * float(b[0])) + (float(a[1]) * float(b[1])) + (float(a[2]) * float(b[2]))


def _add(a: Vec3, b: Vec3) -> Vec3:
    return (float(a[0]) + float(b[0]), float(a[1]) + float(b[1]), float(a[2]) + float(b[2]))


def _sub(a: Vec3, b: Vec3) -> Vec3:
    return (float(a[0]) - float(b[0]), float(a[1]) - float(b[1]), float(a[2]) - float(b[2]))


def _mul(v: Vec3, s: float) -> Vec3:
    return (float(v[0]) * float(s), float(v[1]) * float(s), float(v[2]) * float(s))


def _length(v: Vec3) -> float:
    return math.sqrt(float(v[0]) * float(v[0]) + float(v[1]) * float(v[1]) + float(v[2]) * float(v[2]))


@dataclass(slots=True)
class FreePaintController:
    """Small controller for surface-independent 3D brush placement.

    The previous free-paint path projected the mouse onto one horizontal Y plane.
    That still fails when the camera ray intersects that plane outside the edit
    area: clamping then pins the cursor to one edge until the camera is moved.

    This controller instead treats the brush as a persistent 3D gizmo and
    reprojects the current mouse ray onto a camera-facing plane through that
    gizmo. That keeps the brush visually lined up with the mouse after camera
    orbit/flight, while explicit height controls move the cursor in world Y. No
    surface hit is used unless the caller asks to seed/reacquire the cursor or
    surface-snap mode is active.
    """

    cursor_world: Vec3 | None = None
    last_screen: Vec2 | None = None

    def reset(self, *, keep_cursor: bool = False) -> None:
        if not keep_cursor:
            self.cursor_world = None
        self.last_screen = None

    def set_cursor(self, point: Vec3 | None, *, keep_screen: bool = True) -> None:
        self.cursor_world = None if point is None else (float(point[0]), float(point[1]), float(point[2]))
        if not keep_screen:
            self.last_screen = None

    def move_world_y(
        self,
        delta_y: float,
        *,
        fallback_point: Vec3,
        chunk_bounds: tuple[int, int, int, int] | None,
        height_range: tuple[int, int],
    ) -> Vec3:
        base = self.cursor_world or fallback_point
        p = (float(base[0]), float(base[1]) + float(delta_y), float(base[2]))
        p = clamp_point_to_edit_volume(p, chunk_bounds=chunk_bounds, height_range=height_range)
        self.cursor_world = p
        return p

    def _initial_anchor(
        self,
        *,
        current_cursor: Vec3 | None,
        surface_hit: dict | None,
        camera_target: Vec3,
        chunk_bounds: tuple[int, int, int, int] | None,
        height_range: tuple[int, int],
    ) -> Vec3:
        candidates: list[Vec3] = []
        if current_cursor is not None:
            candidates.append(current_cursor)
        if self.cursor_world is not None:
            candidates.append(self.cursor_world)
        if surface_hit is not None and surface_hit.get("point") is not None:
            try:
                p = surface_hit.get("point")
                candidates.append((float(p[0]), float(p[1]), float(p[2])))
            except Exception:
                pass
        candidates.append(camera_target)
        for p in candidates:
            try:
                return clamp_point_to_edit_volume(
                    (float(p[0]), float(p[1]), float(p[2])),
                    chunk_bounds=chunk_bounds,
                    height_range=height_range,
                )
            except Exception:
                continue
        ymin, ymax = int(height_range[0]), int(height_range[1])
        return (0.0, float((ymin + ymax) * 0.5), 0.0)

    def _intersect_camera_plane(self, *, ray: Ray, anchor: Vec3, forward: Vec3) -> Vec3 | None:
        (ox, oy, oz), (dx, dy, dz) = ray
        nx, ny, nz = (float(forward[0]), float(forward[1]), float(forward[2]))
        denom = (float(dx) * nx) + (float(dy) * ny) + (float(dz) * nz)
        if abs(denom) < 1e-6:
            return None
        ax, ay, az = (float(anchor[0]), float(anchor[1]), float(anchor[2]))
        t = (((ax - float(ox)) * nx) + ((ay - float(oy)) * ny) + ((az - float(oz)) * nz)) / denom
        if t <= 0.0 or not math.isfinite(t):
            return None
        return (float(ox) + float(dx) * t, float(oy) + float(dy) * t, float(oz) + float(dz) * t)

    def _point_at_anchor_depth(self, *, ray: Ray, anchor: Vec3, eye: Vec3) -> Vec3:
        _origin, direction = ray
        depth = max(1.0, min(8192.0, _length(_sub(anchor, eye))))
        return _add(eye, _mul(direction, depth))

    def resolve_free_hit(
        self,
        sx: float,
        sy: float,
        *,
        screen_size: tuple[int, int],
        ray: Ray | None,
        camera_eye: Vec3,
        camera_target: Vec3,
        camera_basis: tuple[Vec3, Vec3, Vec3],
        current_cursor: Vec3 | None,
        surface_hit: dict | None,
        chunk_bounds: tuple[int, int, int, int] | None,
        height_range: tuple[int, int],
    ) -> dict | None:
        if ray is None:
            return None
        w, h = max(1, int(screen_size[0])), max(1, int(screen_size[1]))
        forward, right, up = camera_basis
        anchor = self._initial_anchor(
            current_cursor=current_cursor,
            surface_hit=surface_hit,
            camera_target=camera_target,
            chunk_bounds=chunk_bounds,
            height_range=height_range,
        )

        # Keep the brush visually under the mouse by solving the current mouse
        # ray against a camera-facing plane through the persistent cursor.  The
        # v0.16.8 incremental delta approach was stable, but after camera orbit
        # or flight it could leave the brush offset from the OS cursor because a
        # zero mouse delta reused the old world point. Reprojecting every hover
        # keeps the cursor/screen relationship predictable without going back to
        # the old horizontal-Y lock.
        p: Vec3 | None = self._intersect_camera_plane(ray=ray, anchor=anchor, forward=forward)
        if p is None:
            p = self._point_at_anchor_depth(ray=ray, anchor=anchor, eye=camera_eye)

        p = clamp_point_to_edit_volume(p, chunk_bounds=chunk_bounds, height_range=height_range)
        self.cursor_world = p
        self.last_screen = (float(sx), float(sy))
        return {
            "point": p,
            "normal": (0.0, 1.0, 0.0),
            "resolved_pick": "free-screen-plane",
        }
