from __future__ import annotations

from dataclasses import dataclass

from .package import WorldPainterDimension


@dataclass(frozen=True)
class AlignmentReport:
    status: str
    messages: tuple[str, ...]
    worldpainter_chunk_bounds: tuple[int, int, int, int] | None
    minecraft_chunk_bounds: tuple[int, int, int, int] | None
    height_matches: bool

    @property
    def ok(self) -> bool:
        return self.status in {"aligned", "compatible"}


def compare_metadata(
    dimension: WorldPainterDimension,
    minecraft_chunk_bounds: tuple[int, int, int, int] | None,
    minecraft_height_range: tuple[int, int] | None,
) -> AlignmentReport:
    messages: list[str] = []
    wp_chunks = None
    if dimension.bounds_blocks is not None:
        min_x, max_x, min_z, max_z = dimension.bounds_blocks
        wp_chunks = (min_x // 16, max_x // 16, min_z // 16, max_z // 16)

    height_matches = (
        minecraft_height_range is not None
        and tuple(map(int, minecraft_height_range)) == (dimension.min_y, dimension.max_y)
    )
    if height_matches:
        messages.append(f"Build height matches: {dimension.min_y}..{dimension.max_y}")
    elif minecraft_height_range is not None:
        messages.append(
            f"Build-height difference: WorldPainter {dimension.min_y}..{dimension.max_y}, "
            f"Minecraft {minecraft_height_range[0]}..{minecraft_height_range[1]}"
        )

    if wp_chunks is None or minecraft_chunk_bounds is None:
        messages.append("Exact bounds comparison is unavailable; block-sample alignment should be run later.")
        status = "compatible" if height_matches else "needs_verification"
    else:
        a0, a1, a2, a3 = wp_chunks
        b0, b1, b2, b3 = minecraft_chunk_bounds
        overlap = not (a1 < b0 or b1 < a0 or a3 < b2 or b3 < a2)
        if overlap:
            messages.append("WorldPainter and Minecraft project bounds overlap.")
            status = "aligned" if height_matches else "compatible"
        else:
            messages.append("WorldPainter and Minecraft bounds do not overlap.")
            status = "mismatch"

    return AlignmentReport(
        status=status,
        messages=tuple(messages),
        worldpainter_chunk_bounds=wp_chunks,
        minecraft_chunk_bounds=minecraft_chunk_bounds,
        height_matches=height_matches,
    )
