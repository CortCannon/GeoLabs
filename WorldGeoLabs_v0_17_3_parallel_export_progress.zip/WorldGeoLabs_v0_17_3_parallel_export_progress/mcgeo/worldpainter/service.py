from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

from .bridge import WorldPainterBridgeError, run_bridge
from .package import WorldPainterPackage, load_worldpainter_package


@dataclass(frozen=True)
class WorldPainterImportResult:
    package: WorldPainterPackage
    original_source: Path
    package_path: Path
    used_bridge: bool
    cache_hit: bool


def import_worldpainter_source(source: Path, app_root: Path, cache_root: Path) -> WorldPainterImportResult:
    source = Path(source).resolve()
    if source.suffix.lower() == ".world":
        bridge = run_bridge(source, app_root=app_root, cache_root=cache_root)
        package = load_worldpainter_package(bridge.package_path)
        return WorldPainterImportResult(
            package=package,
            original_source=source,
            package_path=bridge.package_path,
            used_bridge=True,
            cache_hit=not bool(bridge.command),
        )
    package = load_worldpainter_package(source)
    return WorldPainterImportResult(
        package=package,
        original_source=source,
        package_path=source,
        used_bridge=False,
        cache_hit=False,
    )
