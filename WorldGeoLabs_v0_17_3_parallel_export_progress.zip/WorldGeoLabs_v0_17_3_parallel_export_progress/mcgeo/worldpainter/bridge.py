from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import hashlib
import os
import shutil
import subprocess
import sys


class WorldPainterBridgeError(RuntimeError):
    pass


@dataclass(frozen=True)
class BridgeRun:
    package_path: Path
    command: tuple[str, ...]
    stdout: str
    stderr: str
    backend: str = ""


def source_fingerprint(path: Path) -> str:
    path = Path(path)
    stat = path.stat()
    digest = hashlib.sha256()
    digest.update(str(path.resolve()).encode("utf-8", errors="replace"))
    digest.update(str(stat.st_size).encode())
    digest.update(str(stat.st_mtime_ns).encode())
    with path.open("rb") as handle:
        digest.update(handle.read(1024 * 1024))
    return digest.hexdigest()[:24]


def _existing(candidates: list[Path]) -> Path | None:
    for candidate in candidates:
        try:
            if candidate.is_file():
                return candidate.resolve()
        except OSError:
            continue
    return None


def find_wpscript() -> Path | None:
    """Find WorldPainter's official command-line scripting launcher.

    The installed WorldPainter scripting runtime already contains the correct
    classes for the user's .world format, so it is safer than shipping a
    separately versioned copy of WorldPainter libraries.
    """
    candidates: list[Path] = []
    env = os.environ.get("WGL_WPSCRIPT", "").strip()
    if env:
        candidates.append(Path(env))

    for name in ("wpscript.exe", "wpscript.bat", "wpscript.cmd", "wpscript"):
        found = shutil.which(name)
        if found:
            candidates.append(Path(found))

    if os.name == "nt":
        program_files = [
            os.environ.get("ProgramFiles", r"C:\Program Files"),
            os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)"),
            os.environ.get("LOCALAPPDATA", ""),
        ]
        for base in filter(None, program_files):
            root = Path(base)
            candidates.extend([
                root / "WorldPainter" / "wpscript.exe",
                root / "WorldPainter" / "wpscript.bat",
                root / "Programs" / "WorldPainter" / "wpscript.exe",
                root / "Programs" / "WorldPainter" / "wpscript.bat",
            ])
    else:
        candidates.extend([
            Path("/usr/bin/wpscript"),
            Path("/usr/local/bin/wpscript"),
            Path.home() / ".local" / "bin" / "wpscript",
            Path("/opt/worldpainter/wpscript"),
        ])
    return _existing(candidates)


def find_bridge_jar(app_root: Path) -> Path | None:
    candidates: list[Path] = []
    env = os.environ.get("WGL_WORLDPAINTER_BRIDGE_JAR", "").strip()
    if env:
        candidates.append(Path(env))
    candidates.extend([
        Path(app_root) / "tools" / "worldpainter_bridge" / "worldpainter-bridge.jar",
        Path(app_root) / "worldpainter-bridge.jar",
    ])
    return _existing(candidates)


def _run_wpscript(
    *,
    world_file: Path,
    app_root: Path,
    output_dir: Path,
) -> BridgeRun:
    wpscript = find_wpscript()
    if wpscript is None:
        raise WorldPainterBridgeError(
            "WorldPainter is installed, but WorldGeoLabs could not find its "
            "wpscript launcher. Expected C:\\Program Files\\WorldPainter\\wpscript.exe "
            "or a wpscript command on PATH. Set WGL_WPSCRIPT to the full path "
            "of wpscript.exe."
        )

    script = Path(app_root) / "tools" / "worldpainter_bridge" / "export_worldpainter.js"
    if not script.is_file():
        raise WorldPainterBridgeError(f"Bundled WorldPainter export script is missing: {script}")

    sample_step = max(1, int(os.environ.get("WGL_WORLDPAINTER_SAMPLE_STEP", "8") or "8"))
    command = (
        str(wpscript),
        str(script),
        str(world_file),
        str(output_dir),
        str(sample_step),
    )
    proc = subprocess.run(
        command,
        capture_output=True,
        text=True,
        timeout=2 * 60 * 60,
        cwd=str(script.parent),
    )
    if proc.returncode != 0:
        raise WorldPainterBridgeError(
            f"WorldPainter wpscript failed with exit code {proc.returncode}\n"
            f"{proc.stderr.strip() or proc.stdout.strip()}"
        )
    return BridgeRun(
        package_path=output_dir,
        command=command,
        stdout=proc.stdout,
        stderr=proc.stderr,
        backend="wpscript",
    )


def _run_custom_jar(
    *,
    world_file: Path,
    app_root: Path,
    output_dir: Path,
) -> BridgeRun:
    bridge_jar = find_bridge_jar(app_root)
    if bridge_jar is None:
        raise WorldPainterBridgeError("No custom WorldPainter bridge JAR is installed.")
    java = os.environ.get("WGL_JAVA", "").strip() or shutil.which("java")
    if not java:
        raise WorldPainterBridgeError("Java was not found. Install Java or set WGL_JAVA.")
    command = (
        str(java), "-jar", str(bridge_jar),
        "--input", str(world_file),
        "--output", str(output_dir),
        "--schema", "worldgeolabs.worldpainter.v1",
    )
    proc = subprocess.run(command, capture_output=True, text=True, timeout=2 * 60 * 60)
    if proc.returncode != 0:
        raise WorldPainterBridgeError(
            f"WorldPainter bridge failed with exit code {proc.returncode}\n"
            f"{proc.stderr.strip() or proc.stdout.strip()}"
        )
    return BridgeRun(output_dir, command, proc.stdout, proc.stderr, "jar")


def run_bridge(world_file: Path, app_root: Path, cache_root: Path) -> BridgeRun:
    world_file = Path(world_file).resolve()
    if not world_file.is_file():
        raise WorldPainterBridgeError(f"WorldPainter project not found: {world_file}")

    output_dir = Path(cache_root) / source_fingerprint(world_file)
    manifest = output_dir / "world_info.json"
    if manifest.is_file() and manifest.stat().st_mtime_ns >= world_file.stat().st_mtime_ns:
        return BridgeRun(
            output_dir, (), "Using cached WorldPainter analysis package.", "", "cache"
        )

    output_dir.mkdir(parents=True, exist_ok=True)

    # Prefer WorldPainter's own scripting launcher. It uses the exact installed
    # WorldPainter runtime and can officially load .world projects.
    if find_wpscript() is not None:
        result = _run_wpscript(
            world_file=world_file,
            app_root=app_root,
            output_dir=output_dir,
        )
    elif find_bridge_jar(app_root) is not None:
        result = _run_custom_jar(
            world_file=world_file,
            app_root=app_root,
            output_dir=output_dir,
        )
    else:
        raise WorldPainterBridgeError(
            "WorldGeoLabs could not find WorldPainter's wpscript launcher. "
            "Install WorldPainter normally, or set WGL_WPSCRIPT to the full "
            "path of wpscript.exe. The usual Windows path is "
            "C:\\Program Files\\WorldPainter\\wpscript.exe."
        )

    if not manifest.is_file():
        raise WorldPainterBridgeError(
            f"WorldPainter extraction completed using {result.backend}, but "
            "world_info.json was not created."
        )
    return result
