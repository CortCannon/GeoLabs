from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping
import json
import zipfile


class WorldPainterPackageError(RuntimeError):
    pass


@dataclass(frozen=True)
class WorldPainterDimension:
    id: str
    name: str
    anchor: str = "minecraft:overworld"
    min_y: int = -64
    max_y: int = 320
    origin_x: int = 0
    origin_z: int = 0
    tile_size_blocks: int = 128
    bounds_blocks: tuple[int, int, int, int] | None = None
    datasets: Mapping[str, str] = field(default_factory=dict)

    @classmethod
    def from_mapping(cls, raw: Mapping[str, Any]) -> "WorldPainterDimension":
        bounds = raw.get("bounds_blocks")
        parsed_bounds = None
        if isinstance(bounds, (list, tuple)) and len(bounds) == 4:
            parsed_bounds = tuple(int(v) for v in bounds)
        height = raw.get("height")
        min_y = int(raw.get("min_y", -64))
        max_y = int(raw.get("max_y", min_y + int(height))) if height is not None else int(raw.get("max_y", 320))
        return cls(
            id=str(raw.get("id") or raw.get("name") or "surface"),
            name=str(raw.get("name") or raw.get("id") or "Surface"),
            anchor=str(raw.get("anchor") or "minecraft:overworld"),
            min_y=min_y,
            max_y=max_y,
            origin_x=int(raw.get("origin_x", 0)),
            origin_z=int(raw.get("origin_z", 0)),
            tile_size_blocks=max(1, int(raw.get("tile_size_blocks", 128))),
            bounds_blocks=parsed_bounds,
            datasets=dict(raw.get("datasets") or {}),
        )


@dataclass(frozen=True)
class WorldPainterPackage:
    source_path: Path
    schema: str
    project_name: str
    worldpainter_version: str
    dimensions: tuple[WorldPainterDimension, ...]
    materials: Mapping[str, Any]
    layers: tuple[Mapping[str, Any], ...]
    metadata: Mapping[str, Any]

    def dimension_for_anchor(self, anchor: str = "minecraft:overworld") -> WorldPainterDimension | None:
        for dimension in self.dimensions:
            if dimension.anchor == anchor:
                return dimension
        return self.dimensions[0] if self.dimensions else None


def _read_json_from_source(source: Path, member: str) -> dict[str, Any]:
    if source.is_dir():
        path = source / member
        if not path.exists():
            raise WorldPainterPackageError(f"Missing {member} in WorldPainter analysis package")
        return json.loads(path.read_text(encoding="utf-8"))
    if source.is_file() and source.suffix.lower() in {".zip", ".wglwp"}:
        with zipfile.ZipFile(source, "r") as archive:
            names = {name.replace("\\", "/"): name for name in archive.namelist()}
            actual = names.get(member)
            if actual is None:
                # Permit one wrapper directory.
                candidates = [name for key, name in names.items() if key.endswith("/" + member)]
                if len(candidates) == 1:
                    actual = candidates[0]
            if actual is None:
                raise WorldPainterPackageError(f"Missing {member} in {source.name}")
            return json.loads(archive.read(actual).decode("utf-8"))
    raise WorldPainterPackageError(f"Unsupported WorldPainter analysis source: {source}")


def load_worldpainter_package(source: Path) -> WorldPainterPackage:
    source = Path(source)
    info = _read_json_from_source(source, "world_info.json")
    schema = str(info.get("schema") or "")
    if schema not in {"worldgeolabs.worldpainter.v1", "worldgeolabs.worldpainter.v2"}:
        raise WorldPainterPackageError(
            f"Unsupported or missing WorldPainter package schema: {schema or '(none)'}"
        )
    dimensions_raw = info.get("dimensions") or []
    dimensions = tuple(
        WorldPainterDimension.from_mapping(item)
        for item in dimensions_raw
        if isinstance(item, Mapping)
    )
    if not dimensions:
        raise WorldPainterPackageError("WorldPainter package has no dimensions")

    materials: dict[str, Any] = {}
    layers: tuple[Mapping[str, Any], ...] = ()
    try:
        materials = _read_json_from_source(source, "materials.json")
    except WorldPainterPackageError:
        materials = {}
    try:
        layer_doc = _read_json_from_source(source, "layers.json")
        raw_layers = layer_doc.get("layers") if isinstance(layer_doc, Mapping) else []
        layers = tuple(item for item in (raw_layers or []) if isinstance(item, Mapping))
    except WorldPainterPackageError:
        layers = ()

    return WorldPainterPackage(
        source_path=source.resolve(),
        schema=schema,
        project_name=str(info.get("project_name") or source.stem),
        worldpainter_version=str(info.get("worldpainter_version") or "unknown"),
        dimensions=dimensions,
        materials=materials,
        layers=layers,
        metadata=dict(info.get("metadata") or {}),
    )
