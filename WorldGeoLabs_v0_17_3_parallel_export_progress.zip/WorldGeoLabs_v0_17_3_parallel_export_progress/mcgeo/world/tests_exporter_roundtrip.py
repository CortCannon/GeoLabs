from __future__ import annotations

import tempfile
from pathlib import Path

from .anvil_reader import AnvilWorld
from .dimensions import resolve_dimension_storage
from .exporter import IncrementalExportOptions, _rewrite_region_file, export_paint_layers_incremental
from .nbt import NbtTag, TAG_Byte, TAG_Compound, TAG_Int, TAG_List, TAG_String, write_nbt
from .region import RegionFile


def _sample_chunk_nbt() -> bytes:
    stone = {"Name": NbtTag(TAG_String, "minecraft:stone")}
    section = {
        "Y": NbtTag(TAG_Byte, 0),
        "block_states": NbtTag(TAG_Compound, {
            "palette": NbtTag(TAG_List, (TAG_Compound, [stone])),
        }),
        "biomes": NbtTag(TAG_Compound, {
            "palette": NbtTag(TAG_List, (TAG_String, ["minecraft:plains"])),
        }),
    }
    root = {
        "DataVersion": NbtTag(TAG_Int, 5000),
        "xPos": NbtTag(TAG_Int, 0),
        "zPos": NbtTag(TAG_Int, 0),
        "Status": NbtTag(TAG_String, "minecraft:full"),
        "sections": NbtTag(TAG_List, (TAG_Compound, [section])),
    }
    return write_nbt("", root)


def _make_world(root: Path, *, modern: bool = False) -> Path:
    world = root / ("SourceWorld26_2" if modern else "SourceWorldLegacy")
    if modern:
        region_dir = world / "dimensions" / "minecraft" / "overworld" / "region"
    else:
        region_dir = world / "region"
    region_dir.mkdir(parents=True)
    (world / "level.dat").write_bytes(b"synthetic-test-level")
    region = region_dir / "r.0.0.mca"
    region.write_bytes(b"\x00" * 8192)
    _rewrite_region_file(region, {0: _sample_chunk_nbt()})
    return world


def _read_block(world: Path, x: int, y: int, z: int) -> str:
    chunk = AnvilWorld(world).read_chunk(x >> 4, z >> 4)
    assert chunk is not None
    return chunk.get_block(x & 15, y, z & 15)


def _exercise_layout(base: Path, *, modern: bool) -> None:
    src = _make_world(base, modern=modern)
    dst = base / ("ExportedWorld26_2" if modern else "ExportedWorldLegacy")
    layers = [{
        "name": "Test Paint",
        "enabled": True,
        "preview_visible": True,
        "settings": {},
        "strokes": [{
            "action": "Replace blocks",
            "material": "minecraft:diamond_ore",
            "shape": "Sphere",
            "size_blocks": 1,
            "strength_pct": 100,
            "points": [[1.5, 1.5, 1.5]],
            "bbox": [1, 1, 1, 2, 2, 2],
        }],
    }]
    report = export_paint_layers_incremental(IncrementalExportOptions(
        world_path=src,
        paint_layers=layers,
        destination_mode="copy",
        destination_path=dst,
        verify_after_write=True,
    ))

    assert report.changed_blocks >= 1, report.summary_text()
    assert report.changed_chunks == 1, report.summary_text()
    assert report.changed_regions == 1, report.summary_text()
    assert report.verified_chunks == 1, report.summary_text()
    assert _read_block(src, 1, 1, 1) == "minecraft:stone"
    assert _read_block(dst, 1, 1, 1) == "minecraft:diamond_ore"
    assert src.joinpath("level.dat").read_bytes() == dst.joinpath("level.dat").read_bytes()

    s_stat = src.joinpath("level.dat").stat()
    d_stat = dst.joinpath("level.dat").stat()
    if getattr(s_stat, "st_ino", 0) and getattr(d_stat, "st_ino", 0):
        assert (s_stat.st_dev, s_stat.st_ino) != (d_stat.st_dev, d_stat.st_ino)

    storage = resolve_dimension_storage(dst)
    expected_layout = "minecraft-26.1+" if modern else "legacy"
    assert storage.layout == expected_layout, (storage.layout, expected_layout)
    with RegionFile(storage.region_dir / "r.0.0.mca") as reg:
        assert reg.has_chunk(0, 0)
        assert reg.read_chunk_nbt_bytes(0, 0) is not None


def run() -> None:
    with tempfile.TemporaryDirectory(prefix="wgl_export_test_") as td:
        base = Path(td)
        _exercise_layout(base / "legacy", modern=False)
        _exercise_layout(base / "modern", modern=True)
    print("Incremental exporter round-trip tests OK (legacy + Minecraft 26.2 layout)")


if __name__ == "__main__":
    run()
