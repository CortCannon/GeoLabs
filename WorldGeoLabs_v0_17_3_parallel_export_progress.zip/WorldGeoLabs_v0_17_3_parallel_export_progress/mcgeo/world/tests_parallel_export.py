from __future__ import annotations

import tempfile
from pathlib import Path

from .anvil_reader import AnvilWorld
from .exporter import IncrementalExportOptions, _rewrite_region_file, export_paint_layers_incremental
from .tests_exporter_roundtrip import _sample_chunk_nbt


def _make_multi_region_world(root: Path, count: int = 4) -> Path:
    world = root / "ParallelExportWorld"
    region_dir = world / "dimensions" / "minecraft" / "overworld" / "region"
    region_dir.mkdir(parents=True)
    (world / "level.dat").write_bytes(b"synthetic-test-level")
    for rx in range(count):
        region = region_dir / f"r.{rx}.0.mca"
        region.write_bytes(b"\x00" * 8192)
        _rewrite_region_file(region, {0: _sample_chunk_nbt()})
    return world


def run() -> None:
    with tempfile.TemporaryDirectory(prefix="wgl_parallel_export_") as td:
        root = Path(td)
        world = _make_multi_region_world(root, 4)
        strokes = []
        for rx in range(4):
            x = rx * 512 + 1.5
            strokes.append({
                "action": "Replace blocks",
                "material": "minecraft:gold_ore",
                "shape": "Sphere",
                "size_blocks": 1,
                "strength_pct": 100,
                "points": [[x, 1.5, 1.5]],
                "bbox": [int(x), 1, 1, int(x) + 1, 2, 2],
                "generated_geology": True,
            })
        layers = [{
            "name": "Parallel export test",
            "enabled": True,
            "preview_visible": True,
            "settings": {},
            "strokes": strokes,
        }]
        progress: list[tuple[int, str]] = []
        report = export_paint_layers_incremental(IncrementalExportOptions(
            world_path=world,
            paint_layers=layers,
            destination_mode="inplace",
            workers=4,
            verify_after_write=True,
            progress=lambda pct, msg: progress.append((int(pct), str(msg))),
        ))
        assert report.changed_regions == 4, report.summary_text()
        assert report.changed_chunks == 4, report.summary_text()
        assert report.verified_chunks == 4, report.summary_text()
        assert report.workers_used == 4, report.summary_text()
        assert progress and progress[-1][0] == 100, progress[-5:]
        assert any("Applying edits" in msg for _pct, msg in progress)
        reader = AnvilWorld(world)
        for rx in range(4):
            chunk = reader.read_chunk(rx * 32, 0)
            assert chunk is not None
            assert chunk.get_block(1, 1, 1) == "minecraft:gold_ore"

        # Safe-copy progress is byte-based and derived Distant Horizons caches
        # must not be copied into a terrain-modified export.
        copy_world = _make_multi_region_world(root / "copy_case", 1)
        data_dir = copy_world / "data"
        data_dir.mkdir(exist_ok=True)
        (data_dir / "DistantHorizons.sqlite").write_bytes(b"stale-derived-lod" * 100)
        copy_progress: list[tuple[int, str]] = []
        copy_dst = root / "CopyExport"
        copy_report = export_paint_layers_incremental(IncrementalExportOptions(
            world_path=copy_world,
            paint_layers=[{
                "name": "copy test",
                "enabled": True,
                "preview_visible": True,
                "settings": {},
                "strokes": [{
                    "action": "Replace blocks",
                    "material": "minecraft:iron_ore",
                    "shape": "Sphere",
                    "size_blocks": 1,
                    "strength_pct": 100,
                    "points": [[1.5, 1.5, 1.5]],
                    "bbox": [1, 1, 1, 2, 2, 2],
                }],
            }],
            destination_mode="copy",
            destination_path=copy_dst,
            workers=1,
            copy_workers=2,
            progress=lambda pct, msg: copy_progress.append((int(pct), str(msg))),
        ))
        assert copy_report.changed_blocks >= 1, copy_report.summary_text()
        assert not (copy_dst / "data" / "DistantHorizons.sqlite").exists()
        assert any("Copying world" in msg for _pct, msg in copy_progress), copy_progress
    print("Parallel exporter/progress test OK (4 independent region workers)")


if __name__ == "__main__":
    run()
