from __future__ import annotations

import tempfile
from pathlib import Path

from .anvil_reader import AnvilWorld
from .dimensions import resolve_dimension_storage
from .exporter import IncrementalExportOptions, export_paint_layers_incremental
from .region import probe_region_file
from .tests_exporter_roundtrip import _make_world
from ..analysis.engine import AnalysisOptions, GeologicalAnalyzer


def run() -> None:
    with tempfile.TemporaryDirectory(prefix="wgl_void_region_test_") as td:
        root = Path(td)
        world = _make_world(root, modern=True)
        storage = resolve_dimension_storage(world)
        region_dir = storage.region_dir

        # Simulate WorldPainter/Minecraft void-border artifacts.
        zero = region_dir / "r.2.-8.mca"
        zero.write_bytes(b"")
        header_only = region_dir / "r.-1.0.mca"
        header_only.write_bytes(b"\x00" * 8192)
        short = region_dir / "r.3.0.mca"
        short.write_bytes(b"bad")

        assert probe_region_file(zero).void
        assert probe_region_file(header_only).void
        assert not probe_region_file(short).usable

        chunks = list(AnvilWorld(world).iter_chunks((-32, 127, -256, 31), stride_chunks=1))
        assert len(chunks) == 1, len(chunks)
        assert (chunks[0].cx, chunks[0].cz) == (0, 0)

        # Whole-world analysis can span the placeholder border but must mask it.
        report = GeologicalAnalyzer(AnalysisOptions(
            world_path=world,
            chunk_bounds=(-32, 127, -256, 31),
            height_range=(0, 16),
            scope_name="void_border_smoke",
            requested_step=16,
            verification_step=16,
            source_mode="minecraft",
            force_rebuild=True,
        )).run()
        presence = report.summary.get("minecraft_presence") or {}
        assert int(presence.get("void_regions_ignored", 0)) >= 2, presence
        assert int(presence.get("void_regions_ignored", 0)) >= 3, presence
        assert int(presence.get("present_chunks", 0)) == 1, presence

        # An edit aimed entirely into a zero-byte border region must not create
        # terrain or modify the placeholder file.
        dst = root / "ExportVoidTest"
        layers = [{
            "name": "Void edit",
            "enabled": True,
            "preview_visible": True,
            "settings": {},
            "strokes": [{
                "action": "Replace blocks",
                "material": "minecraft:gold_ore",
                "shape": "Sphere",
                "size_blocks": 4,
                "strength_pct": 100,
                "points": [[2 * 32 * 16 + 8, 8, -8 * 32 * 16 + 8]],
                "bbox": [2 * 32 * 16, 0, -8 * 32 * 16, 2 * 32 * 16 + 15, 15, -8 * 32 * 16 + 15],
                "generated_geology": True,
            }],
        }]
        result = export_paint_layers_incremental(IncrementalExportOptions(
            world_path=world,
            paint_layers=layers,
            destination_mode="copy",
            destination_path=dst,
            verify_after_write=True,
        ))
        dst_zero = resolve_dimension_storage(dst).region_dir / "r.2.-8.mca"
        assert dst_zero.is_file() and dst_zero.stat().st_size == 0
        assert result.changed_blocks == 0

    print("Void-border region handling test OK")


if __name__ == "__main__":
    run()
