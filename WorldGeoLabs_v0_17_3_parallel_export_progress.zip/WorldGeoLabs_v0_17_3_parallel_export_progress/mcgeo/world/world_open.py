from __future__ import annotations
import logging
import os
import re
import gzip
import json
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Tuple, List, Optional

from PySide6 import QtCore

from .nbt import read_nbt, TAG_Compound, TAG_List, TAG_String
from .region import RegionFile, probe_region_file
from .dimensions import resolve_dimension_storage

log = logging.getLogger("mcgeo.world.open")

REGION_RE = re.compile(r"r\.(?P<rx>-?\d+)\.(?P<rz>-?\d+)\.mca$")


@dataclass(frozen=True)
class WorldIndex:
    world_path: Path
    region_dir: Path
    chunk_bounds: Tuple[int, int, int, int]     # min_cx,max_cx,min_cz,max_cz
    height_range: Tuple[int, int]               # min_y,max_y
    spawn_chunk: Tuple[int, int]                # cx,cz
    spawn_block: Tuple[int, int, int]           # x,y,z
    dimension_id: str = "minecraft:overworld"
    dimension_path: Path | None = None
    storage_layout: str = "legacy"
    region_files_total: int = 0
    region_files_usable: int = 0
    region_files_void: int = 0
    region_files_invalid: int = 0
    present_chunk_count: int = 0


class WorldIndexer(QtCore.QObject):
    progress = QtCore.Signal(str)
    finished = QtCore.Signal(object)  # WorldIndex
    failed = QtCore.Signal(str)

    def __init__(self) -> None:
        super().__init__()
        self._thread: QtCore.QThread | None = None
        self._worker: _IndexWorker | None = None  # keep a strong ref (Qt thread worker GC bug)

    def start_index(self, world_path: Path) -> None:
        if self._thread and self._thread.isRunning():
            self._thread.quit()
            self._thread.wait(1000)

        self._thread = QtCore.QThread()
        self._worker = _IndexWorker(world_path)
        self._worker.moveToThread(self._thread)

        self._worker.progress.connect(self.progress)
        self._worker.finished.connect(self._thread.quit)
        self._worker.finished.connect(self.finished)
        self._worker.failed.connect(self._thread.quit)
        self._worker.failed.connect(self.failed)

        # cleanup refs when thread ends
        self._thread.finished.connect(self._on_thread_finished)

        self._thread.started.connect(self._worker.run)
        self._thread.start()

    @QtCore.Slot()
    def _on_thread_finished(self) -> None:
        self._worker = None


class _IndexWorker(QtCore.QObject):
    progress = QtCore.Signal(str)
    finished = QtCore.Signal(object)  # WorldIndex
    failed = QtCore.Signal(str)

    def __init__(self, world_path: Path) -> None:
        super().__init__()
        self.world_path = Path(world_path).expanduser().resolve()

    @QtCore.Slot()
    def run(self) -> None:
        try:
            self.progress.emit("Scanning world…")

            storage = resolve_dimension_storage(self.world_path, "minecraft:overworld")
            region_dir = storage.region_dir
            self.progress.emit(
                f"Using {storage.dimension_id} storage ({storage.layout}): "
                f"{storage.region_dir.relative_to(self.world_path)}"
            )

            region_files: List[Path] = []
            total_region_files = 0
            void_region_files = 0
            invalid_region_files = 0
            present_chunk_count = 0
            min_cx = min_cz = 10**12
            max_cx = max_cz = -10**12

            # Minecraft/WorldPainter can leave zero-byte or header-only .mca
            # placeholders around a void border.  Index the *actual chunk slots*
            # instead of using region filenames as world bounds.
            for p in region_dir.glob("r.*.*.mca"):
                m = REGION_RE.fullmatch(p.name)
                if not m:
                    continue
                total_region_files += 1
                rx = int(m.group("rx"))
                rz = int(m.group("rz"))
                probe = probe_region_file(p)
                if not probe.usable:
                    if probe.void:
                        void_region_files += 1
                    else:
                        invalid_region_files += 1
                        log.warning("Ignoring unusable region %s: %s", p, probe.message or probe.status)
                    continue
                region_files.append(p)
                present_chunk_count += len(probe.present_chunks)
                for lx, lz in probe.present_chunks:
                    cx = rx * 32 + int(lx)
                    cz = rz * 32 + int(lz)
                    min_cx = min(min_cx, cx)
                    max_cx = max(max_cx, cx)
                    min_cz = min(min_cz, cz)
                    max_cz = max(max_cz, cz)

            if not region_files or present_chunk_count <= 0:
                raise RuntimeError(
                    f"No usable terrain chunks found for {storage.dimension_id} in {region_dir}. "
                    f"Ignored {void_region_files} void and {invalid_region_files} invalid region file(s)."
                )

            self.progress.emit(
                f"Found {len(region_files)} usable region files / {present_chunk_count:,} chunks; "
                f"ignored {void_region_files} void and {invalid_region_files} invalid region file(s). Reading level.dat…"
            )

            spawn_chunk, spawn_block, level_data = self._read_level_dat_info()

            # Respect custom/tall-world vertical limits instead of forcing the
            # vanilla 1.18+ range.  The rest of the editor clamps cursor motion,
            # voxel picking, cut planes, and preview bounds to this tuple, so a
            # bad default here makes free 3D painting feel locked to -64..320
            # even when the renderer is displaying taller chunk sections.
            min_y, max_y = self._detect_height_range(level_data, region_files, spawn_chunk)

            wi = WorldIndex(
                world_path=self.world_path,
                region_dir=region_dir,
                chunk_bounds=(min_cx, max_cx, min_cz, max_cz),
                height_range=(min_y, max_y),
                spawn_chunk=spawn_chunk,
                spawn_block=spawn_block,
                dimension_id=storage.dimension_id,
                dimension_path=storage.dimension_path,
                storage_layout=storage.layout,
                region_files_total=total_region_files,
                region_files_usable=len(region_files),
                region_files_void=void_region_files,
                region_files_invalid=invalid_region_files,
                present_chunk_count=present_chunk_count,
            )
            self.finished.emit(wi)
        except Exception as e:
            log.exception("World index failed")
            self.failed.emit(str(e))

    def _read_level_dat_info(self) -> Tuple[Tuple[int, int], Tuple[int, int, int], Optional[dict]]:
        level_dat = self.world_path / "level.dat"
        if not level_dat.exists():
            return ((0, 0), (0, 80, 0), None)
        try:
            raw = level_dat.read_bytes()
            # Java level.dat is gzipped NBT
            data = gzip.decompress(raw)
            root = read_nbt(data).value
            data_tag = root.get("Data")
            if not data_tag or data_tag.tag_id != TAG_Compound:
                return ((0, 0), (0, 80, 0), None)
            d = data_tag.value
            sx = int(d.get("SpawnX").value) if d.get("SpawnX") else 0
            sy = int(d.get("SpawnY").value) if d.get("SpawnY") else 80
            sz = int(d.get("SpawnZ").value) if d.get("SpawnZ") else 0
            return ((sx // 16, sz // 16), (sx, sy, sz), d)
        except Exception:
            return ((0, 0), (0, 80, 0), None)

    def _read_world_gen_settings_info(self) -> Optional[dict]:
        """Read the 26.1+ world generation settings file when present.

        Mojang moved ``WorldGenSettings`` out of level.dat in Java 26.1.
        Vanilla stores it at data/minecraft/world_gen_settings.dat.  Some
        server implementations briefly placed a copy under the Overworld
        dimension, so accept that location as a compatibility fallback too.
        """
        candidates = [
            self.world_path / "data" / "minecraft" / "world_gen_settings.dat",
            self.world_path / "dimensions" / "minecraft" / "overworld" / "data" / "minecraft" / "world_gen_settings.dat",
        ]
        for path in candidates:
            if not path.is_file():
                continue
            try:
                raw = path.read_bytes()
                try:
                    raw = gzip.decompress(raw)
                except OSError:
                    pass
                root = read_nbt(raw).value
                # Data files may be wrapped by Data/data or may store the
                # payload directly at the root. Return the most useful compound.
                for key in ("Data", "data", "WorldGenSettings", "world_gen_settings"):
                    tag = root.get(key)
                    if tag is not None and getattr(tag, "tag_id", None) == TAG_Compound:
                        root = tag.value
                        break
                log.info("Read Minecraft 26.1+ world gen settings from %s", path)
                return root
            except Exception:
                log.warning("Could not read world generation settings: %s", path, exc_info=True)
        return None

    def _read_spawn(self) -> Tuple[Tuple[int, int], Tuple[int, int, int]]:
        spawn_chunk, spawn_block, _level_data = self._read_level_dat_info()
        return spawn_chunk, spawn_block

    def _detect_height_range(
        self,
        level_data: Optional[dict],
        region_files: List[Path],
        spawn_chunk: Tuple[int, int],
    ) -> Tuple[int, int]:
        """Return editor vertical limits as (min_y, max_y_exclusive_style).

        Tall Minecraft worlds usually declare their vertical build limits in a
        datapack dimension type JSON, not directly in ``level.dat``.  Scan the
        active world/datapacks folder generically before falling back to chunk
        section inference so WorldPainter/custom worlds are not clamped to
        vanilla ``-64..320``.
        """
        # User override for unusual datapack worlds when metadata cannot be
        # found.  This is also useful for debugging a broken exporter.
        env_min = os.environ.get("WGL_WORLD_MIN_Y")
        env_max = os.environ.get("WGL_WORLD_MAX_Y")
        try:
            if env_min is not None and env_max is not None:
                mn, mx = int(env_min), int(env_max)
                if mx > mn:
                    log.info("World height range from WGL_WORLD_MIN_Y/MAX_Y: %s..%s", mn, mx)
                    return (mn, mx)
        except Exception:
            log.warning("Ignoring invalid WGL_WORLD_MIN_Y/MAX_Y override", exc_info=True)

        external_worldgen = self._read_world_gen_settings_info()
        from_external = self._height_range_from_level_dat(external_worldgen)
        if from_external is not None and self._is_custom_height_range(from_external):
            log.info("World height range from 26.1+ world_gen_settings.dat: %s..%s", from_external[0], from_external[1])
            return from_external

        from_level = self._height_range_from_level_dat(level_data)
        # Inline dimension compounds in older level.dat files are authoritative
        # when they describe a custom/tall height. If metadata only tells us
        # vanilla limits, still check datapacks because they can override the
        # built-in overworld dimension type.
        if from_level is not None and self._is_custom_height_range(from_level):
            log.info("World height range from level.dat custom dimension metadata: %s..%s", from_level[0], from_level[1])
            return from_level

        # For 26.1+, use references from world_gen_settings.dat when matching
        # custom datapack dimension types.
        reference_data = external_worldgen or level_data
        from_datapacks = self._height_range_from_datapacks(reference_data)
        if from_datapacks is not None:
            log.info("World height range from world datapack dimension_type JSON: %s..%s", from_datapacks[0], from_datapacks[1])
            return from_datapacks

        if from_external is not None:
            log.info("World height range from 26.1+ world_gen_settings.dat: %s..%s", from_external[0], from_external[1])
            return from_external

        if from_level is not None:
            log.info("World height range from level.dat dimension metadata: %s..%s", from_level[0], from_level[1])
            return from_level

        from_sections = self._height_range_from_chunk_sections(region_files, spawn_chunk)
        if from_sections is not None:
            log.info("World height range inferred from chunk sections: %s..%s", from_sections[0], from_sections[1])
            return from_sections

        log.info("World height range fallback: -64..320")
        return (-64, 320)

    @staticmethod
    def _is_custom_height_range(hr: Tuple[int, int]) -> bool:
        # Treat anything beyond modern vanilla 1.18+ as custom/tall.  Vanilla or
        # old vanilla-sized worlds can still be overridden by datapacks below.
        return int(hr[0]) < -64 or int(hr[1]) > 320

    def _height_range_from_level_dat(self, data: Optional[dict]) -> Optional[Tuple[int, int]]:
        if not data:
            return None

        def as_comp(v):
            return v.value if v is not None and getattr(v, "tag_id", None) == TAG_Compound else None

        def int_value(comp: dict, key: str) -> Optional[int]:
            tag = comp.get(key) if comp else None
            if tag is None:
                return None
            try:
                return int(tag.value)
            except Exception:
                return None

        # Modern level.dat can inline a custom dimension type here:
        # Data/WorldGenSettings/dimensions/minecraft:overworld/type/{min_y,height}
        wgs = as_comp(data.get("WorldGenSettings"))
        if wgs is None and as_comp(data.get("world_gen_settings")) is not None:
            wgs = as_comp(data.get("world_gen_settings"))
        # Minecraft 26.1+ world_gen_settings.dat stores the old payload as a
        # standalone data file, so dimensions may be directly on the root.
        if wgs is None and as_comp(data.get("dimensions")) is not None:
            wgs = data
        dims = as_comp(wgs.get("dimensions")) if wgs else None
        overworld = as_comp(dims.get("minecraft:overworld")) if dims else None
        dtype = overworld.get("type") if overworld else None
        dtype_comp = as_comp(dtype)
        if dtype_comp:
            mn = int_value(dtype_comp, "min_y")
            h = int_value(dtype_comp, "height")
            if mn is not None and h is not None and h > 0:
                return (int(mn), int(mn + h))

        # Be permissive for exporter/datapack variants that copy vertical limits
        # directly onto one of the dimension/worldgen compounds.
        for comp in (data, wgs, overworld):
            if not comp:
                continue
            mn = int_value(comp, "min_y")
            h = int_value(comp, "height")
            mx = int_value(comp, "max_y") or int_value(comp, "logical_height")
            if mn is not None and h is not None and h > 0:
                return (int(mn), int(mn + h))
            if mn is not None and mx is not None and mx > mn:
                return (int(mn), int(mx))

        return None


    def _height_range_from_datapacks(self, level_data: Optional[dict]) -> Optional[Tuple[int, int]]:
        """Read min_y/height from any world datapack dimension_type JSON.

        Supports both folder datapacks and zipped datapacks, with or without a
        root folder inside the zip.  It does not assume the pack name or
        namespace; it looks for any ``data/<namespace>/dimension_type/*.json``.
        If level.dat references a specific dimension type, prefer that ID.  If
        not, prefer an overworld-looking type, then any non-vanilla/tall type.
        """
        datapacks_dir = self.world_path / "datapacks"
        if not datapacks_dir.exists() or not datapacks_dir.is_dir():
            return None

        records: dict[str, Tuple[int, int, str]] = {}

        for item in sorted(datapacks_dir.iterdir(), key=lambda p: p.name.lower()):
            try:
                if item.is_dir():
                    for json_path in item.rglob("*.json"):
                        rec = self._dimension_type_record_from_parts(json_path.parts, lambda: json_path.read_text(encoding="utf-8"))
                        if rec:
                            dtype_id, height_range = rec
                            records[dtype_id] = (height_range[0], height_range[1], str(json_path))
                elif item.is_file() and item.suffix.lower() == ".zip":
                    with zipfile.ZipFile(item, "r") as zf:
                        for name in zf.namelist():
                            if not name.lower().endswith(".json"):
                                continue
                            parts = tuple(Path(name).parts)
                            rec = self._dimension_type_record_from_parts(
                                parts,
                                lambda zf=zf, name=name: zf.read(name).decode("utf-8", errors="replace"),
                            )
                            if rec:
                                dtype_id, height_range = rec
                                records[dtype_id] = (height_range[0], height_range[1], f"{item}!{name}")
            except Exception:
                log.warning("Could not inspect datapack for height range: %s", item, exc_info=True)

        if not records:
            return None

        wanted = self._dimension_type_references_from_level_dat(level_data)
        for dtype_id in wanted:
            rec = records.get(dtype_id)
            if rec:
                log.info("Matched level.dat dimension type %s in %s", dtype_id, rec[2])
                return (rec[0], rec[1])

        # Most WorldPainter/tall-world packs override minecraft:overworld.
        for dtype_id in ("minecraft:overworld", "overworld"):
            rec = records.get(dtype_id)
            if rec:
                log.info("Using overworld datapack dimension type %s from %s", dtype_id, rec[2])
                return (rec[0], rec[1])

        overworldish = [
            (dtype_id, rec) for dtype_id, rec in records.items()
            if "overworld" in dtype_id.lower()
        ]
        if overworldish:
            dtype_id, rec = sorted(overworldish, key=lambda x: x[0])[0]
            log.info("Using overworld-like datapack dimension type %s from %s", dtype_id, rec[2])
            return (rec[0], rec[1])

        custom = [
            (dtype_id, rec) for dtype_id, rec in records.items()
            if self._is_custom_height_range((rec[0], rec[1]))
        ]
        if custom:
            # If there are multiple custom dimension types, prefer the tallest
            # one because the editor needs enough vertical room to avoid cursor
            # clamps in tall worlds.
            dtype_id, rec = sorted(custom, key=lambda x: (x[1][1] - x[1][0], x[0]), reverse=True)[0]
            log.info("Using custom/tall datapack dimension type %s from %s", dtype_id, rec[2])
            return (rec[0], rec[1])

        return None

    def _dimension_type_record_from_parts(
        self,
        parts: Tuple[str, ...],
        read_text,
    ) -> Optional[Tuple[str, Tuple[int, int]]]:
        # Accept both direct datapack layout:
        #   data/<namespace>/dimension_type/<path>.json
        # and zip/folder layouts with a wrapper directory before data/.
        lowered = [p.lower() for p in parts]
        for i, part in enumerate(lowered):
            if part != "data":
                continue
            if i + 3 >= len(parts):
                continue
            namespace = parts[i + 1]
            if lowered[i + 2] != "dimension_type":
                continue
            rel_path_parts = parts[i + 3:]
            if not rel_path_parts:
                continue
            rel = "/".join(rel_path_parts)
            if not rel.lower().endswith(".json"):
                continue
            dtype_path = rel[:-5].replace("\\", "/")
            dtype_id = f"{namespace}:{dtype_path}"
            try:
                data = json.loads(read_text())
            except Exception:
                log.warning("Could not parse dimension_type JSON: %s", "/".join(parts), exc_info=True)
                return None
            hr = self._height_range_from_dimension_json(data)
            if hr is None:
                return None
            return (dtype_id, hr)
        return None

    def _height_range_from_dimension_json(self, data: object) -> Optional[Tuple[int, int]]:
        if not isinstance(data, dict):
            return None
        try:
            mn = int(data["min_y"])
        except Exception:
            return None

        # Minecraft dimension_type height is the vertical span.  max_y is
        # exclusive in the app status/clamp convention, matching -512..2032.
        h = data.get("height")
        if h is not None:
            try:
                height = int(h)
                if height > 0:
                    return (mn, mn + height)
            except Exception:
                pass

        # Some generators/exporters include logical_height or max_y.  In the
        # official format logical_height is not max_y by itself, but many custom
        # exports use it as the vertical span alongside min_y.  Treat it as a
        # span when it is larger than zero and would exceed min_y.
        logical = data.get("logical_height")
        if logical is not None:
            try:
                logical_i = int(logical)
                if logical_i > 0:
                    return (mn, mn + logical_i)
            except Exception:
                pass

        mx = data.get("max_y")
        if mx is not None:
            try:
                mx_i = int(mx)
                if mx_i > mn:
                    return (mn, mx_i)
            except Exception:
                pass
        return None

    def _dimension_type_references_from_level_dat(self, data: Optional[dict]) -> List[str]:
        if not data:
            return []

        def as_comp(v):
            return v.value if v is not None and getattr(v, "tag_id", None) == TAG_Compound else None

        out: List[str] = []
        wgs = as_comp(data.get("WorldGenSettings"))
        if wgs is None and as_comp(data.get("world_gen_settings")) is not None:
            wgs = as_comp(data.get("world_gen_settings"))
        # Minecraft 26.1+ world_gen_settings.dat stores the old payload as a
        # standalone data file, so dimensions may be directly on the root.
        if wgs is None and as_comp(data.get("dimensions")) is not None:
            wgs = data
        dims = as_comp(wgs.get("dimensions")) if wgs else None
        if not dims:
            return out
        for _dim_id, dim_tag in dims.items():
            dim = as_comp(dim_tag)
            if not dim:
                continue
            t = dim.get("type")
            if t is not None and getattr(t, "tag_id", None) == TAG_String:
                ref = str(t.value)
                if ":" not in ref:
                    ref = f"minecraft:{ref}"
                if ref not in out:
                    out.append(ref)
        return out

    def _height_range_from_chunk_sections(
        self,
        region_files: List[Path],
        spawn_chunk: Tuple[int, int],
    ) -> Optional[Tuple[int, int]]:
        # Full-height custom worlds can be huge, so avoid decoding every chunk
        # during indexing.  Scan nearby regions first and cap chunk reads.
        try:
            max_chunks = max(1, int(os.environ.get("WGL_HEIGHT_SCAN_CHUNKS", "768")))
        except Exception:
            max_chunks = 768

        def region_coords(path: Path) -> Tuple[int, int]:
            m = REGION_RE.fullmatch(path.name)
            if not m:
                return (0, 0)
            return (int(m.group("rx")), int(m.group("rz")))

        sr_x, sr_z = int(spawn_chunk[0]) >> 5, int(spawn_chunk[1]) >> 5
        ordered = sorted(
            region_files,
            key=lambda p: (abs(region_coords(p)[0] - sr_x) + abs(region_coords(p)[1] - sr_z), p.name),
        )

        min_sy: Optional[int] = None
        max_sy: Optional[int] = None
        scanned = 0
        for rp in ordered:
            if scanned >= max_chunks:
                break
            try:
                with RegionFile(rp) as reg:
                    for czr in range(32):
                        for cxr in range(32):
                            if scanned >= max_chunks:
                                break
                            if not reg.has_chunk(cxr, czr):
                                continue
                            raw = reg.read_chunk_nbt_bytes(cxr, czr)
                            scanned += 1
                            if raw is None:
                                continue
                            try:
                                root = read_nbt(raw).value
                                data = root.get("Level").value if "Level" in root and root["Level"].tag_id == TAG_Compound else root
                                sections_tag = data.get("sections") or data.get("Sections")
                                if not sections_tag or sections_tag.tag_id != TAG_List:
                                    continue
                                _elem_id, sections_list = sections_tag.value
                                for sec_comp in sections_list:
                                    y_tag = sec_comp.get("Y") or sec_comp.get("y")
                                    if not y_tag:
                                        continue
                                    sy = int(y_tag.value)
                                    min_sy = sy if min_sy is None else min(min_sy, sy)
                                    max_sy = sy if max_sy is None else max(max_sy, sy)
                            except Exception:
                                continue
                        if scanned >= max_chunks:
                            break
            except Exception:
                continue

        if min_sy is None or max_sy is None:
            return None

        mn = int(min_sy) * 16
        mx = (int(max_sy) + 1) * 16

        # If chunk scanning only sees a vanilla-ish subset, keep the normal
        # fallback. If it sees wider sections, use them. This avoids shrinking
        # old worlds with sparse section data.
        if mn < -64 or mx > 320:
            return (mn, mx)
        return None
