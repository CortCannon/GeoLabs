from __future__ import annotations
import logging
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Dict, List, Tuple

from .region import RegionFile, RegionError, probe_region_file
from .dimensions import resolve_dimension_storage
from .nbt import read_nbt, NbtTag, TAG_Compound, TAG_List, TAG_String, TAG_Byte, TAG_Long_Array
from .blockstates_decode import decode_blockstates
from .palette import canonical_state, is_air

log = logging.getLogger("mcgeo.world")

@dataclass
class SectionModel:
    y: int
    palette: List[str]              # canonical state strings
    indices: List[int]              # 4096 palette indices

@dataclass
class ChunkModel:
    cx: int
    cz: int
    sections: Dict[int, SectionModel]  # key: section Y
    _surface_cache: Optional[List[Tuple[int, str]]] = None

    def _build_surface_cache(self) -> List[Tuple[int, str]]:
        cache: List[Tuple[int, str]] = [(0, "minecraft:air")] * 256
        if not self.sections:
            return cache
        top_sy = max(self.sections.keys())
        bot_sy = min(self.sections.keys())
        for z in range(16):
            for x in range(16):
                found_y = 0
                found_name = "minecraft:air"
                found = False
                for sy in range(top_sy, bot_sy - 1, -1):
                    sec = self.sections.get(sy)
                    if sec is None:
                        continue
                    for ly in range(15, -1, -1):
                        y = sy * 16 + ly
                        idx = (ly * 16 + (z & 15)) * 16 + (x & 15)
                        pi = sec.indices[idx]
                        if pi < 0 or pi >= len(sec.palette):
                            continue
                        name = sec.palette[pi].split("[", 1)[0]
                        if not is_air(name):
                            found_y = y
                            found_name = name
                            found = True
                            break
                    if found:
                        break
                cache[(z & 15) * 16 + (x & 15)] = (int(found_y), str(found_name))
        return cache

    def get_surface_block_cached(self, x: int, z: int) -> Tuple[int, str]:
        cache = self._surface_cache
        if cache is None:
            cache = self._build_surface_cache()
            self._surface_cache = cache
        return cache[(z & 15) * 16 + (x & 15)]

    def get_block(self, x: int, y: int, z: int) -> str:
        sy = y // 16
        sec = self.sections.get(sy)
        if sec is None:
            return "minecraft:air"
        ly = y & 15
        idx = (ly * 16 + (z & 15)) * 16 + (x & 15)  # YZX order (deterministic)
        pi = sec.indices[idx]
        if 0 <= pi < len(sec.palette):
            return sec.palette[pi].split("[", 1)[0]  # base name for color lookup
        return "minecraft:air"

    def find_surface_block(self, x: int, z: int) -> Tuple[int, str]:
        return self.get_surface_block_cached(x, z)

    def find_surface_block_direct(self, x: int, z: int) -> Tuple[int, str]:
        """Find one surface column without building the 256-column cache.

        Whole-world analysis often samples only one X/Z position from a chunk.
        Building the normal render-oriented surface cache in that case performs
        ~256x more column work than necessary.
        """
        if not self.sections:
            return (0, "minecraft:air")
        for sy in range(max(self.sections), min(self.sections) - 1, -1):
            sec = self.sections.get(sy)
            if sec is None:
                continue
            for ly in range(15, -1, -1):
                idx = (ly * 16 + (z & 15)) * 16 + (x & 15)
                pi = sec.indices[idx]
                if 0 <= pi < len(sec.palette):
                    name = sec.palette[pi].split("[", 1)[0]
                    if not is_air(name):
                        return (sy * 16 + ly, name)
        return (0, "minecraft:air")

class AnvilWorld:
    def __init__(self, world_path: Path, dimension_id: str = "minecraft:overworld") -> None:
        self.world_path = Path(world_path).expanduser().resolve()
        self.dimension = resolve_dimension_storage(self.world_path, dimension_id)
        self.dimension_id = self.dimension.dimension_id
        self.dimension_path = self.dimension.dimension_path
        self.region_dir = self.dimension.region_dir
        self._region_probe_cache = {}

    def _region_path(self, cx: int, cz: int) -> Path:
        rx = cx >> 5
        rz = cz >> 5
        return self.region_dir / f"r.{rx}.{rz}.mca"

    def _probe_region(self, path: Path):
        path = Path(path)
        probe = self._region_probe_cache.get(path)
        if probe is None:
            probe = probe_region_file(path)
            self._region_probe_cache[path] = probe
        return probe

    def read_chunk(
        self, cx: int, cz: int, *, section_range: Optional[Tuple[int, int]] = None
    ) -> Optional[ChunkModel]:
        """Read one chunk column.

        ``section_range`` is an editor-performance hint expressed in Minecraft
        section Y coordinates.  Region compression/NBT still has to be decoded as
        one chunk payload, but block-state palettes outside the requested vertical
        work volume are skipped.  On very tall worlds this avoids expanding every
        16-block section into a 4096-entry Python index array just to render a
        small detailed box.
        """
        rp = self._region_path(cx, cz)
        if not rp.exists():
            return None
        probe = self._probe_region(rp)
        if not probe.usable or (cx & 31, cz & 31) not in probe.present_chunks:
            return None
        cxr = cx & 31
        czr = cz & 31
        try:
            with RegionFile(rp) as reg:
                raw = reg.read_chunk_nbt_bytes(cxr, czr)
        except (RegionError, OSError):
            return None
        if raw is None:
            return None
        return self.decode_chunk_bytes(raw, cx, cz, section_range=section_range)

    def decode_chunk_bytes(
        self, raw: bytes, cx: int, cz: int, *, section_range: Optional[Tuple[int, int]] = None
    ) -> ChunkModel:
        """Decode one uncompressed chunk NBT payload.

        Kept separate so analysis and export passes can hold a region file open
        and decode many chunks without reopening the same .mca file 1024 times.
        """
        root = read_nbt(raw).value  # compound dict[str,NbtTag]

        # Modern chunks often store data at root; some have a 'Level' compound.
        data = root.get("Level").value if "Level" in root and root["Level"].tag_id == TAG_Compound else root

        # xPos/zPos might exist; ignore if missing.
        sections_tag = data.get("sections") or data.get("Sections")
        if not sections_tag or sections_tag.tag_id != TAG_List:
            return ChunkModel(cx, cz, {})

        elem_id, sections_list = sections_tag.value
        # sections_list is list of compound dicts
        sections: Dict[int, SectionModel] = {}
        wanted_sections = None
        if section_range is not None:
            wanted_sections = tuple(sorted((int(section_range[0]), int(section_range[1]))))
        for sec_comp in sections_list:
            # sec_comp is dict[str,NbtTag]
            y_tag = sec_comp.get("Y") or sec_comp.get("y")
            if not y_tag:
                continue
            y = int(y_tag.value)
            if wanted_sections is not None and not (wanted_sections[0] <= y <= wanted_sections[1]):
                # The NBT payload has already been parsed, but the expensive
                # palette canonicalisation + 4096 block-state expansion is not
                # needed outside the active Detailed Edit volume.
                continue
            bs = sec_comp.get("block_states") or sec_comp.get("BlockStates")
            if not bs or bs.tag_id != TAG_Compound:
                continue
            bs_comp = bs.value

            pal_tag = bs_comp.get("palette") or bs_comp.get("Palette")
            if not pal_tag or pal_tag.tag_id != TAG_List:
                continue
            _, pal_list = pal_tag.value

            palette: List[str] = []
            for p in pal_list:
                # p is dict[str,NbtTag]
                name = p.get("Name").value if p.get("Name") else "minecraft:air"
                props_tag = p.get("Properties")
                props = None
                if props_tag and props_tag.tag_id == TAG_Compound:
                    props = {k: v.value for k, v in props_tag.value.items()}
                palette.append(canonical_state(name, props))

            data_tag = bs_comp.get("data") or bs_comp.get("Data")
            if not data_tag:
                indices = [0] * 4096
            else:
                if data_tag.tag_id != TAG_Long_Array:
                    indices = [0] * 4096
                else:
                    indices = decode_blockstates(list(data_tag.value), len(palette))

            sections[y] = SectionModel(y=y, palette=palette, indices=indices)

        return ChunkModel(cx, cz, sections)
    def iter_chunks(
        self,
        bounds: Tuple[int, int, int, int],
        *,
        stride_chunks: int = 1,
    ):
        """Yield decoded chunks while opening each region file only once.

        ``stride_chunks`` is measured in chunk columns and is intended for
        whole-map geological verification scans.
        """
        min_cx, max_cx, min_cz, max_cz = (int(v) for v in bounds)
        stride = max(1, int(stride_chunks))
        min_rx, max_rx = min_cx >> 5, max_cx >> 5
        min_rz, max_rz = min_cz >> 5, max_cz >> 5

        for rz in range(min_rz, max_rz + 1):
            for rx in range(min_rx, max_rx + 1):
                region_path = self.region_dir / f"r.{rx}.{rz}.mca"
                if not region_path.is_file():
                    continue
                probe = self._probe_region(region_path)
                if not probe.usable:
                    continue
                present = set(probe.present_chunks)
                try:
                    with RegionFile(region_path) as region:
                        region_min_cx = max(min_cx, rx * 32)
                        region_max_cx = min(max_cx, rx * 32 + 31)
                        region_min_cz = max(min_cz, rz * 32)
                        region_max_cz = min(max_cz, rz * 32 + 31)
                        for cz in range(region_min_cz, region_max_cz + 1):
                            if (cz - min_cz) % stride:
                                continue
                            for cx in range(region_min_cx, region_max_cx + 1):
                                if (cx - min_cx) % stride:
                                    continue
                                if (cx & 31, cz & 31) not in present:
                                    continue
                                try:
                                    raw = region.read_chunk_nbt_bytes(cx & 31, cz & 31)
                                except RegionError:
                                    continue
                                if raw is None:
                                    continue
                                yield self.decode_chunk_bytes(raw, cx, cz)
                except (RegionError, OSError):
                    # Empty/short/corrupt border regions are treated as void.
                    continue
