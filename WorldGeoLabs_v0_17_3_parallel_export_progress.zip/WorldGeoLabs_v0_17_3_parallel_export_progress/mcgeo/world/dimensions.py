from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True, slots=True)
class DimensionStorage:
    """Resolved on-disk storage for one Minecraft Java dimension.

    Minecraft Java 26.1 moved the three vanilla dimensions into the namespaced
    ``dimensions/<namespace>/<path>`` tree.  Older worlds keep the Overworld at
    the world root and the Nether/End in DIM-1/DIM1.  WorldGeoLabs accepts both
    layouts and keeps the selected dimension explicit so readers/writers never
    have to guess a ``region`` path after the world has been opened.
    """

    world_path: Path
    dimension_id: str
    dimension_path: Path
    region_dir: Path
    entities_dir: Path
    poi_dir: Path
    layout: str  # minecraft-26.1+ | legacy | direct-dimension

    @property
    def region_relative_path(self) -> Path:
        return self.region_dir.relative_to(self.world_path)


def _normalize_dimension_id(dimension_id: str | None) -> str:
    text = str(dimension_id or "minecraft:overworld").strip()
    if ":" not in text:
        text = f"minecraft:{text}"
    namespace, path = text.split(":", 1)
    namespace = namespace.strip() or "minecraft"
    path = path.strip().strip("/").replace("\\", "/") or "overworld"
    return f"{namespace}:{path}"


def _new_dimension_path(world_path: Path, dimension_id: str) -> Path:
    namespace, path = _normalize_dimension_id(dimension_id).split(":", 1)
    return world_path / "dimensions" / namespace / Path(*path.split("/"))


def _legacy_dimension_path(world_path: Path, dimension_id: str) -> Path | None:
    dim = _normalize_dimension_id(dimension_id)
    if dim == "minecraft:overworld":
        return world_path
    if dim == "minecraft:the_nether":
        return world_path / "DIM-1"
    if dim == "minecraft:the_end":
        return world_path / "DIM1"
    return None


def resolve_dimension_storage(
    world_path: Path,
    dimension_id: str = "minecraft:overworld",
    *,
    require_region: bool = True,
) -> DimensionStorage:
    """Resolve a dimension without hard-coding pre-26.1 world paths.

    Preference order:
      1. Minecraft 26.1+ namespaced dimension tree.
      2. Legacy vanilla paths.
      3. A directly supplied dimension folder containing ``region``.

    The third form is mainly diagnostic/convenience behavior; normal UI usage
    should pass the save root containing ``level.dat``.
    """

    world = Path(world_path).expanduser().resolve()
    dim = _normalize_dimension_id(dimension_id)

    candidates: list[tuple[Path, str]] = [(_new_dimension_path(world, dim), "minecraft-26.1+")]
    legacy = _legacy_dimension_path(world, dim)
    if legacy is not None:
        candidates.append((legacy, "legacy"))

    # If a caller intentionally supplied a dimension directory rather than the
    # save root, allow it as a last resort. Do not use this ahead of the proper
    # 26.1+ path because a save root may also contain unrelated folders.
    candidates.append((world, "direct-dimension"))

    seen: set[Path] = set()
    for dimension_path, layout in candidates:
        try:
            key = dimension_path.resolve()
        except Exception:
            key = dimension_path
        if key in seen:
            continue
        seen.add(key)
        region_dir = dimension_path / "region"
        if require_region and not region_dir.is_dir():
            continue
        if not require_region and not dimension_path.exists():
            continue
        return DimensionStorage(
            world_path=world,
            dimension_id=dim,
            dimension_path=dimension_path,
            region_dir=region_dir,
            entities_dir=dimension_path / "entities",
            poi_dir=dimension_path / "poi",
            layout=layout,
        )

    expected_new = _new_dimension_path(world, dim) / "region"
    expected_legacy = (_legacy_dimension_path(world, dim) / "region") if _legacy_dimension_path(world, dim) else None
    msg = [f"Could not find region storage for {dim} in {world}.", f"Minecraft 26.1+ expected: {expected_new}"]
    if expected_legacy is not None:
        msg.append(f"Legacy expected: {expected_legacy}")
    raise FileNotFoundError(" ".join(msg))


def discover_dimensions(world_path: Path) -> list[DimensionStorage]:
    """Return dimension stores present in either modern or legacy layouts."""

    world = Path(world_path).expanduser().resolve()
    found: dict[str, DimensionStorage] = {}

    dimensions_root = world / "dimensions"
    if dimensions_root.is_dir():
        # A dimension path can contain slashes after the namespace, so locate
        # region directories and derive the id from the relative parent path.
        for region_dir in dimensions_root.rglob("region"):
            if not region_dir.is_dir():
                continue
            dim_path = region_dir.parent
            try:
                rel = dim_path.relative_to(dimensions_root)
            except ValueError:
                continue
            parts = rel.parts
            if len(parts) < 2:
                continue
            namespace = parts[0]
            path = "/".join(parts[1:])
            dim_id = _normalize_dimension_id(f"{namespace}:{path}")
            found[dim_id] = DimensionStorage(
                world_path=world,
                dimension_id=dim_id,
                dimension_path=dim_path,
                region_dir=region_dir,
                entities_dir=dim_path / "entities",
                poi_dir=dim_path / "poi",
                layout="minecraft-26.1+",
            )

    for dim_id in ("minecraft:overworld", "minecraft:the_nether", "minecraft:the_end"):
        if dim_id in found:
            continue
        legacy = _legacy_dimension_path(world, dim_id)
        if legacy is None or not (legacy / "region").is_dir():
            continue
        found[dim_id] = DimensionStorage(
            world_path=world,
            dimension_id=dim_id,
            dimension_path=legacy,
            region_dir=legacy / "region",
            entities_dir=legacy / "entities",
            poi_dir=legacy / "poi",
            layout="legacy",
        )

    preferred = ["minecraft:overworld", "minecraft:the_nether", "minecraft:the_end"]
    order = {name: idx for idx, name in enumerate(preferred)}
    return sorted(found.values(), key=lambda d: (order.get(d.dimension_id, 99), d.dimension_id))
