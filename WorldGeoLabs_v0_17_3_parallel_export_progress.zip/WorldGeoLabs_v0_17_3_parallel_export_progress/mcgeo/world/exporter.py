from __future__ import annotations

import concurrent.futures as cf
import gzip
import math
import multiprocessing as mp
import os
import shutil
import struct
import time
import zlib
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterable

from .nbt import (
    NbtTag,
    read_nbt,
    write_nbt,
    TAG_Byte,
    TAG_Compound,
    TAG_Int,
    TAG_List,
    TAG_Long_Array,
    TAG_String,
)
from .region import RegionFile, probe_region_file
from .dimensions import resolve_dimension_storage
from .blockstates_decode import decode_blockstates, encode_blockstates
from .palette import is_air

ProgressCallback = Callable[[int, str], None]

_REPLACEABLE_ROCK_NAMES = {
    "minecraft:stone", "minecraft:deepslate", "minecraft:tuff", "minecraft:andesite",
    "minecraft:diorite", "minecraft:granite", "minecraft:calcite", "minecraft:basalt",
    "minecraft:blackstone", "minecraft:end_stone", "minecraft:netherrack",
}


def _is_replaceable_rock_name(name: str) -> bool:
    base = str(name or "").split("[", 1)[0]
    if base in _REPLACEABLE_ROCK_NAMES:
        return True
    return (
        base.endswith("_stone")
        or base.endswith("_deepslate")
        or base.endswith("_rock")
        or base.endswith("_slate")
    )


def _mix32(v: int) -> int:
    v &= 0xFFFFFFFF
    v ^= (v >> 16)
    v = (v * 0x7FEB352D) & 0xFFFFFFFF
    v ^= (v >> 15)
    v = (v * 0x846CA68B) & 0xFFFFFFFF
    v ^= (v >> 16)
    return v & 0xFFFFFFFF


def _hash_u32(*vals: int) -> int:
    h = 0x9E3779B9
    for i, v in enumerate(vals):
        h = _mix32(h ^ _mix32(int(v) + i * 0x85EBCA6B))
    return h


def _mirror_points_for_stroke(points: list[tuple[float, float, float]], mirror: str) -> list[tuple[float, float, float]]:
    mode = str(mirror or "None").strip().lower()
    if mode in {"", "none"}:
        return list(points)
    variants: list[tuple[int, int, int]] = [(1, 1, 1)]
    if "x+z" in mode:
        variants = [(1, 1, 1), (-1, 1, 1), (1, 1, -1), (-1, 1, -1)]
    elif "x" in mode:
        variants = [(1, 1, 1), (-1, 1, 1)]
    elif "z" in mode:
        variants = [(1, 1, 1), (1, 1, -1)]
    out: list[tuple[float, float, float]] = []
    seen: set[tuple[int, int, int]] = set()
    for x, y, z in points:
        for sx, sy, sz in variants:
            p = (float(x * sx), float(y * sy), float(z * sz))
            key = (int(round(p[0] * 16.0)), int(round(p[1] * 16.0)), int(round(p[2] * 16.0)))
            if key not in seen:
                seen.add(key)
                out.append(p)
    return out


@dataclass(slots=True)
class IncrementalExportOptions:
    world_path: Path
    paint_layers: list[dict[str, Any]]
    destination_mode: str = "copy"  # copy | inplace
    destination_path: Path | None = None
    seed: int = 1337
    height_range: tuple[int, int] | None = None
    edit_area_chunk_bounds: tuple[int, int, int, int] | None = None
    verify_after_write: bool = True
    dimension_id: str = "minecraft:overworld"
    workers: int = 0       # 0 = all logical CPUs for changed-region processing
    copy_workers: int = 0  # 0 = conservative automatic I/O parallelism
    progress: ProgressCallback | None = None


@dataclass(slots=True)
class IncrementalExportReport:
    source_world: Path
    destination_world: Path
    destination_mode: str
    clone_mode: str = "none"
    dimension_id: str = "minecraft:overworld"
    dimension_region: str = "region"
    changed_blocks: int = 0
    skipped_blocks: int = 0
    changed_chunks: int = 0
    changed_regions: int = 0
    touched_chunks: int = 0
    touched_regions: int = 0
    verified_chunks: int = 0
    workers_used: int = 1
    copy_workers_used: int = 1
    copied_files: int = 0
    copied_bytes: int = 0
    elapsed_seconds: float = 0.0
    changed_region_files: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    def summary_text(self) -> str:
        lines = [
            "Incremental export complete.",
            f"Source: {self.source_world}",
            f"Destination: {self.destination_world}",
            f"Mode: {self.destination_mode}",
        ]
        if self.clone_mode and self.clone_mode != "none":
            lines.append(f"Copy preparation: {self.clone_mode}")
        lines.append(f"Dimension: {self.dimension_id} ({self.dimension_region})")
        lines.extend([
            f"Changed blocks: {self.changed_blocks}",
            f"Skipped blocks: {self.skipped_blocks}",
            f"Changed chunks: {self.changed_chunks} / touched {self.touched_chunks}",
            f"Changed region files: {self.changed_regions} / touched {self.touched_regions}",
            f"Verified changed chunks: {self.verified_chunks}",
            f"Region workers: {self.workers_used}",
        ])
        if self.destination_mode == "copy":
            lines.append(f"Copy workers: {self.copy_workers_used}; copied {self.copied_files:,} files / {self.copied_bytes / (1024**3):.2f} GiB")
        if self.elapsed_seconds > 0:
            lines.append(f"Elapsed: {self.elapsed_seconds:.1f} s")
        if self.changed_region_files:
            lines.append("Region files rewritten:")
            lines.extend(f"- {p}" for p in self.changed_region_files[:30])
            if len(self.changed_region_files) > 30:
                lines.append(f"- … {len(self.changed_region_files) - 30} more")
        if self.warnings:
            lines.append("Warnings:")
            lines.extend(f"- {w}" for w in self.warnings)
        return "\n".join(lines)


def _emit_export_progress(options: IncrementalExportOptions, percent: int, message: str) -> None:
    cb = options.progress
    if cb is None:
        return
    try:
        cb(max(0, min(100, int(percent))), str(message))
    except Exception:
        # UI/progress reporting must never make a safe export fail.
        pass


def _human_bytes(value: int) -> str:
    n = float(max(0, int(value)))
    for unit in ("B", "KiB", "MiB", "GiB", "TiB"):
        if n < 1024.0 or unit == "TiB":
            return f"{n:.1f} {unit}"
        n /= 1024.0
    return f"{n:.1f} TiB"


def _format_eta(seconds: float) -> str:
    if not math.isfinite(seconds) or seconds < 0:
        return "—"
    sec = int(seconds + 0.5)
    h, rem = divmod(sec, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h:d}h {m:02d}m"
    if m:
        return f"{m:d}m {s:02d}s"
    return f"{s:d}s"


def export_paint_layers_incremental(options: IncrementalExportOptions) -> IncrementalExportReport:
    started = time.monotonic()
    src = Path(options.world_path).resolve()
    if not src.exists():
        raise FileNotFoundError(f"World folder does not exist: {src}")
    source_storage = resolve_dimension_storage(src, options.dimension_id)

    layers = [dict(x or {}) for x in list(options.paint_layers or [])]
    if not layers:
        raise ValueError("There are no visible/enabled paint layers with strokes to export.")

    mode = str(options.destination_mode or "copy").strip().lower()
    if mode not in {"copy", "inplace"}:
        mode = "copy"

    # Build the edit plan before copying gigabytes.  Older builds cloned the
    # whole world first even when the visible strokes did not touch a single
    # existing chunk.
    active_strokes = sum(
        len(list(layer.get("strokes") or []))
        for layer in layers
        if bool(layer.get("enabled", True)) and bool(layer.get("preview_visible", True))
    )
    _emit_export_progress(options, 0, f"Planning export: {active_strokes:,} visible/enabled stroke(s)…")

    def plan_progress(done: int, total: int) -> None:
        pct = 1 + int(7 * (done / max(1, total)))
        _emit_export_progress(options, pct, f"Planning edits: {done:,}/{total:,} stroke(s)…")

    chunk_plan = _build_chunk_plan(
        layers,
        seed=int(options.seed),
        edit_area_chunk_bounds=options.edit_area_chunk_bounds,
        progress=plan_progress,
    )
    touched_regions = sorted({(cx >> 5, cz >> 5) for cx, cz in chunk_plan.keys()})
    _emit_export_progress(
        options,
        8,
        f"Edit plan ready: {len(chunk_plan):,} chunk(s) across {len(touched_regions):,} region file(s).",
    )

    if mode == "copy":
        dst = Path(options.destination_path) if options.destination_path else _default_export_path(src)
        dst = dst.resolve()
        if dst.exists():
            raise FileExistsError(f"Destination already exists: {dst}")
        clone_mode, copied_files, copied_bytes, copy_workers_used = _clone_world_tree_safe(
            src,
            dst,
            workers=int(options.copy_workers),
            progress=lambda frac, msg: _emit_export_progress(options, 8 + int(37 * frac), msg),
        )
    else:
        dst = src
        clone_mode = "in-place"
        copied_files = 0
        copied_bytes = 0
        copy_workers_used = 0
        _emit_export_progress(options, 45, "In-place export selected; world-copy stage skipped.")

    destination_storage = resolve_dimension_storage(dst, source_storage.dimension_id)
    report = IncrementalExportReport(
        source_world=src,
        destination_world=dst,
        destination_mode=mode,
        clone_mode=clone_mode,
        dimension_id=destination_storage.dimension_id,
        dimension_region=str(destination_storage.region_dir.relative_to(dst)),
        copied_files=int(copied_files),
        copied_bytes=int(copied_bytes),
        copy_workers_used=max(1, int(copy_workers_used or 1)),
    )
    report.touched_chunks = len(chunk_plan)
    report.touched_regions = len(touched_regions)

    if not chunk_plan:
        report.warnings.append("Paint layers had strokes, but no chunk columns intersected those strokes.")
        report.elapsed_seconds = time.monotonic() - started
        _emit_export_progress(options, 100, "Export complete: no existing chunks intersected the edits.")
        return report

    region_to_chunks: dict[tuple[int, int], list[tuple[int, int]]] = {}
    for cx, cz in sorted(chunk_plan.keys()):
        region_to_chunks.setdefault((cx >> 5, cz >> 5), []).append((cx, cz))

    tasks: list[dict[str, Any]] = []
    for (rx, rz), chunks in sorted(region_to_chunks.items()):
        region_path = destination_storage.region_dir / f"r.{rx}.{rz}.mca"
        task_chunks = [
            (int(cx), int(cz), chunk_plan[(cx, cz)])
            for cx, cz in chunks
        ]
        tasks.append({
            "region_path": str(region_path),
            "region_rel": str(region_path.relative_to(dst)),
            "chunks": task_chunks,
            "seed": int(options.seed),
            "verify": bool(options.verify_after_write),
        })

    requested_workers = int(options.workers or 0)
    logical = max(1, int(os.cpu_count() or 1))
    region_workers = requested_workers if requested_workers > 0 else logical
    region_workers = max(1, min(region_workers, logical, len(tasks)))
    report.workers_used = int(region_workers)

    total_regions = len(tasks)
    total_chunk_work = sum(len(task["chunks"]) for task in tasks)
    done_regions = 0
    done_chunk_work = 0
    processing_started = time.monotonic()
    _emit_export_progress(
        options,
        46,
        f"Applying edits: starting {region_workers} region worker process(es) for {total_regions:,} region(s) / {total_chunk_work:,} chunk(s)…",
    )

    def consume_result(result: dict[str, Any]) -> None:
        nonlocal done_regions, done_chunk_work
        done_regions += 1
        done_chunk_work += int(result.get("touched_chunks", 0))
        report.changed_blocks += int(result.get("changed_blocks", 0))
        report.skipped_blocks += int(result.get("skipped_blocks", 0))
        report.changed_chunks += int(result.get("changed_chunks", 0))
        report.verified_chunks += int(result.get("verified_chunks", 0))
        if bool(result.get("changed_region", False)):
            report.changed_regions += 1
            rel = str(result.get("region_rel") or "")
            if rel:
                report.changed_region_files.append(rel)
        report.warnings.extend(str(x) for x in (result.get("warnings") or []))

        frac = done_chunk_work / max(1, total_chunk_work)
        elapsed = max(0.001, time.monotonic() - processing_started)
        rate = done_chunk_work / elapsed
        remaining = max(0, total_chunk_work - done_chunk_work)
        eta = remaining / rate if rate > 0 else math.inf
        pct = 46 + int(50 * frac)
        _emit_export_progress(
            options,
            pct,
            f"Applying edits: {done_regions:,}/{total_regions:,} region(s), "
            f"{done_chunk_work:,}/{total_chunk_work:,} chunk(s); "
            f"{report.changed_blocks:,} block change(s); {region_workers} workers; ETA {_format_eta(eta)}",
        )

    if region_workers <= 1 or len(tasks) <= 1:
        for task in tasks:
            consume_result(_export_region_worker(task))
    else:
        executor: cf.ProcessPoolExecutor | None = None
        try:
            ctx = mp.get_context("spawn") if os.name == "nt" else mp.get_context()
            executor = cf.ProcessPoolExecutor(max_workers=region_workers, mp_context=ctx)
            futures = [executor.submit(_export_region_worker, task) for task in tasks]
            for future in cf.as_completed(futures):
                consume_result(future.result())
        finally:
            if executor is not None:
                executor.shutdown(wait=True, cancel_futures=True)

    _emit_export_progress(options, 97, "Finalizing export report and safety checks…")
    if report.changed_blocks <= 0:
        report.warnings.append("No blocks changed. This can happen when strokes only hit air/missing sections or no existing chunks were under the brush.")
    report.warnings.append("Export applies visible/enabled Paint layers, including generated Geological Resource layers. Legacy cave/ore generator-preview layers remain preview-only; heightmap/light recalculation is still a future pass.")
    report.elapsed_seconds = time.monotonic() - started
    _emit_export_progress(
        options,
        100,
        f"Export complete: {report.changed_blocks:,} block(s), {report.changed_chunks:,} chunk(s), "
        f"{report.changed_regions:,} region file(s) in {report.elapsed_seconds:.1f}s.",
    )
    return report


def _export_region_worker(payload: dict[str, Any]) -> dict[str, Any]:
    """Apply all planned edits for one independent Anvil region file.

    A region is the natural unit of parallelism: workers never write the same
    ``.mca`` file, so no inter-process file locks are needed.  Each worker opens
    the region once, reads every target chunk through that one handle, rewrites
    the region once, and verifies the changed chunks before atomically replacing
    the destination file.
    """
    region_path = Path(str(payload["region_path"]))
    region_rel = str(payload.get("region_rel") or region_path.name)
    chunks = list(payload.get("chunks") or [])
    seed = int(payload.get("seed", 1337))
    verify = bool(payload.get("verify", True))
    result: dict[str, Any] = {
        "region_rel": region_rel,
        "touched_chunks": len(chunks),
        "changed_blocks": 0,
        "skipped_blocks": 0,
        "changed_chunks": 0,
        "verified_chunks": 0,
        "changed_region": False,
        "warnings": [],
    }
    warnings: list[str] = result["warnings"]

    if not region_path.exists():
        warnings.append(f"Skipped missing/void region: {region_rel}")
        return result
    probe = probe_region_file(region_path)
    if not probe.usable:
        warnings.append(f"Skipped void/unusable region: {region_rel} ({probe.status})")
        return result
    present_slots = set(probe.present_chunks)

    replacements: dict[int, bytes] = {}
    # One file/header open for the whole region instead of reopening it once per
    # target chunk.  This is a large win for generated whole-world geology.
    with RegionFile(region_path) as reg:
        for cx, cz, stroke_plan in chunks:
            cx = int(cx)
            cz = int(cz)
            if (cx & 31, cz & 31) not in present_slots:
                continue
            try:
                raw = reg.read_chunk_nbt_bytes(cx & 31, cz & 31)
            except Exception as exc:
                warnings.append(f"Skipped chunk {cx},{cz}: failed to read NBT ({exc})")
                continue
            if raw is None:
                continue
            try:
                new_raw, stats = _apply_paint_to_chunk_nbt(raw, cx, cz, stroke_plan, seed)
            except Exception as exc:
                warnings.append(f"Skipped chunk {cx},{cz}: failed to apply paint ({exc})")
                continue
            result["skipped_blocks"] += int(stats.get("skipped", 0))
            changed = int(stats.get("changed", 0))
            if changed <= 0:
                continue
            idx = RegionFile.index(cx & 31, cz & 31)
            replacements[idx] = new_raw
            result["changed_blocks"] += changed
            result["changed_chunks"] += 1

    if replacements:
        verified = _rewrite_region_file(region_path, replacements, verify=verify)
        result["verified_chunks"] = int(verified)
        result["changed_region"] = True
    return result

def _default_export_path(src: Path) -> Path:
    stamp = time.strftime("%Y%m%d_%H%M%S")
    return src.parent / f"{src.name}_wgl_export_{stamp}"


def _clone_world_tree_safe(
    src: Path,
    dst: Path,
    *,
    workers: int = 0,
    progress: Callable[[float, str], None] | None = None,
) -> tuple[str, int, int, int]:
    """Create a genuinely independent world copy with byte/file progress.

    File copying is I/O-bound, so this uses a small thread pool rather than all
    logical CPUs.  On a single SSD/HDD, low CPU during this phase is expected;
    the progress text reports throughput and ETA so it does not look stalled.
    """
    src = Path(src)
    dst = Path(dst)
    dst.mkdir(parents=True, exist_ok=False)
    copy_started = time.monotonic()
    manifest: list[tuple[Path, Path, int]] = []
    try:
        # Build a manifest first so the UI can show a real byte-based progress
        # bar rather than an indeterminate spinner.
        if progress:
            progress(0.0, "Copying world: scanning files and calculating total size…")
        for root, dirs, files in os.walk(src):
            r = Path(root)
            rel = r.relative_to(src)
            dirs[:] = [d for d in dirs if d != ".worldgeolabs"]
            out_dir = dst / rel
            out_dir.mkdir(parents=True, exist_ok=True)
            for d in dirs:
                (out_dir / d).mkdir(exist_ok=True)
            for name in files:
                if rel == Path('.') and name == "session.lock":
                    continue
                # Distant Horizons data is a derived render cache, not Minecraft
                # world authority. Copying a precomputed 16k-world DH database
                # can dominate export time and would be stale immediately after
                # GeoLabs changes terrain. Let DH regenerate it for the copy.
                if str(name).lower().startswith("distanthorizons.sqlite"):
                    continue
                source = r / name
                target = out_dir / name
                try:
                    size = int(source.stat().st_size)
                except OSError:
                    size = 0
                manifest.append((source, target, size))

        total_files = len(manifest)
        total_bytes = sum(item[2] for item in manifest)
        logical = max(1, int(os.cpu_count() or 1))
        requested = int(workers or 0)
        # More than ~8 simultaneous reads/writes to one world directory usually
        # hurts rather than helps. Users can override this explicitly.
        copy_workers = requested if requested > 0 else min(8, logical)
        copy_workers = max(1, min(copy_workers, max(1, total_files)))

        if progress:
            progress(
                0.0,
                f"Copying world: 0/{total_files:,} files, 0 B/{_human_bytes(total_bytes)}; {copy_workers} I/O worker(s)…",
            )

        copied_files = 0
        copied_bytes = 0

        def copy_one(item: tuple[Path, Path, int]) -> int:
            source, target, size = item
            shutil.copy2(source, target)
            return int(size)

        if copy_workers <= 1:
            iterator = ((copy_one(item), item) for item in manifest)
            for size_done, _item in iterator:
                copied_files += 1
                copied_bytes += int(size_done)
                if progress:
                    elapsed = max(0.001, time.monotonic() - copy_started)
                    rate = copied_bytes / elapsed
                    remaining = max(0, total_bytes - copied_bytes)
                    eta = remaining / rate if rate > 0 else math.inf
                    progress(
                        copied_bytes / max(1, total_bytes),
                        f"Copying world: {copied_files:,}/{total_files:,} files, "
                        f"{_human_bytes(copied_bytes)}/{_human_bytes(total_bytes)} "
                        f"({_human_bytes(int(rate))}/s); ETA {_format_eta(eta)}",
                    )
        else:
            with cf.ThreadPoolExecutor(max_workers=copy_workers, thread_name_prefix="wgl-copy") as ex:
                futures = {ex.submit(copy_one, item): item for item in manifest}
                for future in cf.as_completed(futures):
                    copied_files += 1
                    copied_bytes += int(future.result())
                    if progress:
                        elapsed = max(0.001, time.monotonic() - copy_started)
                        rate = copied_bytes / elapsed
                        remaining = max(0, total_bytes - copied_bytes)
                        eta = remaining / rate if rate > 0 else math.inf
                        progress(
                            copied_bytes / max(1, total_bytes),
                            f"Copying world: {copied_files:,}/{total_files:,} files, "
                            f"{_human_bytes(copied_bytes)}/{_human_bytes(total_bytes)} "
                            f"({_human_bytes(int(rate))}/s); ETA {_format_eta(eta)}",
                        )
        return ("independent file copy (analysis + DH caches excluded)", copied_files, copied_bytes, copy_workers)
    except Exception:
        shutil.rmtree(dst, ignore_errors=True)
        raise

def _verify_region_replacements(path: Path, replacement_nbt: dict[int, bytes]) -> None:
    """Reopen a rewritten region and byte-verify every changed chunk payload."""
    with RegionFile(path) as region:
        for idx, expected in sorted(replacement_nbt.items()):
            cxr = int(idx) & 31
            czr = (int(idx) >> 5) & 31
            actual = region.read_chunk_nbt_bytes(cxr, czr)
            if actual is None:
                raise IOError(f"Verification failed for {path.name} chunk {cxr},{czr}: chunk disappeared")
            if actual != expected:
                raise IOError(f"Verification failed for {path.name} chunk {cxr},{czr}: NBT payload mismatch")


def _build_chunk_plan(
    layers: list[dict[str, Any]],
    *,
    seed: int,
    edit_area_chunk_bounds: tuple[int, int, int, int] | None = None,
    progress: Callable[[int, int], None] | None = None,
) -> dict[tuple[int, int], list[tuple[int, int, dict[str, Any]]]]:
    plan: dict[tuple[int, int], list[tuple[int, int, dict[str, Any]]]] = {}
    area = edit_area_chunk_bounds
    total_strokes = sum(
        len(list(layer.get("strokes") or []))
        for layer in layers
        if bool(layer.get("enabled", True)) and bool(layer.get("preview_visible", True))
    )
    done_strokes = 0
    last_progress_bucket = -1

    def mark_stroke_done() -> None:
        nonlocal done_strokes, last_progress_bucket
        done_strokes += 1
        if progress is None:
            return
        bucket = int((done_strokes * 100) / max(1, total_strokes))
        if bucket != last_progress_bucket:
            last_progress_bucket = bucket
            progress(done_strokes, total_strokes)

    for layer_i, layer in enumerate(layers):
        if not bool(layer.get("enabled", True)) or not bool(layer.get("preview_visible", True)):
            continue
        settings = dict(layer.get("settings") or {})
        strokes = list(layer.get("strokes") or [])
        for stroke_i, stroke in enumerate(strokes):
            try:
                try:
                    merged = dict(settings)
                    merged.update(dict(stroke or {}))
                except Exception:
                    continue
                bbox = _stroke_bbox(merged)
                if bbox is None:
                    continue
                x0, y0, z0, x1, y1, z1 = bbox
                try:
                    size = max(1, int(merged.get("size_blocks", 1)))
                except Exception:
                    size = 1
                # _stroke_bbox() already expands by the brush radius. Keep only
                # a one-block rounding/falloff guard.
                pad = 1
                min_cx = math.floor((x0 - pad) / 16)
                max_cx = math.floor((x1 + pad) / 16)
                min_cz = math.floor((z0 - pad) / 16)
                max_cz = math.floor((z1 + pad) / 16)
                if area is not None and not bool(merged.get("generated_geology", False)):
                    aminx, amaxx, aminz, amaxz = area
                    min_cx = max(min_cx, int(aminx))
                    max_cx = min(max_cx, int(amaxx))
                    min_cz = max(min_cz, int(aminz))
                    max_cz = min(max_cz, int(amaxz))
                if max_cx < min_cx or max_cz < min_cz:
                    continue
                merged["_export_seed"] = _hash_u32(seed, 0x5041494E, layer_i, stroke_i)
                for cz in range(min_cz, max_cz + 1):
                    for cx in range(min_cx, max_cx + 1):
                        plan.setdefault((cx, cz), []).append((layer_i, stroke_i, merged))
            finally:
                mark_stroke_done()
    return plan

def _stroke_bbox(stroke: dict[str, Any]) -> tuple[int, int, int, int, int, int] | None:
    bbox = stroke.get("bbox")
    if isinstance(bbox, (list, tuple)) and len(bbox) == 6:
        try:
            x0, y0, z0, x1, y1, z1 = [int(float(v)) for v in bbox]
            return (min(x0, x1), min(y0, y1), min(z0, z1), max(x0, x1), max(y0, y1), max(z0, z1))
        except Exception:
            pass
    pts = []
    for p in stroke.get("points") or []:
        if isinstance(p, (list, tuple)) and len(p) >= 3:
            try:
                pts.append((float(p[0]), float(p[1]), float(p[2])))
            except Exception:
                pass
    if not pts:
        return None
    try:
        size = max(1, int(stroke.get("size_blocks", 1)))
    except Exception:
        size = 1
    r = max(1.0, float(size) * 0.5)
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    zs = [p[2] for p in pts]
    return (
        int(math.floor(min(xs) - r)), int(math.floor(min(ys) - r)), int(math.floor(min(zs) - r)),
        int(math.ceil(max(xs) + r)), int(math.ceil(max(ys) + r)), int(math.ceil(max(zs) + r)),
    )


def _read_chunk_nbt_bytes(region_path: Path, cx_in_region: int, cz_in_region: int) -> bytes | None:
    with RegionFile(region_path) as reg:
        return reg.read_chunk_nbt_bytes(cx_in_region, cz_in_region)


def _apply_paint_to_chunk_nbt(
    raw: bytes,
    cx: int,
    cz: int,
    stroke_plan: list[tuple[int, int, dict[str, Any]]],
    seed: int,
) -> tuple[bytes, dict[str, int]]:
    root = read_nbt(raw).value
    data = root.get("Level").value if "Level" in root and root["Level"].tag_id == TAG_Compound else root
    sections_tag = data.get("sections") or data.get("Sections")
    if not sections_tag or sections_tag.tag_id != TAG_List:
        return raw, {"changed": 0, "skipped": 0}
    elem_id, sections_list = sections_tag.value
    if int(elem_id) != TAG_Compound:
        return raw, {"changed": 0, "skipped": 0}

    sections: dict[int, dict[str, Any]] = {}
    for sec_comp in sections_list:
        if not isinstance(sec_comp, dict):
            continue
        y_tag = sec_comp.get("Y") or sec_comp.get("y")
        if y_tag is None:
            continue
        try:
            sy = int(y_tag.value)
        except Exception:
            continue
        bs_key = "block_states" if "block_states" in sec_comp else "BlockStates" if "BlockStates" in sec_comp else "block_states"
        bs_tag = sec_comp.get(bs_key)
        if not bs_tag or bs_tag.tag_id != TAG_Compound:
            continue
        bs_comp = bs_tag.value
        pal_key = "palette" if "palette" in bs_comp else "Palette" if "Palette" in bs_comp else "palette"
        pal_tag = bs_comp.get(pal_key)
        if not pal_tag or pal_tag.tag_id != TAG_List:
            continue
        _, pal_list = pal_tag.value
        palette_states = [_canonical_from_palette_entry(p) for p in pal_list]
        data_key = "data" if "data" in bs_comp else "Data" if "Data" in bs_comp else "data"
        data_tag = bs_comp.get(data_key)
        if data_tag and data_tag.tag_id == TAG_Long_Array:
            indices = decode_blockstates(list(data_tag.value), len(palette_states))
        else:
            indices = [0] * 4096
        sections[sy] = {
            "sec_comp": sec_comp,
            "bs_comp": bs_comp,
            "pal_key": pal_key,
            "data_key": data_key,
            "palette_states": palette_states,
            "indices": indices,
        }

    if not sections:
        return raw, {"changed": 0, "skipped": 0}

    tops = _compute_chunk_top_y(sections)
    changed = 0
    skipped = 0
    dirty_section_y: set[int] = set()

    for _layer_i, _stroke_i, stroke in stroke_plan:
        c, s, dirty = _apply_stroke_to_sections(sections, tops, cx, cz, stroke)
        changed += c
        skipped += s
        dirty_section_y.update(int(v) for v in dirty)

    if changed <= 0:
        return raw, {"changed": 0, "skipped": skipped}

    # Only re-encode NBT sections that actually changed. Tall worlds can have
    # 150+ vertical sections per chunk; touching one ore vein should not repack
    # every section in the column.
    for sy, item in sections.items():
        if int(sy) not in dirty_section_y:
            continue
        palette_states = item["palette_states"]
        indices = item["indices"]
        bs_comp = item["bs_comp"]
        pal_key = item["pal_key"]
        data_key = item["data_key"]
        pal_list = [_palette_entry_from_canonical(s) for s in palette_states]
        bs_comp[pal_key] = NbtTag(TAG_List, (TAG_Compound, pal_list))
        bs_comp[data_key] = NbtTag(TAG_Long_Array, encode_blockstates(indices, len(palette_states)))

    # Empty root name is what the existing reader assumes and works for modern Anvil chunks.
    return write_nbt("", root), {"changed": changed, "skipped": skipped}


def _apply_stroke_to_sections(
    sections: dict[int, dict[str, Any]],
    tops: list[int],
    cx: int,
    cz: int,
    stroke: dict[str, Any],
) -> tuple[int, int, set[int]]:
    points_raw = stroke.get("points") or []
    pts: list[tuple[float, float, float]] = []
    for p in points_raw:
        if isinstance(p, (list, tuple)) and len(p) >= 3:
            try:
                pts.append((float(p[0]), float(p[1]), float(p[2])))
            except Exception:
                pass
    if not pts:
        return (0, 0, set())
    pts = _mirror_points_for_stroke(pts, str(stroke.get("mirror", "None")))
    action = str(stroke.get("action", "Replace blocks"))
    shape = str(stroke.get("shape", "Sphere")).strip().lower()
    try:
        size_blocks = max(1, int(stroke.get("size_blocks", 1)))
    except Exception:
        size_blocks = 1
    radius = max(0.5, float(size_blocks) * 0.5)
    try:
        strength_pct = max(0, min(100, int(stroke.get("strength_pct", 100))))
    except Exception:
        strength_pct = 100
    target_state = _paint_target_state(action, str(stroke.get("material", "minecraft:stone")))
    host_only = bool(stroke.get("host_only", False))
    replace_only = {
        (str(name).strip().lower() if ":" in str(name) else f"minecraft:{str(name).strip().lower()}")
        for name in (stroke.get("replace_only") or [])
        if str(name).strip()
    }
    protect_surface = bool(stroke.get("protect_surface", False))
    try:
        surface_margin = max(0, int(stroke.get("surface_margin", 0)))
    except Exception:
        surface_margin = 0
    axis_lock = str(stroke.get("axis_lock", "None")).strip().upper()
    seed = int(stroke.get("_export_seed", 1337))

    ox = cx * 16
    oz = cz * 16
    changed = 0
    skipped = 0
    dirty_section_y: set[int] = set()

    def strength_pass(wx: int, wy: int, wz: int) -> bool:
        if strength_pct >= 100:
            return True
        if strength_pct <= 0:
            return False
        return (_hash_u32(seed, wx, wy, wz) % 100) < strength_pct

    for stamp_i, (wxc, wyc, wzc) in enumerate(pts):
        x0 = max(0, int(math.floor(wxc - radius - ox)))
        x1 = min(15, int(math.ceil(wxc + radius - ox)))
        z0 = max(0, int(math.floor(wzc - radius - oz)))
        z1 = min(15, int(math.ceil(wzc + radius - oz)))
        if x1 < 0 or x0 > 15 or z1 < 0 or z0 > 15:
            continue
        # Clamp y to the range of existing sections. First export pass avoids
        # creating brand-new chunk sections so it cannot create malformed biome-less
        # sections in modern worlds.
        min_sy = min(sections.keys())
        max_sy = max(sections.keys())
        y0 = max(min_sy * 16, int(math.floor(wyc - radius)))
        y1 = min(max_sy * 16 + 15, int(math.ceil(wyc + radius)))
        if shape == "disc":
            if axis_lock == "X":
                x0 = x1 = max(0, min(15, int(round(wxc - ox))))
            elif axis_lock == "Z":
                z0 = z1 = max(0, min(15, int(round(wzc - oz))))
            else:
                y0 = y1 = max(min_sy * 16, min(max_sy * 16 + 15, int(round(wyc))))
        r2 = radius * radius
        for wy in range(y0, y1 + 1):
            sy = wy // 16
            item = sections.get(sy)
            if item is None:
                skipped += 1
                continue
            ly = wy & 15
            indices = item["indices"]
            palette_states = item["palette_states"]
            for gz in range(z0, z1 + 1):
                wz = oz + gz
                for gx in range(x0, x1 + 1):
                    wx = ox + gx
                    inside = True
                    if shape in {"sphere", "blob", "tunnel brush", "tunnel"}:
                        dx = (wx + 0.5) - float(wxc)
                        dy = (wy + 0.5) - float(wyc)
                        dz = (wz + 0.5) - float(wzc)
                        d2 = dx * dx + dy * dy + dz * dz
                        if shape == "blob":
                            jitter = 1.0 + 0.20 * _rand_signed_local(_hash_u32(seed, stamp_i, gx, wy, gz))
                            inside = d2 <= (r2 * max(0.5, jitter))
                        else:
                            inside = d2 <= r2
                    elif shape == "disc":
                        dx = (wx + 0.5) - float(wxc)
                        dy = (wy + 0.5) - float(wyc)
                        dz = (wz + 0.5) - float(wzc)
                        if axis_lock == "X":
                            inside = (dy * dy + dz * dz) <= r2
                        elif axis_lock == "Z":
                            inside = (dx * dx + dy * dy) <= r2
                        else:
                            inside = (dx * dx + dz * dz) <= r2
                    if not inside or not strength_pass(wx, wy, wz):
                        continue
                    idx = (ly * 16 + gz) * 16 + gx
                    cur_state = _state_at(palette_states, indices[idx])
                    cur_name = cur_state.split("[", 1)[0].lower()
                    if replace_only and cur_name not in replace_only:
                        skipped += 1
                        continue
                    if host_only and (is_air(cur_name) or not _is_replaceable_rock_name(cur_name)):
                        skipped += 1
                        continue
                    if protect_surface:
                        top = tops[gz * 16 + gx]
                        if top < 0 or (top - wy) < surface_margin:
                            skipped += 1
                            continue
                    if cur_state == target_state:
                        continue
                    pi = _palette_index(palette_states, target_state)
                    indices[idx] = pi
                    dirty_section_y.add(int(sy))
                    changed += 1
    return (changed, skipped, dirty_section_y)


def _paint_target_state(action: str, material: str) -> str:
    a = str(action or "").strip().lower()
    mat = str(material or "minecraft:stone").strip() or "minecraft:stone"
    if "erase" in a or "carve" in a or mat == "minecraft:air":
        return "minecraft:air"
    return mat


def _state_at(palette: list[str], idx: int) -> str:
    if 0 <= int(idx) < len(palette):
        return palette[int(idx)]
    return "minecraft:air"


def _palette_index(palette: list[str], state: str) -> int:
    try:
        return palette.index(state)
    except ValueError:
        palette.append(state)
        return len(palette) - 1


def _rand_signed_local(seed: int) -> float:
    return ((seed & 0xFFFFFF) / float(0x1000000)) * 2.0 - 1.0


def _compute_chunk_top_y(sections: dict[int, dict[str, Any]]) -> list[int]:
    tops = [-10**9] * 256
    for sy in sorted(sections.keys(), reverse=True):
        item = sections[sy]
        palette = item["palette_states"]
        indices = item["indices"]
        for ly in range(15, -1, -1):
            wy = sy * 16 + ly
            base_y = ly * 256
            for z in range(16):
                base_z = base_y + z * 16
                for x in range(16):
                    ti = z * 16 + x
                    if tops[ti] != -10**9:
                        continue
                    st = _state_at(palette, indices[base_z + x])
                    if not is_air(st.split("[", 1)[0]):
                        tops[ti] = wy
    return [t if t != -10**9 else -1 for t in tops]


def _canonical_from_palette_entry(entry: Any) -> str:
    if not isinstance(entry, dict):
        return "minecraft:air"
    name_tag = entry.get("Name")
    name = str(name_tag.value) if name_tag is not None else "minecraft:air"
    props_tag = entry.get("Properties")
    if props_tag is None or props_tag.tag_id != TAG_Compound:
        return name
    props = props_tag.value or {}
    if not props:
        return name
    parts = []
    for k in sorted(props.keys()):
        try:
            parts.append(f"{k}={props[k].value}")
        except Exception:
            parts.append(f"{k}={props[k]}")
    return f"{name}[{','.join(parts)}]"


def _palette_entry_from_canonical(state: str) -> dict[str, NbtTag]:
    text = str(state or "minecraft:air")
    name = text
    props: dict[str, NbtTag] = {}
    if "[" in text and text.endswith("]"):
        name, rest = text.split("[", 1)
        rest = rest[:-1]
        for part in rest.split(","):
            if not part or "=" not in part:
                continue
            k, v = part.split("=", 1)
            props[str(k)] = NbtTag(TAG_String, str(v))
    out = {"Name": NbtTag(TAG_String, name)}
    if props:
        out["Properties"] = NbtTag(TAG_Compound, props)
    return out


def _read_region_entries(path: Path) -> tuple[dict[int, tuple[int, bytes, int]], list[int]]:
    entries: dict[int, tuple[int, bytes, int]] = {}
    timestamps = [0] * 1024
    with open(path, "rb") as fh:
        header = fh.read(8192)
        if len(header) < 8192:
            raise IOError(f"Bad region header: {path}")
        offsets = header[:4096]
        times = header[4096:8192]
        for i in range(1024):
            t = struct.unpack(">I", times[i * 4:(i + 1) * 4])[0]
            timestamps[i] = t
            off = offsets[i * 4:(i + 1) * 4]
            sector_offset = (off[0] << 16) | (off[1] << 8) | off[2]
            sector_count = off[3]
            if sector_offset == 0 or sector_count == 0:
                continue
            fh.seek(sector_offset * 4096)
            length_b = fh.read(4)
            if len(length_b) != 4:
                continue
            length = struct.unpack(">I", length_b)[0]
            ctype_b = fh.read(1)
            if len(ctype_b) != 1 or length <= 0:
                continue
            payload = fh.read(length - 1)
            entries[i] = (int(ctype_b[0]), payload, t)
    return entries, timestamps


def _rewrite_region_file(
    path: Path,
    replacement_nbt: dict[int, bytes],
    *,
    verify: bool = True,
) -> int:
    """Stream-rewrite one region and atomically replace it.

    Unchanged chunks stay compressed: their raw region payloads are copied
    directly from the source file into the temporary file.  Only changed chunks
    are zlib-compressed again.  This avoids materializing the entire .mca body in
    RAM and scales much better when several independent region workers run at
    once.
    """
    path = Path(path)
    now = int(time.time())
    tmp = path.with_suffix(path.suffix + ".wgl.tmp")
    verified = 0
    try:
        with open(path, "rb") as source:
            header = source.read(8192)
            if len(header) != 8192:
                raise IOError(f"Bad region header: {path}")
            source_offsets = header[:4096]
            source_times = header[4096:8192]

            offset_table = bytearray(4096)
            time_table = bytearray(source_times)

            with open(tmp, "wb") as out:
                # Reserve header sectors and then stream each chunk record.
                out.write(b"\x00" * 8192)
                next_sector = 2
                for i in range(1024):
                    replacement = replacement_nbt.get(i)
                    if replacement is not None:
                        payload = zlib.compress(replacement, level=6)
                        ctype = 2
                        ts = now
                    else:
                        j = i * 4
                        off = source_offsets[j:j + 4]
                        sector_offset = (off[0] << 16) | (off[1] << 8) | off[2]
                        sector_count = off[3]
                        if sector_offset == 0 or sector_count == 0:
                            continue
                        source.seek(sector_offset * 4096)
                        length_b = source.read(4)
                        if len(length_b) != 4:
                            raise IOError(f"Unexpected EOF reading chunk {i} from {path}")
                        length = struct.unpack(">I", length_b)[0]
                        if length <= 0 or length + 4 > sector_count * 4096:
                            raise IOError(f"Invalid chunk length for index {i} in {path}")
                        ctype_b = source.read(1)
                        if len(ctype_b) != 1:
                            raise IOError(f"Unexpected EOF reading compression type for chunk {i} in {path}")
                        ctype = int(ctype_b[0])
                        payload = source.read(length - 1)
                        if len(payload) != length - 1:
                            raise IOError(f"Unexpected EOF reading chunk payload {i} from {path}")
                        ts = struct.unpack(">I", source_times[j:j + 4])[0]

                    record = struct.pack(">I", len(payload) + 1) + struct.pack(">B", int(ctype)) + payload
                    sectors = max(1, (len(record) + 4095) // 4096)
                    if next_sector >= (1 << 24) or sectors >= 256:
                        raise IOError(f"Region file too large while writing {path}")
                    j = i * 4
                    offset_table[j] = (next_sector >> 16) & 0xFF
                    offset_table[j + 1] = (next_sector >> 8) & 0xFF
                    offset_table[j + 2] = next_sector & 0xFF
                    offset_table[j + 3] = sectors & 0xFF
                    struct.pack_into(">I", time_table, j, int(ts or now))
                    out.write(record)
                    pad = sectors * 4096 - len(record)
                    if pad:
                        out.write(b"\x00" * pad)
                    next_sector += sectors

                out.seek(0)
                out.write(offset_table)
                out.write(time_table)
                out.flush()
                os.fsync(out.fileno())

        # Validate the temporary file while the original is still intact.  A
        # successful atomic replace cannot alter the verified bytes, so a
        # second full decompression pass after os.replace is unnecessary.
        with RegionFile(tmp) as reg:
            for idx, expected in sorted(replacement_nbt.items()):
                cxr = int(idx) & 31
                czr = (int(idx) >> 5) & 31
                if not reg.has_chunk(cxr, czr):
                    raise IOError(f"Temporary region verification failed for chunk index {idx}")
                actual = reg.read_chunk_nbt_bytes(cxr, czr)
                if actual is None:
                    raise IOError(f"Temporary region verification failed reading chunk index {idx}")
                if verify and actual != expected:
                    raise IOError(f"Temporary region verification payload mismatch for chunk index {idx}")
                verified += 1
        os.replace(tmp, path)
        return verified if verify else 0
    finally:
        try:
            if tmp.exists():
                tmp.unlink()
        except OSError:
            pass

