from __future__ import annotations
import io
import os
import struct
import zlib
import gzip
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Iterable

class RegionError(Exception):
    pass


@dataclass(frozen=True)
class RegionProbe:
    """Cheap header-only classification of an Anvil region file.

    WorldPainter/Minecraft 26.x worlds can contain zero-byte or header-only
    ``.mca`` placeholders around intentionally void terrain.  Those files are
    not world data and must never expand editor bounds, participate in
    analysis, or become edit/export targets.
    """
    path: Path
    status: str
    size_bytes: int
    present_chunks: tuple[tuple[int, int], ...] = ()
    invalid_slots: int = 0
    message: str = ""

    @property
    def usable(self) -> bool:
        return bool(self.present_chunks) and self.status in {"ok", "partial"}

    @property
    def void(self) -> bool:
        return self.status in {"zero_byte", "short_header", "empty_header"}


def probe_region_file(path: Path) -> RegionProbe:
    """Inspect only the location table and return usable chunk slots.

    A slot is considered usable when its sector offset/count points inside the
    current file.  Bad/empty border files are therefore ignored without
    attempting NBT decompression.
    """
    p = Path(path)
    try:
        size = int(p.stat().st_size)
    except OSError as exc:
        return RegionProbe(p, "unreadable", 0, message=str(exc))
    if size == 0:
        return RegionProbe(p, "zero_byte", 0, message="zero-byte region placeholder")
    if size < RegionFile.HEADER_BYTES:
        return RegionProbe(p, "short_header", size, message=f"short region header ({size} bytes)")
    try:
        with open(p, "rb") as fh:
            header = fh.read(RegionFile.HEADER_BYTES)
    except OSError as exc:
        return RegionProbe(p, "unreadable", size, message=str(exc))
    if len(header) != RegionFile.HEADER_BYTES:
        return RegionProbe(p, "short_header", size, message=f"short region header ({len(header)} bytes)")

    offsets = header[:4096]
    total_sectors = max(0, size // RegionFile.SECTOR_BYTES)
    present: list[tuple[int, int]] = []
    invalid = 0
    for i in range(1024):
        j = i * 4
        off = offsets[j:j+4]
        sector_offset = (off[0] << 16) | (off[1] << 8) | off[2]
        sector_count = off[3]
        if sector_offset == 0 or sector_count == 0:
            continue
        # Sectors 0 and 1 are the region header. A chunk record must begin at
        # sector >= 2 and its allocated run must fit in the file.
        if sector_offset < 2 or sector_offset >= total_sectors or sector_offset + sector_count > total_sectors:
            invalid += 1
            continue
        present.append((i & 31, (i >> 5) & 31))

    if not present:
        status = "empty_header" if invalid == 0 else "invalid"
        msg = "no present chunk slots" if invalid == 0 else f"no valid chunks; {invalid} invalid location entries"
        return RegionProbe(p, status, size, (), invalid, msg)
    if invalid:
        return RegionProbe(p, "partial", size, tuple(present), invalid, f"{invalid} invalid location entries skipped")
    return RegionProbe(p, "ok", size, tuple(present), 0, "")


def usable_region_files(paths: Iterable[Path]) -> list[Path]:
    return [Path(p) for p in paths if probe_region_file(Path(p)).usable]

@dataclass(frozen=True)
class ChunkLocation:
    sector_offset: int
    sector_count: int
    timestamp: int

class RegionFile:
    """Read a Minecraft .mca region file (Anvil format)."""
    SECTOR_BYTES = 4096
    HEADER_BYTES = 8192

    def __init__(self, path: Path) -> None:
        self.path = path
        self._fh: Optional[io.BufferedReader] = None
        self._loc: list[ChunkLocation] = []

    def __enter__(self) -> "RegionFile":
        self._fh = open(self.path, "rb")
        header = self._fh.read(self.HEADER_BYTES)
        if len(header) != self.HEADER_BYTES:
            raise RegionError(f"Bad region header: {self.path}")
        offsets = header[:4096]
        times = header[4096:8192]
        self._loc = []
        for i in range(1024):
            off = offsets[i*4:(i+1)*4]
            t = struct.unpack(">I", times[i*4:(i+1)*4])[0]
            sector_offset = (off[0] << 16) | (off[1] << 8) | off[2]
            sector_count = off[3]
            self._loc.append(ChunkLocation(sector_offset, sector_count, t))
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        if self._fh:
            self._fh.close()
            self._fh = None

    @staticmethod
    def index(cx_in_region: int, cz_in_region: int) -> int:
        return (cx_in_region & 31) + ((cz_in_region & 31) * 32)

    def has_chunk(self, cx_in_region: int, cz_in_region: int) -> bool:
        loc = self._loc[self.index(cx_in_region, cz_in_region)]
        return loc.sector_offset != 0 and loc.sector_count != 0

    def read_chunk_nbt_bytes(self, cx_in_region: int, cz_in_region: int) -> Optional[bytes]:
        if not self._fh:
            raise RegionError("RegionFile not opened")
        loc = self._loc[self.index(cx_in_region, cz_in_region)]
        if loc.sector_offset == 0 or loc.sector_count == 0:
            return None

        self._fh.seek(loc.sector_offset * self.SECTOR_BYTES)
        length_bytes = self._fh.read(4)
        if len(length_bytes) != 4:
            raise RegionError("Unexpected EOF reading chunk length")
        length = struct.unpack(">I", length_bytes)[0]
        ctype = self._fh.read(1)
        if len(ctype) != 1:
            raise RegionError("Unexpected EOF reading compression type")
        ctype = ctype[0]
        payload = self._fh.read(length - 1)

        if ctype == 1:
            return gzip.decompress(payload)
        if ctype == 2:
            return zlib.decompress(payload)
        if ctype == 3:
            # Uncompressed (rare)
            return payload
        raise RegionError(f"Unknown compression type {ctype} in {self.path}")
