"""Minecraft Java Anvil world loading and block data helpers."""
