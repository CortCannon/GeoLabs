from __future__ import annotations

from copy import deepcopy
from typing import Any

DEFAULT_PAINT_LAYER_SETTINGS: dict[str, Any] = {
    "action": "Replace blocks",
    "material": "minecraft:iron_ore",
    "shape": "Sphere",
    "size_blocks": 8,
    "strength_pct": 100,
    "spacing_pct_radius": 25,
    "falloff": "Constant",
    "axis_lock": "None",
    "mirror": "None",
    "host_only": False,
    "protect_surface": False,
    "surface_margin": 6,
    "align_mode": "Follow hit normal (auto)",
    "brush_roll_deg": 0.0,
    "brush_offset_blocks": 0.0,
}


def clean_layer_name(name: object, fallback: str = "Paint Layer") -> str:
    text = str(name or fallback).strip()
    return text or fallback


def new_paint_layer(name: object) -> dict[str, Any]:
    clean = clean_layer_name(name)
    return {
        "name": clean,
        "enabled": True,
        "preview_visible": True,
        "settings": deepcopy(DEFAULT_PAINT_LAYER_SETTINGS),
        "strokes": [],
    }


def normalize_paint_layer(name: object, layer: object | None = None) -> dict[str, Any]:
    """Return a safe paint-layer dict for project save/load and renderer preview.

    This prevents UI code from duplicating schema defaults and makes later layer
    types easier to add without growing MainWindow.
    """
    source = dict(layer or {}) if isinstance(layer, dict) else {}
    clean = clean_layer_name(source.get("name") or name)
    settings = deepcopy(DEFAULT_PAINT_LAYER_SETTINGS)
    settings.update(dict(source.get("settings") or {}))
    return {
        "name": clean,
        "enabled": bool(source.get("enabled", True)),
        "preview_visible": bool(source.get("preview_visible", True)),
        "settings": settings,
        "strokes": list(source.get("strokes") or []),
    }


def serialize_paint_layers(layers: dict[str, dict]) -> dict[str, dict]:
    return {
        str(name): normalize_paint_layer(name, layer)
        for name, layer in sorted(dict(layers or {}).items(), key=lambda item: str(item[0]).lower())
    }


def restore_paint_layers(store: object) -> tuple[dict[str, dict], dict[str, int]]:
    layers: dict[str, dict] = {}
    stroke_counts: dict[str, int] = {}
    if not isinstance(store, dict):
        return layers, stroke_counts
    for name, layer in store.items():
        clean_layer = normalize_paint_layer(name, layer)
        clean = clean_layer["name"]
        layers[clean] = clean_layer
        stroke_counts[clean] = len(clean_layer.get("strokes") or [])
    return layers, stroke_counts
