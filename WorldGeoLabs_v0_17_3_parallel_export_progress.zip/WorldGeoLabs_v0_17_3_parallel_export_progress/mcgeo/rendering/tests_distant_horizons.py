from __future__ import annotations

import lzma
from contextlib import closing
import sqlite3
import struct
import tempfile
from pathlib import Path

from .distant_horizons import (
    find_distant_horizons_database,
    inspect_distant_horizons_database,
    _build_dh_tile_mesh,
)


def _java_utf(text: str) -> bytes:
    raw = text.encode("utf-8")
    return struct.pack(">H", len(raw)) + raw


def _mapping_blob() -> bytes:
    raw = struct.pack(">i", 1) + _java_utf("minecraft:plains_DH-BSW_minecraft:stone")
    return lzma.compress(raw, format=lzma.FORMAT_XZ)


def _data_blob_v1() -> bytes:
    # 64x64 columns, one stone datapoint each. mapping=0, height=1, minHeight=64.
    value = (0 & 0x7FFFFFFF) | (1 << 32) | (64 << 44) | (15 << 56) | (15 << 60)
    col = struct.pack(">H", 1) + struct.pack(">Q", value)
    return lzma.compress(col * (64 * 64), format=lzma.FORMAT_XZ)


def _varint(value: int) -> bytes:
    if value < 0:
        raise ValueError(value)
    out = bytearray()
    while value >= 128:
        out.append((value & 0x7F) | 0x80)
        value >>= 7
    out.append(value)
    return bytes(out)


def _zigzag(value: int) -> int:
    return (value << 1) ^ (value >> 31)


def _data_blob_v2(column_count: int) -> bytes:
    # Modern DH format 2 is staged rather than interleaved. Each synthetic column has
    # one stone point at relative bottomY=64, height=1, no light. Because bottomY stays
    # flat, each point has a predictive-Y discontinuity correction.
    raw = bytearray()
    for _ in range(column_count):
        raw += _varint(1)  # stage 1: column count
    for _ in range(column_count):
        raw += _varint(1)  # stage 2: id=0 << 2, discontinuity flag=1
    for _ in range(column_count):
        raw += _varint(1)  # stage 3: height
    previous_bottom = 0
    for _ in range(column_count):
        expected = previous_bottom - 1
        error = 64 - expected
        raw += _varint(_zigzag(error))
        previous_bottom = 64
    # stage 5 has no bytes because no points carry light.
    return lzma.compress(bytes(raw), format=lzma.FORMAT_XZ)


def _create_db(db: Path, *, fmt: int) -> None:
    with closing(sqlite3.connect(db)) as con:
        con.execute(
            "CREATE TABLE FullData ("
            "DetailLevel INTEGER, PosX INTEGER, PosZ INTEGER, Data BLOB, Mapping BLOB, "
            "NorthAdjData BLOB, SouthAdjData BLOB, EastAdjData BLOB, WestAdjData BLOB, "
            "DataFormatVersion INTEGER, CompressionMode INTEGER)"
        )
        if fmt == 1:
            con.execute(
                "INSERT INTO FullData VALUES (0,0,0,?,?,NULL,NULL,NULL,NULL,1,3)",
                (_data_blob_v1(), _mapping_blob()),
            )
        else:
            main = _data_blob_v2(62 * 62)
            edge = _data_blob_v2(64)
            con.execute(
                "INSERT INTO FullData VALUES (0,0,0,?,?,?,?,?,?,2,3)",
                (main, _mapping_blob(), edge, edge, edge, edge),
            )
        con.commit()


def _exercise(world: Path, fmt: int) -> None:
    data_dir = world / "data"
    data_dir.mkdir(parents=True)
    db = data_dir / "DistantHorizons.sqlite"
    _create_db(db, fmt=fmt)

    found = find_distant_horizons_database(world)
    assert found == db.resolve(), (found, db)
    info = inspect_distant_horizons_database(db, (0, 3, 0, 3), target_cells=10000)
    assert info.compatible, info
    assert info.selected_detail == 0, info
    assert info.selected_rows == 1, info
    assert fmt in info.format_versions, info
    info32 = inspect_distant_horizons_database(db, (0, 3, 0, 3), target_cell_blocks=32)
    assert info32.compatible and info32.cell_size_blocks == 32, info32
    result = _build_dh_tile_mesh(str(db), 0, 0, 0, -64)
    assert result["ok"], result
    mesh = result["mesh"]
    assert mesh.lod == "dh_context"
    assert mesh.vertex_count == 4096 * 6, (fmt, mesh.vertex_count)
    assert len(mesh.vertices) == mesh.vertex_count * 7 * 4


def run() -> bool:
    with tempfile.TemporaryDirectory(prefix="wgl_dh_test_") as td:
        root = Path(td)
        _exercise(root / "LegacyV1", 1)
        _exercise(root / "ModernV2", 2)
    print("Distant Horizons LOD read/mesh tests OK (FullData formats 1 + 2)")
    return True


if __name__ == "__main__":
    raise SystemExit(0 if run() else 2)
