from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterable, Iterator, Sequence


@dataclass(frozen=True)
class RenderSectionKey:
    """16 x 16 x 16 render/edit brick key.

    This is intentionally separate from Minecraft Anvil chunk-column storage.
    X/Z still match normal chunk coordinates; sy is the vertical section index
    where section world Y spans [sy*16, sy*16+15].
    """

    cx: int
    sy: int
    cz: int

    @property
    def bounds_blocks(self) -> tuple[int, int, int, int, int, int]:
        return (
            int(self.cx) * 16,
            int(self.sy) * 16,
            int(self.cz) * 16,
            int(self.cx) * 16 + 15,
            int(self.sy) * 16 + 15,
            int(self.cz) * 16 + 15,
        )


def block_to_section(x: int | float, y: int | float, z: int | float) -> RenderSectionKey:
    return RenderSectionKey(
        int(math.floor(float(x) / 16.0)),
        int(math.floor(float(y) / 16.0)),
        int(math.floor(float(z) / 16.0)),
    )


def section_y_range_for_height(height_range: tuple[int, int] | Sequence[int]) -> tuple[int, int]:
    ymin, ymax = int(height_range[0]), int(height_range[1])
    if ymin > ymax:
        ymin, ymax = ymax, ymin
    return (int(math.floor(ymin / 16.0)), int(math.floor(ymax / 16.0)))


def sections_for_block_box(
    bbox: Sequence[int | float],
    *,
    padding_blocks: int = 0,
    include_neighbors: bool = True,
) -> set[RenderSectionKey]:
    """Return all 16x16x16 render sections touched by a block-space bbox.

    include_neighbors adds the immediate section on a touched border so greedy
    mesh faces stay correct when a brush changes blocks exactly on a brick edge.
    """
    if len(bbox) != 6:
        return set()
    x0, y0, z0, x1, y1, z1 = [int(math.floor(float(v))) for v in bbox]
    p = max(0, int(padding_blocks))
    mnx, mxx = sorted((x0, x1)); mnx -= p; mxx += p
    mny, mxy = sorted((y0, y1)); mny -= p; mxy += p
    mnz, mxz = sorted((z0, z1)); mnz -= p; mxz += p

    sx0 = int(math.floor(mnx / 16.0)); sx1 = int(math.floor(mxx / 16.0))
    sy0 = int(math.floor(mny / 16.0)); sy1 = int(math.floor(mxy / 16.0))
    sz0 = int(math.floor(mnz / 16.0)); sz1 = int(math.floor(mxz / 16.0))

    if include_neighbors:
        if mnx % 16 == 0:
            sx0 -= 1
        if mxx % 16 == 15:
            sx1 += 1
        if mny % 16 == 0:
            sy0 -= 1
        if mxy % 16 == 15:
            sy1 += 1
        if mnz % 16 == 0:
            sz0 -= 1
        if mxz % 16 == 15:
            sz1 += 1

    out: set[RenderSectionKey] = set()
    for cz in range(sz0, sz1 + 1):
        for sy in range(sy0, sy1 + 1):
            for cx in range(sx0, sx1 + 1):
                out.add(RenderSectionKey(cx, sy, cz))
    return out


def chunk_columns_for_sections(sections: Iterable[RenderSectionKey]) -> set[tuple[int, int]]:
    return {(int(s.cx), int(s.cz)) for s in sections}


def vertical_band(center_y: float, height_range: tuple[int, int], radius_sections: int) -> range:
    sy_min, sy_max = section_y_range_for_height(height_range)
    csy = int(math.floor(float(center_y) / 16.0))
    r = max(0, int(radius_sections))
    return range(max(sy_min, csy - r), min(sy_max, csy + r) + 1)
