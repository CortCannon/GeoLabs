from __future__ import annotations

"""Read-only Distant Horizons LOD context renderer.

WorldGeoLabs uses Distant Horizons *FullData* as a navigation/background surface only.
The DH database is never modified.  Real Minecraft Anvil chunks remain the source of truth
inside the editable working area.

The reader supports Distant Horizons FullData serialization generations used by modern
3.x releases as well as the older fixed-width layout:
- SQLite table ``FullData``
- DataFormatVersion 1 (legacy fixed-width columns)
- DataFormatVersion 2 (VarInt/predictive-Y columns with adjacent edge blobs)
- CompressionMode 0 (raw), 1 (LZ4 frame), 2/4 (Zstandard), or 3 (XZ/LZMA2)

The database is opened read-only. If its schema/format cannot be decoded, the manager
disables itself and the normal WorldGeoLabs surface streamer remains active.
"""

import array
import concurrent.futures as cf
from contextlib import closing
import logging
import lzma
import math
import os
import sqlite3
import struct
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, Optional

try:
    from PySide6 import QtCore
except Exception:  # allows non-GUI parser/self-tests before SETUP installs Qt
    QtCore = None  # type: ignore

@dataclass
class MeshData:
    vertices: bytes
    vertex_count: int
    lod: str
    materials_version: int = 0
    top_heights: tuple[int, ...] | None = None
    section_y: int | None = None


_AIR = {"minecraft:air", "minecraft:cave_air", "minecraft:void_air"}
_BASE_COLORS = {
    "minecraft:grass_block": (95, 159, 53),
    "minecraft:dirt": (134, 96, 67),
    "minecraft:stone": (125, 125, 125),
    "minecraft:deepslate": (70, 70, 75),
    "minecraft:sand": (219, 211, 160),
    "minecraft:water": (64, 96, 220),
    "minecraft:lava": (240, 110, 20),
    "minecraft:bedrock": (35, 35, 35),
    "minecraft:snow_block": (240, 240, 240),
    "minecraft:ice": (170, 200, 240),
}

log = logging.getLogger("mcgeo.render.distant_horizons")

_REQUIRED_FULLDATA_COLUMNS = {
    "DetailLevel", "PosX", "PosZ", "Data", "Mapping", "DataFormatVersion", "CompressionMode"
}
_SUPPORTED_FORMATS = {1, 2}
_SUPPORTED_COMPRESSIONS = {0, 1, 2, 3, 4}
_TILE_COLUMNS = 64

try:  # optional at import time; SETUP installs it for DH zstd databases
    import zstandard as _zstd  # type: ignore
except Exception:  # pragma: no cover - dependency availability differs by install
    _zstd = None

try:  # optional at import time; SETUP installs it for DH LZ4 databases
    import lz4.frame as _lz4_frame  # type: ignore
except Exception:  # pragma: no cover
    _lz4_frame = None


@dataclass(frozen=True)
class DistantHorizonsInfo:
    db_path: Path
    compatible: bool
    message: str
    detail_levels: tuple[int, ...] = ()
    selected_detail: int | None = None
    selected_rows: int = 0
    sample_stride: int = 1
    compression_modes: tuple[int, ...] = ()
    format_versions: tuple[int, ...] = ()
    table_columns: tuple[str, ...] = ()
    estimated_cells: int = 0

    @property
    def cell_size_blocks(self) -> int:
        if self.selected_detail is None:
            return 0
        return (1 << max(0, int(self.selected_detail))) * max(1, int(self.sample_stride))

    @property
    def tile_span_blocks(self) -> int:
        return _TILE_COLUMNS * self.cell_size_blocks


@dataclass(frozen=True)
class DHTileKey:
    detail: int
    pos_x: int
    pos_z: int


@dataclass(frozen=True)
class _DetailStats:
    detail: int
    rows: int
    min_x: int
    max_x: int
    min_z: int
    max_z: int


def _candidate_dh_paths(world_path: Path, dimension_id: str) -> list[Path]:
    world_path = Path(world_path).expanduser().resolve()
    namespace, _, dim_path = str(dimension_id or "minecraft:overworld").partition(":")
    namespace = namespace or "minecraft"
    dim_path = dim_path or "overworld"

    out: list[Path] = [world_path / "data" / "DistantHorizons.sqlite"]
    if dimension_id == "minecraft:overworld":
        out.extend([
            world_path / "dimensions" / "minecraft" / "overworld" / "data" / "DistantHorizons.sqlite",
            world_path / "DistantHorizons.sqlite",
        ])
    elif dimension_id == "minecraft:the_nether":
        out.extend([
            world_path / "dimensions" / "minecraft" / "the_nether" / "data" / "DistantHorizons.sqlite",
            world_path / "DIM-1" / "data" / "DistantHorizons.sqlite",
        ])
    elif dimension_id == "minecraft:the_end":
        out.extend([
            world_path / "dimensions" / "minecraft" / "the_end" / "data" / "DistantHorizons.sqlite",
            world_path / "DIM1" / "data" / "DistantHorizons.sqlite",
        ])
    else:
        out.append(world_path / "dimensions" / namespace / dim_path / "data" / "DistantHorizons.sqlite")

    # Preserve order but remove duplicate paths.
    seen: set[Path] = set()
    unique: list[Path] = []
    for p in out:
        rp = p.resolve()
        if rp not in seen:
            seen.add(rp)
            unique.append(rp)
    return unique


def find_distant_horizons_database(world_path: Path, dimension_id: str = "minecraft:overworld") -> Path | None:
    """Find a DH SQLite database associated with this Minecraft world/dimension."""
    world_path = Path(world_path).expanduser().resolve()
    for p in _candidate_dh_paths(world_path, dimension_id):
        if p.is_file():
            return p

    # DH paths have moved between releases/loaders.  A bounded recursive fallback lets
    # GeoLabs discover the file without baking in every historical layout.  Ignore backup
    # and trash folders where possible, and prefer paths that mention the requested dimension.
    matches: list[Path] = []
    try:
        for p in world_path.rglob("DistantHorizons.sqlite"):
            try:
                rel = p.relative_to(world_path)
            except Exception:
                continue
            if len(rel.parts) > 8:
                continue
            lowered = "/".join(rel.parts).lower()
            if any(part in lowered for part in ("backup", "backups", ".trash", "recycle")):
                continue
            if p.is_file():
                matches.append(p.resolve())
    except Exception:
        log.debug("DH recursive database discovery failed", exc_info=True)

    if not matches:
        return None
    if dimension_id == "minecraft:overworld":
        matches.sort(key=lambda p: ("overworld" not in str(p).lower(), len(p.parts), str(p).lower()))
    elif dimension_id == "minecraft:the_nether":
        matches.sort(key=lambda p: ("nether" not in str(p).lower() and "dim-1" not in str(p).lower(), len(p.parts), str(p).lower()))
    elif dimension_id == "minecraft:the_end":
        matches.sort(key=lambda p: ("the_end" not in str(p).lower() and "dim1" not in str(p).lower(), len(p.parts), str(p).lower()))
    else:
        token = dimension_id.split(":", 1)[-1].lower()
        matches.sort(key=lambda p: (token not in str(p).lower(), len(p.parts), str(p).lower()))
    return matches[0]


def _connect_ro(db_path: Path) -> sqlite3.Connection:
    # mode=ro prevents accidental writes but still allows SQLite to consult WAL/SHM sidecars.
    uri = f"file:{Path(db_path).resolve().as_posix()}?mode=ro"
    con = sqlite3.connect(uri, uri=True, timeout=2.0)
    con.execute("PRAGMA query_only=ON")
    return con


def _world_block_bounds(chunk_bounds: tuple[int, int, int, int]) -> tuple[int, int, int, int]:
    min_cx, max_cx, min_cz, max_cz = [int(v) for v in chunk_bounds]
    return min_cx * 16, (max_cx + 1) * 16 - 1, min_cz * 16, (max_cz + 1) * 16 - 1


def _row_bounds_for_world(detail: int, chunk_bounds: tuple[int, int, int, int]) -> tuple[int, int, int, int]:
    min_x, max_x, min_z, max_z = _world_block_bounds(chunk_bounds)
    span = _TILE_COLUMNS * (1 << max(0, int(detail)))
    return (
        math.floor(min_x / span),
        math.floor(max_x / span),
        math.floor(min_z / span),
        math.floor(max_z / span),
    )


def inspect_distant_horizons_database(
    db_path: Path,
    chunk_bounds: tuple[int, int, int, int],
    *,
    target_cells: int = 1_000_000,
    max_tiles: int = 2048,
    target_cell_blocks: int | None = None,
) -> DistantHorizonsInfo:
    """Validate a DH database and select a sensible whole-world FullData detail level."""
    db_path = Path(db_path).expanduser().resolve()
    if not db_path.is_file():
        return DistantHorizonsInfo(db_path, False, "database file does not exist")

    try:
        with closing(_connect_ro(db_path)) as con:
            table = con.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='FullData'").fetchone()
            if not table:
                return DistantHorizonsInfo(db_path, False, "FullData table is missing")
            columns = tuple(str(r[1]) for r in con.execute("PRAGMA table_info(FullData)"))
            missing = sorted(_REQUIRED_FULLDATA_COLUMNS - set(columns))
            if missing:
                return DistantHorizonsInfo(db_path, False, f"FullData schema is missing: {', '.join(missing)}", table_columns=columns)

            formats = tuple(sorted(int(r[0]) for r in con.execute("SELECT DISTINCT DataFormatVersion FROM FullData WHERE DataFormatVersion IS NOT NULL")))
            compressions = tuple(sorted(int(r[0]) for r in con.execute("SELECT DISTINCT CompressionMode FROM FullData WHERE CompressionMode IS NOT NULL")))
            unsupported_formats = [v for v in formats if v not in _SUPPORTED_FORMATS]
            if formats and len(unsupported_formats) == len(formats):
                return DistantHorizonsInfo(
                    db_path, False, f"unsupported DH FullData format(s): {formats}",
                    format_versions=formats, compression_modes=compressions, table_columns=columns,
                )
            usable_compressions = [c for c in compressions if c in _SUPPORTED_COMPRESSIONS]
            if compressions and not usable_compressions:
                return DistantHorizonsInfo(
                    db_path, False, f"unsupported DH compression mode(s): {compressions}",
                    format_versions=formats, compression_modes=compressions, table_columns=columns,
                )
            zstd_modes = {2, 4}
            if any(c in zstd_modes for c in usable_compressions) and _zstd is None and not any(c in {0, 1, 3} for c in usable_compressions):
                return DistantHorizonsInfo(
                    db_path, False, "DH database uses Zstandard but the Python 'zstandard' package is not installed",
                    format_versions=formats, compression_modes=compressions, table_columns=columns,
                )
            if 1 in usable_compressions and _lz4_frame is None and not any(c in {0, 2, 3, 4} for c in usable_compressions):
                return DistantHorizonsInfo(
                    db_path, False, "DH database uses LZ4 but the Python 'lz4' package is not installed",
                    format_versions=formats, compression_modes=compressions, table_columns=columns,
                )

            raw_stats: list[_DetailStats] = []
            for row in con.execute(
                "SELECT DetailLevel, COUNT(*), MIN(PosX), MAX(PosX), MIN(PosZ), MAX(PosZ) "
                "FROM FullData GROUP BY DetailLevel ORDER BY DetailLevel"
            ):
                if row[0] is None or int(row[1] or 0) <= 0:
                    continue
                raw_stats.append(_DetailStats(*(int(v) for v in row)))
            if not raw_stats:
                return DistantHorizonsInfo(
                    db_path, False, "FullData contains no LOD rows",
                    format_versions=formats, compression_modes=compressions, table_columns=columns,
                )

            detail_levels = tuple(s.detail for s in raw_stats)
            candidates: list[tuple[int, int, int]] = []  # detail, rows in world, cells
            for stat in raw_stats:
                bx0, bx1, bz0, bz1 = _row_bounds_for_world(stat.detail, chunk_bounds)
                # Fast reject from aggregate extents.
                if stat.max_x < bx0 or stat.min_x > bx1 or stat.max_z < bz0 or stat.min_z > bz1:
                    continue
                rows = int(con.execute(
                    "SELECT COUNT(*) FROM FullData WHERE DetailLevel=? AND PosX BETWEEN ? AND ? AND PosZ BETWEEN ? AND ? "
                    "AND DataFormatVersion IN (1,2) AND CompressionMode IN (0,1,2,3,4)",
                    (stat.detail, bx0, bx1, bz0, bz1),
                ).fetchone()[0])
                if rows <= 0:
                    continue
                cells = rows * (_TILE_COLUMNS * _TILE_COLUMNS)
                candidates.append((stat.detail, rows, cells))

            if not candidates:
                return DistantHorizonsInfo(
                    db_path, False, "no compatible FullData rows overlap this world",
                    detail_levels=detail_levels, format_versions=formats,
                    compression_modes=compressions, table_columns=columns,
                )

            # Prefer the most detailed level whose number of SQLite rows is bounded. The
            # mesh itself can be decimated inside each 64x64 tile, but opening tens of
            # thousands of blobs would defeat the point of using DH for smooth navigation.
            fitting = [c for c in candidates if c[1] <= max_tiles]
            if not fitting:
                coarsest = max(candidates, key=lambda x: x[0])
                return DistantHorizonsInfo(
                    db_path, False,
                    f"DH has no sufficiently coarse FullData level ({coarsest[1]:,} tiles at coarsest available detail {coarsest[0]})",
                    detail_levels=detail_levels, format_versions=formats,
                    compression_modes=compressions, table_columns=columns,
                )
            chosen = min(fitting, key=lambda x: x[0])
            detail, rows, raw_cells = chosen
            # Choose a power-of-two sampling stride. If the user requested an explicit
            # DH display-cell size, honor it as closely as possible while never sampling
            # finer than the source detail. Otherwise retain the automatic whole-world
            # cell budget used by earlier builds.
            stride = 1
            base_cell = 1 << max(0, int(detail))
            if target_cell_blocks is not None and int(target_cell_blocks) > 0:
                requested = max(base_cell, int(target_cell_blocks))
                while (base_cell * stride) < requested and stride < _TILE_COLUMNS:
                    stride *= 2
            else:
                while rows * ((_TILE_COLUMNS // stride) ** 2) > max(1, int(target_cells)) and stride < _TILE_COLUMNS:
                    stride *= 2
            cells = rows * ((_TILE_COLUMNS // stride) ** 2)

            unavailable_compression_note = ""
            if any(c in {2, 4} for c in compressions) and _zstd is None:
                unavailable_compression_note += "; zstd rows require the 'zstandard' package"
            if 1 in compressions and _lz4_frame is None:
                unavailable_compression_note += "; LZ4 rows require the 'lz4' package"

            return DistantHorizonsInfo(
                db_path=db_path,
                compatible=True,
                message=(
                    f"DH FullData ready: detail {detail}, {rows:,} tile(s), "
                    f"{(1 << detail) * stride} block(s)/display cell{unavailable_compression_note}"
                ),
                detail_levels=detail_levels,
                selected_detail=detail,
                selected_rows=rows,
                sample_stride=stride,
                compression_modes=compressions,
                format_versions=formats,
                table_columns=columns,
                estimated_cells=cells,
            )
    except sqlite3.Error as exc:
        return DistantHorizonsInfo(db_path, False, f"SQLite error: {exc}")
    except Exception as exc:
        log.exception("Failed to inspect DH database %s", db_path)
        return DistantHorizonsInfo(db_path, False, str(exc))


def inspect_world_distant_horizons(
    world_path: Path,
    chunk_bounds: tuple[int, int, int, int],
    dimension_id: str = "minecraft:overworld",
) -> DistantHorizonsInfo | None:
    db = find_distant_horizons_database(world_path, dimension_id)
    if db is None:
        return None
    return inspect_distant_horizons_database(db, chunk_bounds)


def _decompress(blob: bytes, compression_mode: int) -> bytes:
    """Mirror DH's EDhApiDataCompressionMode values.

    0=UNCOMPRESSED, 1=LZ4 frame, 2=legacy Zstd stream,
    3=LZMA2/XZ, 4=current Zstd block/frame.
    """
    mode = int(compression_mode)
    payload = bytes(blob)
    if mode == 0:
        return payload
    if mode == 1:
        if _lz4_frame is None:
            raise RuntimeError("LZ4-compressed DH data requires the 'lz4' Python package")
        return _lz4_frame.decompress(payload)
    if mode == 3:
        return lzma.decompress(payload, format=lzma.FORMAT_XZ)
    if mode in {2, 4}:
        if _zstd is None:
            raise RuntimeError("Zstandard-compressed DH data requires the 'zstandard' Python package")
        dctx = _zstd.ZstdDecompressor()
        try:
            return dctx.decompress(payload)
        except Exception:
            # Legacy Z_STD_STREAM frames may omit a decompressed-size hint. stream_reader
            # handles both bounded and streaming frames without requiring that metadata.
            import io
            with dctx.stream_reader(io.BytesIO(payload)) as reader:
                return reader.read()
    raise RuntimeError(f"Unsupported DH CompressionMode {mode}")


def _read_java_utf(data: memoryview, offset: int) -> tuple[str, int]:
    if offset + 2 > len(data):
        raise ValueError("truncated Java UTF length")
    n = struct.unpack_from(">H", data, offset)[0]
    offset += 2
    if offset + n > len(data):
        raise ValueError("truncated Java UTF payload")
    raw = bytes(data[offset:offset + n])
    offset += n
    # Minecraft resource IDs are overwhelmingly ASCII/UTF-8. Java modified UTF-8 differs
    # for NUL/supplementary characters, neither of which is valid/typical in resource IDs.
    return raw.decode("utf-8", "replace"), offset


def _decode_mapping(mapping_blob: bytes, compression_mode: int) -> list[str]:
    raw = memoryview(_decompress(mapping_blob, compression_mode))
    if len(raw) < 4:
        raise ValueError("DH mapping blob is too short")
    count = int(struct.unpack_from(">i", raw, 0)[0])
    if count < 0 or count > 2_000_000:
        raise ValueError(f"unreasonable DH mapping count: {count}")
    offset = 4
    out: list[str] = []
    for _ in range(count):
        text, offset = _read_java_utf(raw, offset)
        out.append(_mapping_entry_to_block(text))
    return out


def _mapping_entry_to_block(text: str) -> str:
    if text == "AIR" or text.endswith("_DH-BSW_AIR"):
        return "minecraft:air"
    marker = "_DH-BSW_"
    if marker in text:
        block = text.split(marker, 1)[1]
        if "_STATE_" in block:
            block = block.split("_STATE_", 1)[0]
        block = block.strip()
        if block:
            return block
    # Some versions/tools may already serialize a bare block id.
    value = text.strip()
    if ":" in value and " " not in value:
        return value
    return "minecraft:stone"


def _decode_top_columns_v1(data_blob: bytes, compression_mode: int, mapping: list[str], world_min_y: int) -> list[tuple[int, str] | None]:
    raw = memoryview(_decompress(data_blob, compression_mode))
    offset = 0
    result: list[tuple[int, str] | None] = []
    for _column in range(_TILE_COLUMNS * _TILE_COLUMNS):
        if offset + 2 > len(raw):
            raise ValueError(f"DH data ended after {len(result)} columns")
        count = int(struct.unpack_from(">H", raw, offset)[0])
        offset += 2
        best_top: int | None = None
        best_name = "minecraft:air"
        need = count * 8
        if offset + need > len(raw):
            raise ValueError("truncated DH column data")
        for _ in range(count):
            value = int(struct.unpack_from(">Q", raw, offset)[0])
            offset += 8
            mapping_id = value & 0x7FFFFFFF
            height = (value >> 32) & 0xFFF
            min_height = (value >> 44) & 0xFFF
            if mapping_id >= len(mapping):
                continue
            name = mapping[mapping_id]
            if name in _AIR:
                continue
            top_y = int(world_min_y) + int(min_height) + int(height)
            if best_top is None or top_y > best_top:
                best_top = top_y
                best_name = name
        result.append(None if best_top is None else (best_top, best_name))
    return result


def _read_varint(raw: memoryview, offset: int) -> tuple[int, int]:
    """Read DH/VarintUtil's unsigned 32-bit varint."""
    value = 0
    shift = 0
    while True:
        if offset >= len(raw):
            raise ValueError("truncated DH varint")
        b = int(raw[offset])
        offset += 1
        value |= (b & 0x7F) << shift
        if (b & 0x80) == 0:
            return value, offset
        shift += 7
        if shift >= 32:
            raise ValueError("invalid DH varint")


def _zigzag_decode(value: int) -> int:
    return (int(value) >> 1) ^ -(int(value) & 1)


def _decode_top_columns_v2_blob(
    data_blob: bytes,
    compression_mode: int,
    mapping: list[str],
    world_min_y: int,
    *,
    min_x: int, max_x: int, min_z: int, max_z: int,
    result: list[tuple[int, str] | None],
) -> None:
    """Decode one format-2 FullData blob into a shared 64x64 top-surface array.

    DH V2 serializes in five passes: column lengths, ID+flags, heights, predictive
    bottom-Y corrections, then optional light bytes.  Only the first four stages are
    needed for WorldGeoLabs' far navigation surface.
    """
    raw = memoryview(_decompress(data_blob, compression_mode))
    offset = 0
    coords = [(x, z) for x in range(int(min_x), int(max_x)) for z in range(int(min_z), int(max_z))]
    counts: list[int] = []
    total_points = 0
    for _ in coords:
        count, offset = _read_varint(raw, offset)
        if count < 0 or count > 4096:
            raise ValueError(f"unreasonable DH V2 column length: {count}")
        counts.append(count)
        total_points += count
    if total_points > len(coords) * 4096:
        raise ValueError("unreasonable DH V2 datapoint count")

    # One compact flat list keeps the staged layout easy to mirror without thousands
    # of tiny Python objects. Each item is [mapping_id, flags, height, bottom_y].
    points: list[list[int]] = []
    for count in counts:
        for _ in range(count):
            encoded, offset = _read_varint(raw, offset)
            points.append([encoded >> 2, encoded & 0x3, 0, 0])

    for point in points:
        height, offset = _read_varint(raw, offset)
        point[2] = height

    previous_bottom_y = 0
    for point in points:
        mapping_id, flags, height, _ = point
        error = 0
        if flags & 0x1:
            encoded_error, offset = _read_varint(raw, offset)
            error = _zigzag_decode(encoded_error)
        bottom_y = previous_bottom_y - height + error
        point[3] = bottom_y
        previous_bottom_y = bottom_y

    # Light bytes follow. They do not affect GeoLabs' terrain context mesh, but consume
    # them for structural validation so malformed blobs fail before activation.
    lit_points = sum(1 for pnt in points if pnt[1] & 0x2)
    if offset + lit_points > len(raw):
        raise ValueError("truncated DH V2 light data")
    offset += lit_points

    p = 0
    for (x, z), count in zip(coords, counts):
        best_top: int | None = None
        best_name = "minecraft:air"
        for _ in range(count):
            mapping_id, _flags, height, bottom_y = points[p]
            p += 1
            if mapping_id < 0 or mapping_id >= len(mapping):
                continue
            name = mapping[mapping_id]
            if name in _AIR:
                continue
            top_y = int(world_min_y) + int(bottom_y) + int(height)
            if best_top is None or top_y > best_top:
                best_top = top_y
                best_name = name
        result[z * _TILE_COLUMNS + x] = None if best_top is None else (best_top, best_name)


def _decode_top_columns_v2(
    data_blob: bytes, compression_mode: int, mapping: list[str], world_min_y: int,
    adjacent_blobs: tuple[bytes | None, bytes | None, bytes | None, bytes | None] | None = None,
) -> list[tuple[int, str] | None]:
    """Decode modern DH FullData V2, including edge blobs when present."""
    result: list[tuple[int, str] | None] = [None] * (_TILE_COLUMNS * _TILE_COLUMNS)
    # Main V2 Data intentionally excludes the one-cell border.
    _decode_top_columns_v2_blob(
        data_blob, compression_mode, mapping, world_min_y,
        min_x=1, max_x=_TILE_COLUMNS - 1, min_z=1, max_z=_TILE_COLUMNS - 1, result=result,
    )

    if adjacent_blobs:
        north, south, east, west = adjacent_blobs
        if north:
            _decode_top_columns_v2_blob(north, compression_mode, mapping, world_min_y, min_x=0, max_x=64, min_z=0, max_z=1, result=result)
        if south:
            _decode_top_columns_v2_blob(south, compression_mode, mapping, world_min_y, min_x=0, max_x=64, min_z=63, max_z=64, result=result)
        if east:
            _decode_top_columns_v2_blob(east, compression_mode, mapping, world_min_y, min_x=63, max_x=64, min_z=0, max_z=64, result=result)
        if west:
            _decode_top_columns_v2_blob(west, compression_mode, mapping, world_min_y, min_x=0, max_x=1, min_z=0, max_z=64, result=result)

    # Current DH databases carry all four adjacent blobs.  If an early/partial V2 row
    # lacks one, replicate the nearest interior cell rather than producing a visible gap.
    for z in range(_TILE_COLUMNS):
        for x in range(_TILE_COLUMNS):
            idx = z * _TILE_COLUMNS + x
            if result[idx] is None and (x in {0, 63} or z in {0, 63}):
                sx = min(62, max(1, x))
                sz = min(62, max(1, z))
                result[idx] = result[sz * _TILE_COLUMNS + sx]
    return result


def _rgb_for_block(name: str) -> tuple[float, float, float]:
    import hashlib
    rgb = _BASE_COLORS.get(name)
    if rgb is None:
        h = hashlib.md5(name.encode("utf-8", "replace")).digest()
        rgb = (40 + h[0] % 160, 40 + h[1] % 160, 40 + h[2] % 160)
    return rgb[0] / 255.0, rgb[1] / 255.0, rgb[2] / 255.0


def _push_vertex(buf: array.array, x: float, y: float, z: float, rgb: tuple[float, float, float]) -> None:
    buf.extend((float(x), float(y), float(z), float(rgb[0]), float(rgb[1]), float(rgb[2]), 0.0))


def _push_top_quad(buf: array.array, x0: float, z0: float, size: float, y: float, rgb: tuple[float, float, float]) -> None:
    # Slight elevation prevents coplanar flicker where context meets other context tiles.
    yy = float(y) + 0.02
    x1 = x0 + size
    z1 = z0 + size
    _push_vertex(buf, x0, yy, z0, rgb)
    _push_vertex(buf, x1, yy, z0, rgb)
    _push_vertex(buf, x1, yy, z1, rgb)
    _push_vertex(buf, x0, yy, z0, rgb)
    _push_vertex(buf, x1, yy, z1, rgb)
    _push_vertex(buf, x0, yy, z1, rgb)


def _push_heightfield_quad(
    buf: array.array, x0: float, z0: float, size: float,
    y00: float, y10: float, y11: float, y01: float,
    rgb: tuple[float, float, float],
) -> None:
    """Emit a continuous sloped surface cell instead of a floating flat plate.

    Neighboring cells reuse the same boundary-height calculation, so normal terrain
    no longer looks like disconnected checkerboard slabs when viewed obliquely.
    """
    e = 0.02
    x1 = float(x0) + float(size)
    z1 = float(z0) + float(size)
    p00 = (float(x0), float(y00) + e, float(z0))
    p10 = (x1, float(y10) + e, float(z0))
    p11 = (x1, float(y11) + e, z1)
    p01 = (float(x0), float(y01) + e, z1)
    for p in (p00, p10, p11, p00, p11, p01):
        _push_vertex(buf, p[0], p[1], p[2], rgb)


def _build_dh_tile_mesh(
    db_path_str: str,
    detail: int,
    pos_x: int,
    pos_z: int,
    world_min_y: int,
    sample_stride: int = 1,
) -> dict:
    """Process-pool worker: load one FullData row and turn it into a top-surface GL mesh."""
    key = DHTileKey(int(detail), int(pos_x), int(pos_z))
    try:
        db_path = Path(db_path_str)
        with closing(_connect_ro(db_path)) as con:
            columns = {str(r[1]) for r in con.execute("PRAGMA table_info(FullData)")}
            has_adjacent = {"NorthAdjData", "SouthAdjData", "EastAdjData", "WestAdjData"}.issubset(columns)
            select_cols = "Data, Mapping, CompressionMode, DataFormatVersion"
            if has_adjacent:
                select_cols += ", NorthAdjData, SouthAdjData, EastAdjData, WestAdjData"
            row = con.execute(
                f"SELECT {select_cols} FROM FullData WHERE DetailLevel=? AND PosX=? AND PosZ=? LIMIT 1",
                (key.detail, key.pos_x, key.pos_z),
            ).fetchone()
        if row is None:
            return {"ok": False, "key": key, "err": "row disappeared"}
        data_blob, mapping_blob, compression_mode, data_format = row[:4]
        adjacent = tuple(bytes(v) if v is not None else None for v in row[4:8]) if len(row) >= 8 else None
        if int(data_format) not in _SUPPORTED_FORMATS:
            raise RuntimeError(f"unsupported DH DataFormatVersion {data_format}")
        if int(compression_mode) not in _SUPPORTED_COMPRESSIONS:
            raise RuntimeError(f"unsupported DH CompressionMode {compression_mode}")

        mapping = _decode_mapping(bytes(mapping_blob), int(compression_mode))
        if int(data_format) == 1:
            cols = _decode_top_columns_v1(bytes(data_blob), int(compression_mode), mapping, int(world_min_y))
        elif int(data_format) == 2:
            cols = _decode_top_columns_v2(bytes(data_blob), int(compression_mode), mapping, int(world_min_y), adjacent)
        else:  # guarded above; keeps static analyzers honest
            raise RuntimeError(f"unsupported DH DataFormatVersion {data_format}")
        base_cell = 1 << max(0, key.detail)
        sample_stride = max(1, min(_TILE_COLUMNS, int(sample_stride)))
        cell = base_cell * sample_stride
        span = _TILE_COLUMNS * base_cell
        origin_x = key.pos_x * span
        origin_z = key.pos_z * span
        verts = array.array("f")
        color_cache: dict[str, tuple[float, float, float]] = {}

        # Build a coarse height field first.  v0.16.29 emitted every retained DH
        # sample as an independent horizontal quad.  From an oblique camera that
        # leaves black cracks anywhere adjacent samples have different elevations.
        # A shared boundary-height grid produces one continuous navigation surface.
        coarse_n = _TILE_COLUMNS // sample_stride
        coarse: list[list[tuple[float, str] | None]] = [[None for _ in range(coarse_n)] for __ in range(coarse_n)]
        for gz in range(coarse_n):
            iz = gz * sample_stride
            for gx in range(coarse_n):
                ix = gx * sample_stride
                samples: list[tuple[int, str]] = []
                for sz in range(iz, min(_TILE_COLUMNS, iz + sample_stride)):
                    for sx in range(ix, min(_TILE_COLUMNS, ix + sample_stride)):
                        col = cols[sz * _TILE_COLUMNS + sx]
                        if col is not None:
                            samples.append(col)
                if samples:
                    y = sum(v[0] for v in samples) / float(len(samples))
                    block = max(samples, key=lambda v: v[0])[1]
                    coarse[gz][gx] = (float(y), str(block))

        def node_height(nx: int, nz: int) -> float | None:
            vals: list[float] = []
            for dz in (-1, 0):
                for dx in (-1, 0):
                    cx = nx + dx
                    cz = nz + dz
                    if 0 <= cx < coarse_n and 0 <= cz < coarse_n:
                        c = coarse[cz][cx]
                        if c is not None:
                            vals.append(float(c[0]))
            if not vals:
                return None
            return sum(vals) / float(len(vals))

        for gz in range(coarse_n):
            for gx in range(coarse_n):
                c = coarse[gz][gx]
                if c is None:
                    continue
                y00 = node_height(gx, gz)
                y10 = node_height(gx + 1, gz)
                y11 = node_height(gx + 1, gz + 1)
                y01 = node_height(gx, gz + 1)
                if None in (y00, y10, y11, y01):
                    continue
                block = c[1]
                rgb = color_cache.get(block)
                if rgb is None:
                    rgb = _rgb_for_block(block)
                    color_cache[block] = rgb
                _push_heightfield_quad(
                    verts,
                    float(origin_x + gx * cell),
                    float(origin_z + gz * cell),
                    float(cell),
                    float(y00), float(y10), float(y11), float(y01),
                    rgb,
                )
        mesh = MeshData(
            vertices=verts.tobytes(),
            vertex_count=len(verts) // 7,
            lod="dh_context",
            materials_version=0,
            top_heights=None,
            section_y=None,
        )
        # Keep a compact CPU-side surface grid for LOD editing/picking. This is
        # independent of the batched GPU mesh and avoids opening/decompressing Anvil
        # chunks simply to place a coarse surface edit.
        heights = []
        blocks = []
        for rowc in coarse:
            for c in rowc:
                if c is None:
                    heights.append(float('nan'))
                    blocks.append('minecraft:air')
                else:
                    heights.append(float(c[0]))
                    blocks.append(str(c[1]))
        surface = {
            "origin_x": int(origin_x), "origin_z": int(origin_z),
            "cell": int(cell), "n": int(coarse_n),
            "heights": tuple(heights), "blocks": tuple(blocks),
        }
        return {"ok": True, "key": key, "mesh": mesh, "surface": surface, "err": ""}
    except Exception as exc:
        return {"ok": False, "key": key, "err": str(exc)}


def _list_selected_rows(db_path: Path, detail: int, chunk_bounds: tuple[int, int, int, int]) -> list[DHTileKey]:
    bx0, bx1, bz0, bz1 = _row_bounds_for_world(int(detail), chunk_bounds)
    with closing(_connect_ro(db_path)) as con:
        rows = con.execute(
            "SELECT PosX, PosZ FROM FullData WHERE DetailLevel=? "
            "AND PosX BETWEEN ? AND ? AND PosZ BETWEEN ? AND ? "
            "AND DataFormatVersion IN (1,2) AND CompressionMode IN (0,1,2,3,4) ORDER BY PosZ, PosX",
            (int(detail), bx0, bx1, bz0, bz1),
        ).fetchall()
    return [DHTileKey(int(detail), int(x), int(z)) for x, z in rows]


_QtObjectBase = QtCore.QObject if QtCore is not None else object


class DistantHorizonsLodManager(_QtObjectBase):
    """Progressively builds a read-only whole-world DH background mesh."""

    if QtCore is not None:
        tile_ready = QtCore.Signal(object, object)  # GPU batch key, MeshData
        surface_ready = QtCore.Signal(object, object)  # DHTileKey, compact CPU surface grid
        activated = QtCore.Signal(bool, object)     # active, DistantHorizonsInfo|None
        status_changed = QtCore.Signal(str)
        progress_changed = QtCore.Signal(int, int)  # ready, total
        load_finished = QtCore.Signal()

    def __init__(
        self,
        world_path: Path,
        chunk_bounds: tuple[int, int, int, int],
        world_min_y: int,
        dimension_id: str = "minecraft:overworld",
        *,
        workers: int = 0,
        target_cell_blocks: int | None = None,
    ) -> None:
        if QtCore is None:
            raise RuntimeError("PySide6 is required for the live Distant Horizons LOD manager")
        super().__init__()
        self.world_path = Path(world_path).expanduser().resolve()
        self.chunk_bounds = tuple(int(v) for v in chunk_bounds)
        self.world_min_y = int(world_min_y)
        self.dimension_id = str(dimension_id or "minecraft:overworld")
        self.workers = max(1, min(int(workers or max(1, (os.cpu_count() or 4) // 2)), 16))
        self.target_cell_blocks = None if target_cell_blocks is None else max(1, int(target_cell_blocks))
        self.info: DistantHorizonsInfo | None = None
        self.total_tiles = 0
        self.ready_tiles = 0
        self.failed_tiles = 0
        self._executor: cf.ProcessPoolExecutor | None = None
        self._futures: set[cf.Future] = set()
        self._closed = False
        self._activation_emitted = False
        self._load_completed = False
        self._batch_parts: list[MeshData] = []
        self._batch_index = 0
        self._batch_size = max(8, int(os.environ.get("WGL_DH_BATCH_TILES", "32") or "32"))
        self._lock = threading.Lock()
        self.load_finished.connect(self._release_executor)

    def start(self) -> None:
        if self._closed:
            return
        if str(os.environ.get("WGL_DISABLE_DH_LOD", "")).strip().lower() in {"1", "true", "yes", "on"}:
            self.status_changed.emit("Distant Horizons LOD disabled by WGL_DISABLE_DH_LOD; using GeoLabs surface streaming.")
            self.activated.emit(False, None)
            return
        db = find_distant_horizons_database(self.world_path, self.dimension_id)
        if db is None:
            self.status_changed.emit("No Distant Horizons database found; using GeoLabs surface streaming.")
            self.activated.emit(False, None)
            return

        self.status_changed.emit(f"Found Distant Horizons LOD database: {db.name}. Checking compatibility…")
        info = inspect_distant_horizons_database(db, self.chunk_bounds, target_cell_blocks=self.target_cell_blocks)
        self.info = info
        if not info.compatible or info.selected_detail is None:
            self.status_changed.emit(f"Distant Horizons LOD disabled: {info.message}")
            self.activated.emit(False, info)
            return

        try:
            keys = _list_selected_rows(info.db_path, info.selected_detail, self.chunk_bounds)
        except Exception as exc:
            bad = DistantHorizonsInfo(info.db_path, False, f"could not enumerate DH tiles: {exc}")
            self.info = bad
            self.status_changed.emit(f"Distant Horizons LOD disabled: {bad.message}")
            self.activated.emit(False, bad)
            return

        if not keys:
            self.status_changed.emit("Distant Horizons LOD disabled: no compatible tiles overlap the world.")
            self.activated.emit(False, info)
            return

        self.total_tiles = len(keys)
        self.ready_tiles = 0
        self.failed_tiles = 0
        self.status_changed.emit(
            f"Loading Distant Horizons world context: detail {info.selected_detail}, "
            f"{info.cell_size_blocks} block(s)/cell, {len(keys):,} tile(s). "
            "Anvil surface streaming stays active until the first DH tile validates."
        )
        self.progress_changed.emit(0, self.total_tiles)

        self._executor = cf.ProcessPoolExecutor(max_workers=self.workers)
        for key in keys:
            if self._closed:
                break
            fut = self._executor.submit(
                _build_dh_tile_mesh,
                str(info.db_path), key.detail, key.pos_x, key.pos_z, self.world_min_y, info.sample_stride,
            )
            self._futures.add(fut)
            fut.add_done_callback(self._future_done)

    def _emit_batch(self, parts: list[MeshData]) -> None:
        if not parts or self._closed:
            return
        vertices = b"".join(bytes(m.vertices or b"") for m in parts if int(getattr(m, "vertex_count", 0)) > 0)
        vertex_count = sum(int(getattr(m, "vertex_count", 0)) for m in parts)
        if vertex_count <= 0 or not vertices:
            return
        key = ("dh_batch", int(self._batch_index))
        self._batch_index += 1
        mesh = MeshData(vertices=vertices, vertex_count=vertex_count, lod="dh_context", materials_version=0, top_heights=None, section_y=None)
        self.tile_ready.emit(key, mesh)

    def _future_done(self, fut: cf.Future) -> None:
        try:
            result = fut.result()
        except Exception as exc:
            result = {"ok": False, "key": None, "err": str(exc)}

        batch_to_emit: list[MeshData] = []
        final_batch: list[MeshData] = []
        emit_activation = False
        finished = False
        with self._lock:
            self._futures.discard(fut)
            if self._closed:
                return
            if bool(result.get("ok")):
                self.ready_tiles += 1
                mesh = result.get("mesh")
                if mesh is not None and int(getattr(mesh, "vertex_count", 0)) > 0:
                    self._batch_parts.append(mesh)
                if not self._activation_emitted:
                    self._activation_emitted = True
                    emit_activation = True
                if len(self._batch_parts) >= self._batch_size:
                    batch_to_emit = self._batch_parts[:]
                    self._batch_parts.clear()
            else:
                self.failed_tiles += 1
            done = self.ready_tiles + self.failed_tiles
            if done >= self.total_tiles and not self._load_completed:
                self._load_completed = True
                finished = True
                if self._batch_parts:
                    final_batch = self._batch_parts[:]
                    self._batch_parts.clear()

        if bool(result.get("ok")) and result.get("surface") is not None and result.get("key") is not None:
            try:
                self.surface_ready.emit(result.get("key"), result.get("surface"))
            except Exception:
                log.debug("Could not emit DH CPU surface tile", exc_info=True)

        if emit_activation:
            self.activated.emit(True, self.info)
            self.status_changed.emit(
                f"Distant Horizons validated and active: detail {getattr(self.info, 'selected_detail', '?')}, "
                f"{getattr(self.info, 'cell_size_blocks', '?')} block(s)/display cell."
            )
        if batch_to_emit:
            self._emit_batch(batch_to_emit)
        if not bool(result.get("ok")) and self.failed_tiles <= 5:
            log.warning("DH tile build failed %s: %s", result.get("key"), result.get("err"))

        done = self.ready_tiles + self.failed_tiles
        self.progress_changed.emit(done, self.total_tiles)
        if finished:
            if final_batch:
                self._emit_batch(final_batch)
            msg = f"Distant Horizons context ready: {self.ready_tiles:,}/{self.total_tiles:,} tile(s); {self._batch_index:,} GPU batch mesh(es)"
            if self.failed_tiles:
                msg += f"; {self.failed_tiles:,} skipped"
            if self.ready_tiles <= 0:
                msg = "Distant Horizons decode failed for every tile; keeping GeoLabs Anvil surface fallback."
                self.activated.emit(False, self.info)
            self.status_changed.emit(msg)
            self.load_finished.emit()

    def _release_executor(self) -> None:
        ex = self._executor
        self._executor = None
        if ex is not None:
            try:
                ex.shutdown(wait=False, cancel_futures=False)
            except TypeError:
                ex.shutdown(wait=False)
            except Exception:
                log.debug("Could not release completed DH executor", exc_info=True)

    def shutdown(self) -> None:
        self._closed = True
        with self._lock:
            futures = list(self._futures)
            self._futures.clear()
        for fut in futures:
            try:
                fut.cancel()
            except Exception:
                pass
        ex = self._executor
        self._executor = None
        if ex is not None:
            try:
                ex.shutdown(wait=False, cancel_futures=True)
            except TypeError:  # older Python
                ex.shutdown(wait=False)
            except Exception:
                pass
