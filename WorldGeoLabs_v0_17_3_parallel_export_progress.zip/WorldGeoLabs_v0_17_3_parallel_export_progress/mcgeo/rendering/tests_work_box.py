from __future__ import annotations

import tempfile
from pathlib import Path

from ..world.tests_exporter_roundtrip import _make_world
from .stream_manager import _process_build_task


def run() -> bool:
    with tempfile.TemporaryDirectory(prefix="wgl_workbox_test_") as td:
        world = _make_world(Path(td), modern=True)
        result = _process_build_task(
            str(world), 0, 0, "voxel", {}, "preview:off", None, 15, (0, 0)
        )
        assert bool(result.get("ok")), result
        assert tuple(result.get("section_range") or ()) == (0, 0), result
        assert int(result.get("vertex_count", 0)) > 0, result
    print("Detailed 3D work-box section test OK")
    return True


if __name__ == "__main__":
    raise SystemExit(0 if run() else 2)
