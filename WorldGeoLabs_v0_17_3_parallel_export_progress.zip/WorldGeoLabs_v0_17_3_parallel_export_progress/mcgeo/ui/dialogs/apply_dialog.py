from __future__ import annotations
import os
from pathlib import Path
from PySide6 import QtWidgets, QtCore


class ApplyDialog(QtWidgets.QDialog):
    def __init__(self, parent=None, summary: dict | None = None) -> None:
        super().__init__(parent)
        self.setWindowTitle("Export / Apply Changes")
        self.setModal(True)
        self.resize(700, 560)
        self._summary = dict(summary or {})

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(10)

        title = QtWidgets.QLabel("Incremental map export")
        title.setObjectName("PanelTitle")
        subtitle = QtWidgets.QLabel(
            "Export writes only region files that contain visible/enabled paint-layer changes, including generated geology/resource layers. "
            "The recommended mode creates a timestamped world copy first, then replaces only the changed .mca files in that copy."
        )
        subtitle.setObjectName("SubtleHint")
        subtitle.setWordWrap(True)
        layout.addWidget(title)
        layout.addWidget(subtitle)

        summary_box = QtWidgets.QGroupBox("Session summary")
        form = QtWidgets.QFormLayout(summary_box)
        form.setLabelAlignment(QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignVCenter)
        self.lbl_world = QtWidgets.QLabel(str(self._summary.get("world_name") or "No world loaded"))
        self.lbl_area = QtWidgets.QLabel(str(self._summary.get("area_label") or "Area not selected"))
        self.lbl_layers = QtWidgets.QLabel(str(self._summary.get("layer_summary") or "No layers"))
        self.lbl_preview = QtWidgets.QLabel(str(self._summary.get("preview_summary") or "No preview layers active"))
        self.lbl_notes = QtWidgets.QLabel(str(self._summary.get("notes") or ""))
        self.lbl_notes.setWordWrap(True)
        form.addRow("World", self.lbl_world)
        form.addRow("Edit area", self.lbl_area)
        form.addRow("Layers", self.lbl_layers)
        form.addRow("Export", self.lbl_preview)
        form.addRow("Notes", self.lbl_notes)
        layout.addWidget(summary_box)

        dest_box = QtWidgets.QGroupBox("Destination")
        dlay = QtWidgets.QVBoxLayout(dest_box)
        self.apply_copy = QtWidgets.QRadioButton("Export to timestamped copy (recommended)")
        self.apply_copy.setChecked(True)
        self.apply_inplace = QtWidgets.QRadioButton("Apply directly to opened world (advanced)")
        dlay.addWidget(self.apply_copy)
        dlay.addWidget(self.apply_inplace)
        self.dest_hint = QtWidgets.QLabel("")
        self.dest_hint.setObjectName("SubtleHint")
        self.dest_hint.setWordWrap(True)
        dlay.addWidget(self.dest_hint)
        layout.addWidget(dest_box)

        options_box = QtWidgets.QGroupBox("Options")
        opt = QtWidgets.QFormLayout(options_box)
        self.use_seed = QtWidgets.QCheckBox("Override export seed")
        self.seed = QtWidgets.QLineEdit()
        self.seed.setPlaceholderText("Seed (integer, default 1337)")
        self.seed.setEnabled(False)
        self.use_seed.toggled.connect(self.seed.setEnabled)
        opt.addRow(self.use_seed)
        opt.addRow("Seed", self.seed)

        logical = max(1, int(os.cpu_count() or 1))
        self.export_workers = QtWidgets.QSpinBox()
        self.export_workers.setRange(0, logical)
        self.export_workers.setValue(0)
        self.export_workers.setSpecialValueText(f"Auto — all {logical} logical CPUs")
        self.export_workers.setToolTip("Changed .mca region files are independent and can be processed in parallel. Auto uses all logical CPUs, capped by the number of changed regions.")
        opt.addRow("Region workers", self.export_workers)

        self.copy_workers = QtWidgets.QSpinBox()
        self.copy_workers.setRange(0, max(1, min(32, logical)))
        self.copy_workers.setValue(0)
        self.copy_workers.setSpecialValueText(f"Auto — up to {min(8, logical)} I/O workers")
        self.copy_workers.setToolTip("World copying is usually limited by storage throughput rather than CPU. Auto uses a small parallel file-copy pool.")
        opt.addRow("Copy workers", self.copy_workers)

        io_hint = QtWidgets.QLabel("During the copy stage, low CPU usage can be normal because the drive is the bottleneck. The export window now reports bytes copied, throughput and ETA. Changed-region processing uses the Region workers setting.")
        io_hint.setObjectName("SubtleHint")
        io_hint.setWordWrap(True)
        opt.addRow("", io_hint)
        layout.addWidget(options_box)

        self.review = QtWidgets.QPlainTextEdit()
        self.review.setReadOnly(True)
        self.review.setMaximumBlockCount(400)
        self.review.setPlainText(self._build_review_text())
        layout.addWidget(self.review, 1)

        btns = QtWidgets.QDialogButtonBox(
            QtWidgets.QDialogButtonBox.StandardButton.Ok |
            QtWidgets.QDialogButtonBox.StandardButton.Cancel
        )
        ok = btns.button(QtWidgets.QDialogButtonBox.StandardButton.Ok)
        if ok is not None:
            ok.setText("Export")
        btns.accepted.connect(self.accept)
        btns.rejected.connect(self.reject)
        layout.addWidget(btns)

        self.apply_copy.toggled.connect(self._refresh_destination_hint)
        self.apply_inplace.toggled.connect(self._refresh_destination_hint)
        self._refresh_destination_hint()

    def destination_mode(self) -> str:
        return "inplace" if self.apply_inplace.isChecked() else "copy"

    def export_seed(self) -> int:
        if not self.use_seed.isChecked():
            return 1337
        try:
            return int(str(self.seed.text()).strip())
        except Exception:
            return 1337

    def region_workers(self) -> int:
        return int(self.export_workers.value())

    def world_copy_workers(self) -> int:
        return int(self.copy_workers.value())

    def _build_review_text(self) -> str:
        lines = [
            "Incremental export status: paint-layer export milestone.",
            "",
            f"World: {self._summary.get('world_path') or '—'}",
            f"Project: {self._summary.get('project_path') or 'Unsaved session'}",
            f"Area: {self._summary.get('area_label') or 'Not selected'}",
            f"Layer stack: {self._summary.get('layer_summary') or 'No layers'}",
            f"Export plan: {self._summary.get('preview_summary') or 'No visible paint strokes'}",
        ]
        warnings = list(self._summary.get('warnings') or [])
        if warnings:
            lines.extend(["", "Warnings:"])
            lines.extend([f"- {w}" for w in warnings])
        lines.extend([
            "",
            "Export writes visible/enabled Paint layers, including generated Geological Resource layers.",
            "It does not regenerate the whole world and does not rewrite unchanged region files.",
            "Legacy cave/ore generator previews remain preview-only; heightmap/light recalculation is still a follow-up pass.",
        ])
        return "\n".join(lines)

    def _refresh_destination_hint(self) -> None:
        world_path = self._summary.get("world_path")
        if not world_path:
            self.dest_hint.setText("Open a world to export changes.")
            return
        world_path = Path(str(world_path))
        if self.apply_copy.isChecked():
            self.dest_hint.setText(
                f"A timestamped copy will be created next to the world, then only changed region files will be rewritten. "
                f"Example: {world_path.parent / (world_path.name + '_wgl_export_TIMESTAMP')}"
            )
        else:
            self.dest_hint.setText("Advanced mode modifies the currently opened world. Back up the world first.")
