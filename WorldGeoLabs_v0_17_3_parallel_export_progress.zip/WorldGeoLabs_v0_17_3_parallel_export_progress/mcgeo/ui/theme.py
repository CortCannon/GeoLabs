from __future__ import annotations

from PySide6 import QtWidgets


_APP_STYLE = """
QMainWindow, QWidget#WorkspaceRoot {
    background: #202327;
    color: #e8e8e8;
}
QDockWidget {
    titlebar-close-icon: none;
    titlebar-normal-icon: none;
}
QDockWidget::title {
    background: #252a30;
    padding: 6px 8px;
    font-weight: 600;
}
QFrame#WorkspaceHeader, QFrame#ViewportCard, QFrame#LayerHeaderCard, QFrame#AdvancedPanel {
    background: #262b31;
    border: 1px solid #3a414a;
    border-radius: 8px;
}
QFrame#ViewportCard {
    background: #15181c;
}
QLabel#WorkspaceTitle, QLabel#PanelTitle {
    font-size: 17px;
    font-weight: 700;
    color: #f2f2f2;
}
QLabel#SubtleHint {
    color: #b8c0c9;
}
QLabel#MicroHint {
    color: #aab4bf;
    font-size: 11px;
}
QLabel#HeaderPill, QLabel#StatusPill {
    background: #1c2025;
    border: 1px solid #3b4652;
    border-radius: 10px;
    padding: 4px 8px;
    color: #dce4ec;
}
QPushButton {
    background: #303740;
    border: 1px solid #48515c;
    border-radius: 6px;
    padding: 6px 10px;
}
QPushButton:hover {
    background: #39434e;
}
QPushButton:pressed {
    background: #222930;
}
QPushButton#PrimaryButton, QPushButton[active="true"] {
    background: #455a6f;
    border-color: #6c8299;
    font-weight: 600;
}
QTabWidget::pane {
    border: 1px solid #3a414a;
    border-radius: 6px;
    top: -1px;
}
QTabBar::tab {
    background: #252a30;
    border: 1px solid #3a414a;
    padding: 6px 10px;
    margin-right: 2px;
}
QTabBar::tab:selected {
    background: #343c45;
    border-bottom-color: #343c45;
    font-weight: 600;
}
QGroupBox {
    border: 1px solid #3a414a;
    border-radius: 7px;
    margin-top: 12px;
    padding-top: 10px;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 10px;
    padding: 0 4px;
    color: #dce4ec;
    font-weight: 600;
}
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox, QTextEdit, QListWidget {
    background: #181c20;
    border: 1px solid #3d4650;
    border-radius: 5px;
    padding: 4px;
    selection-background-color: #50657a;
}
QSlider::groove:horizontal {
    height: 5px;
    background: #15191d;
    border-radius: 3px;
}
QSlider::handle:horizontal {
    background: #8fa3b8;
    width: 14px;
    margin: -5px 0;
    border-radius: 7px;
}
"""


def apply_app_theme(window: QtWidgets.QWidget) -> None:
    """Apply the app-local stylesheet.

    Kept in one module so UI polish can happen without scattering colors and
    object-name CSS across the main window and individual panels.
    """
    window.setStyleSheet(_APP_STYLE)
