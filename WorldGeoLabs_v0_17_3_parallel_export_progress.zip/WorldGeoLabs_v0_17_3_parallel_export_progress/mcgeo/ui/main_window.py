from __future__ import annotations
import logging
import json
import os
import threading
from copy import deepcopy
from pathlib import Path
from PySide6 import QtWidgets, QtCore, QtGui

from ..core.uistate import UIState
from .log_handler import QtLogHandler
from .widgets.layers_panel import LayersPanel
from .widgets.blocks_panel import BlocksPanel
from .widgets.params_panel import ParamsPanel
from .widgets.paint_panel import PaintPanel
from .widgets.edit_core_panel import EditCorePanel
from .widgets.geology_analysis_panel import GeologyAnalysisPanel
from .widgets.log_panel import LogPanel
from .widgets.workspace_shell import WorkspaceShell
from .theme import apply_app_theme
from .dialogs.performance_dialog import PerformanceDialog
from .dialogs.apply_dialog import ApplyDialog
from .dialogs.create_feature_dialog import CreateFeatureDialog
from .dialogs.startup_dialog import StartupDialog
from .dialogs.project_area_dialog import ProjectAreaDialog
from ..rendering.renderer_manager import RendererManager
from ..world.world_open import WorldIndexer
from ..world.anvil_reader import AnvilWorld
from ..world.region_warmup import RegionWarmupWorker, region_files_for_chunk_bounds
from ..edit.core.integration_bridge import EditingCoreController
from ..edit.core.demo_chunk_adapter import DemoChunkAdapter
from ..project.session import new_paint_layer, serialize_paint_layers, restore_paint_layers
from ..rendering.render_sections import sections_for_block_box, chunk_columns_for_sections
from ..world.exporter import IncrementalExportOptions
from .export_worker import IncrementalExportWorker
from ..worldpainter.service import import_worldpainter_source
from ..worldpainter.bridge import WorldPainterBridgeError
from ..worldpainter.package import WorldPainterPackageError
from ..worldpainter.alignment import compare_metadata
from ..analysis.engine import AnalysisOptions
from ..analysis.qt_worker import GeologicalAnalysisWorker
from ..geology.deposits import ResourceGenerationOptions
from ..geology.qt_worker import GeologicalResourceWorker

log = logging.getLogger("mcgeo.ui")


class MainWindow(QtWidgets.QMainWindow):
    def __init__(self) -> None:
        super().__init__()
        self.setWindowTitle("WorldGeoLabs")
        self.setObjectName("MainWindow")
        self.setDockOptions(
            QtWidgets.QMainWindow.DockOption.AllowNestedDocks
            | QtWidgets.QMainWindow.DockOption.AllowTabbedDocks
            | QtWidgets.QMainWindow.DockOption.AnimatedDocks
            | QtWidgets.QMainWindow.DockOption.GroupedDragging
        )

        self.state = UIState()
        self._ui_settings = QtCore.QSettings("WorldGeoLabs", "WorldGeoLabs")
        self._perf_dlg: PerformanceDialog | None = None

        # Logging to UI
        self.log_panel = LogPanel()
        self._log_handler = QtLogHandler()
        self._log_handler.setFormatter(
            logging.Formatter("%(asctime)s | %(levelname)s | %(name)s: %(message)s", "%H:%M:%S")
        )
        self._log_handler.message.connect(self.log_panel.append)
        logging.getLogger().addHandler(self._log_handler)

        # Panels
        self.layers_panel = LayersPanel()
        self.blocks_panel = BlocksPanel()
        self.params_panel = ParamsPanel()
        self.paint_panel = PaintPanel()
        self._paint_layer_strokes: dict[str, int] = {}
        self._paint_layers: dict[str, dict] = {}
        # Per-layer redo stacks.  Undo/redo is intentionally scoped to the
        # selected paint layer, matching the GIMP-style layer workflow: editing
        # one layer never rewinds strokes on a different layer.
        self._paint_layer_redo: dict[str, list[dict]] = {}
        self._paint_layer_serial = 1
        self.edit_core_panel = EditCorePanel()
        self.geology_analysis_panel = GeologyAnalysisPanel()
        self.edit_core = EditingCoreController()
        self._edit_core_box_params: dict = self.edit_core_panel.params()
        self._anvil_world: AnvilWorld | None = None
        self._last_world_index = None
        self._dev_tools_visible = False
        self._edit_core_tab_index = -1
        self._layer_header_sync_guard = False
        self._layer_header_meta: dict = {}
        self._startup_prompt_shown = False
        self._pending_project_payload: dict | None = None
        self._pending_worldpainter_source: Path | None = None
        self._worldpainter_import = None
        self._analysis_thread: QtCore.QThread | None = None
        self._analysis_worker: GeologicalAnalysisWorker | None = None
        self._analysis_cancel_event: threading.Event | None = None
        self._resource_thread: QtCore.QThread | None = None
        self._resource_worker: GeologicalResourceWorker | None = None
        self._resource_cancel_event: threading.Event | None = None
        self._export_thread: QtCore.QThread | None = None
        self._export_worker: IncrementalExportWorker | None = None
        self._export_progress: QtWidgets.QProgressDialog | None = None
        self._export_last_logged_progress = -10

        # Renderer (strict GL mode)
        self.renderer_mgr = RendererManager()
        self.viewport = self.renderer_mgr.create_viewport()
        self.viewport.setObjectName("WorldViewport")
        self.renderer_mgr.materials_changed.connect(self._on_materials_changed)
        self.renderer_mgr.paint_hover_changed.connect(self._on_paint_hover_changed)
        self.renderer_mgr.paint_stroke_committed.connect(self._on_paint_stroke_committed)
        if hasattr(self.renderer_mgr, "block_picked"):
            self.renderer_mgr.block_picked.connect(self._on_viewport_block_picked)

        # Layout / docks
        self._build_docks()
        self._build_workspace_shell()

        # Toolbar / menus / status
        self._build_toolbar()
        self._build_menus()
        self._build_status_widgets()
        apply_app_theme(self)

        self.statusBar().showMessage("Ready")

        # Indexer worker
        self._indexer = WorldIndexer()
        self._indexer.progress.connect(self._on_index_progress)
        self._indexer.finished.connect(self._on_index_done)
        self._indexer.failed.connect(self._on_index_failed)

        # UI signals
        self.params_panel.view_mode.currentTextChanged.connect(self._on_view_mode)
        self.params_panel.preview_settings_changed.connect(self._on_preview_settings_changed)
        self.params_panel.view_settings_changed.connect(self._on_view_settings_changed)
        self.blocks_panel.visibility_changed.connect(self._on_blocks_visibility)
        self.paint_panel.paint_settings_changed.connect(self._on_paint_settings_changed)
        self.paint_panel.realign_requested.connect(self._on_paint_realign_requested)
        self.paint_panel.add_layer_requested.connect(self._on_add_paint_layer)
        self.paint_panel.import_model_requested.connect(self._on_import_model_requested)
        self.paint_panel.focus_paint_requested.connect(self._focus_paint_tab)
        self.layers_panel.create_feature_requested.connect(self._show_create_feature_dialog)
        self.layers_panel.quick_feature_requested.connect(self._on_quick_feature_requested)
        self.layers_panel.layer_selected.connect(self._on_layer_selected)
        self.layers_panel.layer_edit_requested.connect(self._on_layer_edit_requested)
        self.layers_panel.layer_remove_requested.connect(self._on_layer_remove_requested)
        self.layers_panel.layer_duplicate_requested.connect(self._on_layer_duplicate_requested)
        self.layers_panel.layer_renamed.connect(self._on_layer_renamed)
        self.layers_panel.layer_visibility_changed.connect(self._on_layer_visibility_changed)
        self.layers_panel.layer_reordered.connect(self._on_layer_reordered)
        self.edit_core_panel.box_params_changed.connect(self._on_edit_core_box_params_changed)
        self.edit_core_panel.add_box_layer_requested.connect(self._on_edit_core_add_box_layer)
        self.edit_core_panel.preview_requested.connect(self._on_edit_core_preview)
        self.edit_core_panel.apply_demo_requested.connect(self._on_edit_core_apply_demo)
        self.geology_analysis_panel.analysis_requested.connect(self._start_geological_analysis)
        self.geology_analysis_panel.resource_generation_requested.connect(self._start_geological_resource_generation)
        self.geology_analysis_panel.cancel_requested.connect(self._cancel_geological_analysis)
        self.geology_analysis_panel.cancel_requested.connect(self._cancel_geological_resource_generation)
        self._layer_header_name.editingFinished.connect(self._on_layer_header_name_edited)
        self._layer_header_enabled.toggled.connect(self._on_layer_header_enabled_toggled)
        self._layer_header_dup.clicked.connect(lambda: self.layers_panel.btn_duplicate.click())
        self._layer_header_del.clicked.connect(lambda: self.layers_panel.btn_remove.click())

        # Seed initial settings into renderer
        self._push_preview_settings_to_renderer(self.params_panel.preview_settings())
        self.renderer_mgr.set_view_settings(self.params_panel.view_settings())
        self.renderer_mgr.set_view_mode(self.params_panel.view_mode.currentText())
        self.renderer_mgr.set_paint_settings(self.paint_panel.settings())
        self.edit_core_panel.set_stats(
            "Developer / internal editing-core tools\n"
            "- Hidden by default in the workflow reset build\n"
            "- Use only for backend milestone testing"
        )
        self._sync_layer_header_from_layers_selection()

        # Poll performance snapshot for status labels (lightweight)
        self._status_timer = QtCore.QTimer(self)
        self._status_timer.setInterval(1000)
        self._status_timer.timeout.connect(self._refresh_status_snapshot)
        self._status_timer.start()
        self._sync_preview_ui_state()
        self._restore_window_layout()
        self._sync_workspace_header()
        self._update_undo_redo_actions()

    # ---------------- UI building ----------------
    def _build_docks(self) -> None:
        self.left_dock = QtWidgets.QDockWidget("Layers", self)
        self.left_dock.setObjectName("dock_layers")
        self.left_dock.setWidget(self.layers_panel)
        self.left_dock.setAllowedAreas(QtCore.Qt.DockWidgetArea.LeftDockWidgetArea)
        self.left_dock.setFeatures(
            QtWidgets.QDockWidget.DockWidgetFeature.DockWidgetMovable
            | QtWidgets.QDockWidget.DockWidgetFeature.DockWidgetFloatable
        )
        self.left_dock.setMinimumWidth(320)
        self.addDockWidget(QtCore.Qt.DockWidgetArea.LeftDockWidgetArea, self.left_dock)

        # Layer editor dock (replaces visible "Inspector" tabs UX)
        self.right_dock = QtWidgets.QDockWidget("Edit Selected Layer", self)
        self.right_dock.setObjectName("dock_layer_editor")

        self.inspector_tabs = QtWidgets.QTabWidget()
        self.inspector_tabs.setObjectName("LayerEditorPages")
        self.inspector_tabs.setDocumentMode(True)
        self.inspector_tabs.setUsesScrollButtons(False)

        self.inspector_tabs.addTab(self.params_panel, "Scene / Preview")
        self.inspector_tabs.addTab(self.paint_panel, "Paint")
        self._analysis_tab_index = self.inspector_tabs.addTab(self.geology_analysis_panel, "Geological Analysis")
        self._edit_core_tab_index = self.inspector_tabs.addTab(self.edit_core_panel, "Advanced / Dev")
        self.inspector_tabs.setTabVisible(self._edit_core_tab_index, False)

        self._layer_editor_title = QtWidgets.QLabel("Scene Tools")
        self._layer_editor_title.setObjectName("PanelTitle")
        self._layer_editor_hint = QtWidgets.QLabel(
            "Select a feature/layer on the left to edit it. "
            "If no layer is selected, scene cutaway + generator controls are shown."
        )
        self._layer_editor_hint.setObjectName("SubtleHint")
        self._layer_editor_hint.setWordWrap(True)

        # Compact "edit selected layer" header card (keeps workflow clean and focused)
        self._layer_header_card = QtWidgets.QFrame()
        self._layer_header_card.setFrameShape(QtWidgets.QFrame.Shape.StyledPanel)
        self._layer_header_card.setObjectName("LayerHeaderCard")

        self._layer_header_name = QtWidgets.QLineEdit()
        self._layer_header_name.setPlaceholderText("Selected layer name")
        self._layer_header_name.setClearButtonEnabled(False)

        self._layer_header_type = QtWidgets.QLabel("Scene")
        self._layer_header_type.setObjectName("StatusPill")
        self._layer_header_type.setMinimumWidth(110)

        self._layer_header_enabled = QtWidgets.QCheckBox("Visible / Enabled")
        self._layer_header_dup = QtWidgets.QToolButton()
        self._layer_header_dup.setText("Duplicate")
        self._layer_header_del = QtWidgets.QToolButton()
        self._layer_header_del.setText("Delete")

        header_top = QtWidgets.QHBoxLayout()
        header_top.setContentsMargins(8, 8, 8, 4)
        header_top.addWidget(QtWidgets.QLabel("Selected Layer"))
        header_top.addStretch(1)
        header_top.addWidget(self._layer_header_type)

        header_row = QtWidgets.QHBoxLayout()
        header_row.setContentsMargins(8, 0, 8, 8)
        header_row.addWidget(self._layer_header_name, 1)
        header_row.addWidget(self._layer_header_enabled)
        header_row.addWidget(self._layer_header_dup)
        header_row.addWidget(self._layer_header_del)

        header_layout = QtWidgets.QVBoxLayout(self._layer_header_card)
        header_layout.setContentsMargins(0, 0, 0, 0)
        header_layout.setSpacing(0)
        header_layout.addLayout(header_top)
        header_layout.addLayout(header_row)

        editor_container = QtWidgets.QWidget()
        editor_layout = QtWidgets.QVBoxLayout(editor_container)
        editor_layout.setContentsMargins(8, 8, 8, 8)
        editor_layout.setSpacing(6)
        editor_layout.addWidget(self._layer_editor_title)
        editor_layout.addWidget(self._layer_editor_hint)
        editor_layout.addWidget(self._layer_header_card)
        editor_layout.addWidget(self.inspector_tabs, 1)

        editor_scroll = QtWidgets.QScrollArea()
        editor_scroll.setWidgetResizable(True)
        editor_scroll.setFrameShape(QtWidgets.QFrame.Shape.NoFrame)
        editor_scroll.setWidget(editor_container)

        self.right_dock.setWidget(editor_scroll)
        self.right_dock.setMinimumWidth(380)
        self.right_dock.setAllowedAreas(QtCore.Qt.DockWidgetArea.RightDockWidgetArea)
        self.right_dock.setFeatures(
            QtWidgets.QDockWidget.DockWidgetFeature.DockWidgetMovable
            | QtWidgets.QDockWidget.DockWidgetFeature.DockWidgetFloatable
        )
        self.addDockWidget(QtCore.Qt.DockWidgetArea.RightDockWidgetArea, self.right_dock)

        # Separate blocks dock (cleaner than mixing into inspector tabs)
        self.blocks_dock = QtWidgets.QDockWidget("Blocks Visibility", self)
        self.blocks_dock.setObjectName("dock_blocks")
        self.blocks_dock.setWidget(self.blocks_panel)
        self.blocks_dock.setAllowedAreas(
            QtCore.Qt.DockWidgetArea.RightDockWidgetArea | QtCore.Qt.DockWidgetArea.LeftDockWidgetArea
        )
        self.blocks_dock.setFeatures(
            QtWidgets.QDockWidget.DockWidgetFeature.DockWidgetMovable
            | QtWidgets.QDockWidget.DockWidgetFeature.DockWidgetFloatable
        )
        self.blocks_dock.setMinimumWidth(360)
        self.addDockWidget(QtCore.Qt.DockWidgetArea.RightDockWidgetArea, self.blocks_dock)
        self.tabifyDockWidget(self.right_dock, self.blocks_dock)
        self.right_dock.raise_()

        self.bottom_dock = QtWidgets.QDockWidget("Logs", self)
        self.bottom_dock.setObjectName("dock_logs")
        self.bottom_dock.setWidget(self.log_panel)
        self.bottom_dock.setAllowedAreas(QtCore.Qt.DockWidgetArea.BottomDockWidgetArea)
        self.bottom_dock.setMinimumHeight(220)
        self.bottom_dock.setFeatures(
            QtWidgets.QDockWidget.DockWidgetFeature.DockWidgetMovable
            | QtWidgets.QDockWidget.DockWidgetFeature.DockWidgetFloatable
        )
        self.addDockWidget(QtCore.Qt.DockWidgetArea.BottomDockWidgetArea, self.bottom_dock)

    def _std_icon(self, pixmap_enum):
        return self.style().standardIcon(pixmap_enum)

    def _build_workspace_shell(self) -> None:
        self.workspace_shell = WorkspaceShell(self.viewport, self)
        self.workspace_shell.open_world_requested.connect(self.open_world)
        self.workspace_shell.project_area_requested.connect(self.edit_project_area)
        self.workspace_shell.create_feature_requested.connect(self._show_create_feature_dialog)
        self.workspace_shell.focus_paint_requested.connect(self._focus_paint_tab)
        self.setCentralWidget(self.workspace_shell)

    def _sync_workspace_header(self) -> None:
        if not hasattr(self, "workspace_shell"):
            return
        world_name = str(self.state.world_name or "")
        area_text = getattr(self, "_sb_area", None).text() if hasattr(self, "_sb_area") else "Area: not set"
        tool_text = getattr(self, "_sb_tool", None).text() if hasattr(self, "_sb_tool") else "Tool: Navigate"
        preview_text = getattr(self, "_sb_preview", None).text() if hasattr(self, "_sb_preview") else "Preview: Off"
        self.workspace_shell.sync(
            world_name=world_name,
            area_text=area_text,
            tool_text=tool_text,
            preview_text=preview_text,
        )
        try:
            self.workspace_shell.set_paint_active(bool(self.state.paint_mode_enabled))
        except Exception:
            pass

    def _restore_window_layout(self) -> None:
        try:
            geometry = self._ui_settings.value("main/geometry")
            if geometry is not None:
                self.restoreGeometry(geometry)
            state = self._ui_settings.value("main/windowState")
            if state is not None:
                self.restoreState(state)
        except Exception:
            log.exception("Failed to restore saved window layout")

    def _save_window_layout(self) -> None:
        try:
            self._ui_settings.setValue("main/geometry", self.saveGeometry())
            self._ui_settings.setValue("main/windowState", self.saveState())
        except Exception:
            log.exception("Failed to save window layout")

    def _reset_window_layout(self) -> None:
        """Return docks/toolbars to the intended production layout."""
        try:
            self._ui_settings.remove("main/windowState")
            self._ui_settings.remove("main/geometry")
        except Exception:
            pass
        self.left_dock.setVisible(True)
        self.right_dock.setVisible(True)
        self.blocks_dock.setVisible(False)
        self.bottom_dock.setVisible(True)
        self.addDockWidget(QtCore.Qt.DockWidgetArea.LeftDockWidgetArea, self.left_dock)
        self.addDockWidget(QtCore.Qt.DockWidgetArea.RightDockWidgetArea, self.right_dock)
        self.addDockWidget(QtCore.Qt.DockWidgetArea.RightDockWidgetArea, self.blocks_dock)
        self.tabifyDockWidget(self.right_dock, self.blocks_dock)
        self.right_dock.raise_()
        self.addDockWidget(QtCore.Qt.DockWidgetArea.BottomDockWidgetArea, self.bottom_dock)
        if self.main_toolbar is not None:
            self.main_toolbar.setVisible(True)
        self.statusBar().showMessage("Reset WorldGeoLabs window layout")

    def closeEvent(self, event: QtGui.QCloseEvent) -> None:
        if self._analysis_cancel_event is not None:
            self._analysis_cancel_event.set()
        if self._resource_cancel_event is not None:
            self._resource_cancel_event.set()
        self._save_window_layout()
        super().closeEvent(event)

    def _build_toolbar(self) -> None:
        tb = self.addToolBar("Main")
        tb.setObjectName("main_toolbar")
        tb.setMovable(False)
        tb.setToolButtonStyle(QtCore.Qt.ToolButtonStyle.ToolButtonTextBesideIcon)
        tb.setIconSize(QtCore.QSize(18, 18))
        tb.setContextMenuPolicy(QtCore.Qt.ContextMenuPolicy.PreventContextMenu)
        self.main_toolbar = tb

        self.act_open = QtGui.QAction(self._std_icon(QtWidgets.QStyle.StandardPixmap.SP_DirOpenIcon), "Open World", self)
        self.act_open.setStatusTip("Open a Minecraft Java world folder")
        self.act_open.triggered.connect(self.open_world)
        tb.addAction(self.act_open)

        self.act_open_worldpainter = QtGui.QAction("Open + WorldPainter", self)
        self.act_open_worldpainter.setStatusTip("Open a Minecraft world paired with a WorldPainter .world project or analysis package")
        self.act_open_worldpainter.triggered.connect(self.open_world_with_worldpainter)
        tb.addAction(self.act_open_worldpainter)

        self.act_load_project = QtGui.QAction(self._std_icon(QtWidgets.QStyle.StandardPixmap.SP_FileDialogContentsView), "Load Project", self)
        self.act_load_project.setStatusTip("Load a WorldGeoLabs project (.mcgeo.json)")
        self.act_load_project.triggered.connect(self.load_project)
        tb.addAction(self.act_load_project)

        self.act_save_project = QtGui.QAction(self._std_icon(QtWidgets.QStyle.StandardPixmap.SP_DialogSaveButton), "Save Project", self)
        self.act_save_project.setStatusTip("Save WorldGeoLabs project (.mcgeo.json)")
        self.act_save_project.triggered.connect(self.save_project)
        tb.addAction(self.act_save_project)

        tb.addSeparator()
        self.act_undo = QtGui.QAction("Undo", self)
        self.act_undo.setStatusTip("Undo the last stroke on the selected paint layer only")
        self.act_undo.setShortcut(QtGui.QKeySequence("Ctrl+Z"))
        self.act_undo.triggered.connect(self._undo_active_paint_layer)
        tb.addAction(self.act_undo)

        self.act_redo = QtGui.QAction("Redo", self)
        self.act_redo.setStatusTip("Redo the last undone stroke on the selected paint layer only")
        self.act_redo.setShortcuts([QtGui.QKeySequence("Ctrl+Y"), QtGui.QKeySequence("Ctrl+Shift+Z")])
        self.act_redo.triggered.connect(self._redo_active_paint_layer)
        tb.addAction(self.act_redo)

        tb.addSeparator()

        self.act_project_area = QtGui.QAction(self._std_icon(QtWidgets.QStyle.StandardPixmap.SP_DialogOpenButton), "Project Area", self)
        self.act_project_area.setStatusTip("Choose or change the project edit area (2D overview map)")
        self.act_project_area.triggered.connect(self.edit_project_area)
        tb.addAction(self.act_project_area)

        self.act_analyze = QtGui.QAction("Analyze Geology", self)
        self.act_analyze.setStatusTip("Build whole-map height, slope, drainage, lithology, soil, and section analysis")
        self.act_analyze.triggered.connect(self.show_geological_analysis)
        tb.addAction(self.act_analyze)

        self.act_create_feature = QtGui.QAction(self._std_icon(QtWidgets.QStyle.StandardPixmap.SP_FileDialogNewFolder), "Create Feature", self)
        self.act_create_feature.setStatusTip("Add a non-destructive cave, ore, paint, or shape layer")
        self.act_create_feature.triggered.connect(self._show_create_feature_dialog)
        tb.addAction(self.act_create_feature)

        self.act_perf = QtGui.QAction(self._std_icon(QtWidgets.QStyle.StandardPixmap.SP_ComputerIcon), "Performance", self)
        self.act_perf.setStatusTip("Open performance tuning dialog")
        self.act_perf.triggered.connect(self.show_performance)
        tb.addAction(self.act_perf)

        tb.addSeparator()
        self.edit_mode_group = QtGui.QActionGroup(self)
        self.edit_mode_group.setExclusive(True)
        self.act_lod_edit = QtGui.QAction("LOD Edit", self)
        self.act_lod_edit.setCheckable(True)
        self.act_lod_edit.setStatusTip("Edit across the Distant Horizons world using coarse surface/volume previews; no real voxel chunks are streamed")
        self.act_lod_edit.toggled.connect(self._on_lod_edit_toggled)
        self.edit_mode_group.addAction(self.act_lod_edit)
        tb.addAction(self.act_lod_edit)

        self.act_detailed_edit = QtGui.QAction("Detailed Edit", self)
        self.act_detailed_edit.setCheckable(True)
        self.act_detailed_edit.setChecked(True)
        self.act_detailed_edit.setStatusTip("Load exact Minecraft blocks only inside the movable 3D detailed work box")
        self.act_detailed_edit.toggled.connect(self._on_detailed_edit_toggled)
        self.edit_mode_group.addAction(self.act_detailed_edit)
        tb.addAction(self.act_detailed_edit)

        self.act_move_work_area = QtGui.QAction("Move Working Area", self)
        self.act_move_work_area.setStatusTip("Move the Detailed Edit 3D box to the current camera target (X/Z/Y) and load only the sections inside it")
        self.act_move_work_area.setShortcut(QtGui.QKeySequence("Ctrl+Shift+M"))
        self.act_move_work_area.triggered.connect(self._move_working_area_to_camera)
        tb.addAction(self.act_move_work_area)

        self.act_paint = QtGui.QAction(self._std_icon(QtWidgets.QStyle.StandardPixmap.SP_DirHomeIcon), "Paint", self)
        self.act_paint.setCheckable(True)
        self.act_paint.setStatusTip("Toggle 3D painter preview mode")
        self.act_paint.toggled.connect(self._on_toolbar_paint_toggled)
        tb.addAction(self.act_paint)

        self.act_apply = QtGui.QAction(self._std_icon(QtWidgets.QStyle.StandardPixmap.SP_DialogApplyButton), "Apply", self)
        self.act_apply.setStatusTip("Open apply dialog (safe write pipeline)")
        self.act_apply.triggered.connect(self.show_apply)
        tb.addAction(self.act_apply)

        tb.addSeparator()
        self.act_toggle_logs = QtGui.QAction("Logs", self)
        self.act_toggle_logs.setCheckable(True)
        self.act_toggle_logs.setChecked(True)
        self.act_toggle_logs.toggled.connect(self.bottom_dock.setVisible)
        self.bottom_dock.visibilityChanged.connect(self.act_toggle_logs.setChecked)
        tb.addAction(self.act_toggle_logs)

    def _build_menus(self) -> None:
        mb = self.menuBar()

        m_file = mb.addMenu("&File")
        m_file.addAction(self.act_open)
        m_file.addAction(self.act_open_worldpainter)
        m_file.addSeparator()
        m_file.addAction(self.act_load_project)
        m_file.addAction(self.act_save_project)
        m_file.addSeparator()
        m_file.addAction(self.act_apply)

        m_analysis = mb.addMenu("&Analysis")
        m_analysis.addAction(self.act_analyze)

        m_edit = mb.addMenu("&Edit")
        m_edit.addAction(self.act_undo)
        m_edit.addAction(self.act_redo)

        m_view = mb.addMenu("&View")
        m_view.addAction(self.left_dock.toggleViewAction())
        m_view.addAction(self.right_dock.toggleViewAction())
        m_view.addAction(self.blocks_dock.toggleViewAction())
        m_view.addAction(self.bottom_dock.toggleViewAction())
        m_view.addSeparator()
        if self.main_toolbar is not None:
            m_view.addAction(self.main_toolbar.toggleViewAction())
        m_view.addSeparator()
        self.act_reset_layout = QtGui.QAction("Reset Window Layout", self)
        self.act_reset_layout.setStatusTip("Restore the default WorldGeoLabs dock layout")
        self.act_reset_layout.triggered.connect(self._reset_window_layout)
        m_view.addAction(self.act_reset_layout)

        m_tools = mb.addMenu("&Tools")
        m_tools.addAction(self.act_create_feature)
        m_tools.addAction(self.act_perf)
        m_tools.addAction(self.act_move_work_area)
        m_tools.addAction(self.act_paint)
        self.act_focus_scene = QtGui.QAction("Show Scene / View Tools", self)
        self.act_focus_scene.triggered.connect(self._focus_scene_tools)
        m_tools.addAction(self.act_focus_scene)
        m_tools.addSeparator()
        self.act_dev_tools = QtGui.QAction("Show Developer Tools", self)
        self.act_dev_tools.setCheckable(True)
        self.act_dev_tools.setChecked(False)
        self.act_dev_tools.toggled.connect(self._set_dev_tools_visible)
        m_tools.addAction(self.act_dev_tools)

        m_help = mb.addMenu("&Help")
        about = QtGui.QAction("About WorldGeoLabs (preview build)", self)
        about.triggered.connect(self._show_about)
        m_help.addAction(about)

    def _build_status_widgets(self) -> None:
        sb = self.statusBar()
        sb.setSizeGripEnabled(True)

        self._sb_world = QtWidgets.QLabel("World: none")
        self._sb_world.setObjectName("StatusPill")
        self._sb_view = QtWidgets.QLabel("View: Surface")
        self._sb_view.setObjectName("StatusPill")
        self._sb_perf = QtWidgets.QLabel("FPS: -- | Resident: --")
        self._sb_perf.setObjectName("StatusPill")
        self._sb_mode = QtWidgets.QLabel("Renderer: OpenGL")
        self._sb_mode.setObjectName("StatusPill")
        self._sb_tool = QtWidgets.QLabel("Tool: Navigate")
        self._sb_tool.setObjectName("StatusPill")
        self._sb_area = QtWidgets.QLabel("Area: not set")
        self._sb_area.setObjectName("StatusPill")
        self._sb_preview = QtWidgets.QLabel("Preview: Off")
        self._sb_preview.setObjectName("StatusPill")

        for w in (self._sb_world, self._sb_view, self._sb_perf, self._sb_mode, self._sb_tool, self._sb_area, self._sb_preview):
            sb.addPermanentWidget(w)

    # ---------------- Actions ----------------
    def _show_not_implemented(self, name: str) -> None:
        QtWidgets.QMessageBox.information(
            self,
            f"{name} (next milestone)",
            f"{name} is not available in this build."
        )

    def _show_about(self) -> None:
        QtWidgets.QMessageBox.information(
            self,
            "About WorldGeoLabs",
            "WorldGeoLabs preview build\n\n"
            "Windows-first Minecraft Java (Anvil) underground editor prototype.\n"
            "Current focus: streamed OpenGL viewport + inspect-first workflow + non-destructive feature previews."
        )

    def _set_dev_tools_visible(self, visible: bool) -> None:
        self._dev_tools_visible = bool(visible)
        if hasattr(self, "inspector_tabs") and self._edit_core_tab_index >= 0:
            self.inspector_tabs.setTabVisible(self._edit_core_tab_index, self._dev_tools_visible)
            if self._dev_tools_visible:
                self.statusBar().showMessage("Developer tools enabled (advanced layer editor available)")
            else:
                if self.inspector_tabs.currentIndex() == self._edit_core_tab_index:
                    self.inspector_tabs.setCurrentWidget(self.params_panel)
                    self._set_layer_editor_context("Scene Tools")
                self.statusBar().showMessage("Developer tools hidden")

    def _set_layer_editor_context(self, title: str, hint: str | None = None) -> None:
        try:
            if hasattr(self, "_layer_editor_title"):
                self._layer_editor_title.setText(title)
            if hasattr(self, "_layer_editor_hint"):
                if hint is None:
                    self._layer_editor_hint.setVisible(False)
                else:
                    self._layer_editor_hint.setVisible(True)
                    self._layer_editor_hint.setText(hint)
        except Exception:
            pass


    def _layer_type_label(self, meta: dict | None) -> str:
        m = dict(meta or {})
        kind = str(m.get("kind", "")).lower()
        if not kind:
            return "Scene"
        if kind == "generator":
            gk = str(m.get("generator_kind", "generator")).strip() or "generator"
            return f"Generator • {gk.title()}"
        if kind == "paint":
            return "Paint Layer"
        if kind == "editcore":
            return "Advanced / Dev"
        return kind.replace("_", " ").title()

    def _layer_header_display_name(self, meta: dict | None) -> str:
        m = dict(meta or {})
        kind = str(m.get("kind", "")).lower()
        if kind == "paint":
            return str(m.get("name") or m.get("label") or "Paint Layer")
        if kind == "generator":
            gk = str(m.get("generator_kind", "Generator")).title()
            return f"{gk} Preview"
        if kind == "editcore":
            return str(m.get("name") or "Box Replace (Dev)")
        return str(m.get("label") or "Scene Tools")

    def _layer_header_name_editable(self, meta: dict | None) -> bool:
        m = dict(meta or {})
        kind = str(m.get("kind", "")).lower()
        return kind in {"paint", "editcore"}

    def _sync_layer_header_from_layers_selection(self) -> None:
        try:
            meta = self.layers_panel.current_layer_meta()
        except Exception:
            meta = {}
        self._layer_header_meta = dict(meta or {})
        self._layer_header_sync_guard = True
        try:
            has_layer = bool(meta)
            self._layer_header_card.setVisible(True)
            self._layer_header_name.setEnabled(has_layer)
            self._layer_header_enabled.setEnabled(has_layer)
            self._layer_header_dup.setEnabled(has_layer)
            self._layer_header_del.setEnabled(has_layer)
            if not has_layer:
                self._layer_header_type.setText("Scene")
                self._layer_header_name.setText("")
                self._layer_header_name.setPlaceholderText("No layer selected")
                self._layer_header_enabled.setChecked(False)
                self._layer_header_enabled.setText("Visible / Enabled")
                return
            self._layer_header_type.setText(self._layer_type_label(meta))
            self._layer_header_name.setText(self._layer_header_display_name(meta))
            self._layer_header_name.setReadOnly(not self._layer_header_name_editable(meta))
            self._layer_header_name.setEnabled(True)
            self._layer_header_name.setPlaceholderText("Layer name")
            checked = bool(meta.get("checked", True))
            self._layer_header_enabled.setChecked(checked)
            kind = str(meta.get("kind", "")).lower()
            if kind == "generator":
                self._layer_header_enabled.setText("Preview visible")
            elif kind == "paint":
                self._layer_header_enabled.setText("Layer visible")
            else:
                self._layer_header_enabled.setText("Visible / Enabled")
        finally:
            self._layer_header_sync_guard = False

    @QtCore.Slot()
    def _on_layer_header_name_edited(self) -> None:
        if self._layer_header_sync_guard:
            return
        try:
            meta = self.layers_panel.current_layer_meta()
        except Exception:
            meta = {}
        if not meta:
            return
        if not self._layer_header_name_editable(meta):
            self._sync_layer_header_from_layers_selection()
            return
        name = self._layer_header_name.text().strip()
        if not name:
            self._sync_layer_header_from_layers_selection()
            return
        # Paint layers have styled labels in the layer list; normalize here.
        if str(meta.get("kind", "")).lower() == "paint" and not name.lower().startswith("paint •"):
            name = f"Paint • {name}"
        try:
            self.layers_panel.set_selected_layer_label(name)
        except Exception:
            pass
        self._sync_layer_header_from_layers_selection()

    @QtCore.Slot(bool)
    def _on_layer_header_enabled_toggled(self, checked: bool) -> None:
        if self._layer_header_sync_guard:
            return
        try:
            self.layers_panel.set_selected_layer_visibility(bool(checked))
        except Exception:
            pass
        self._sync_layer_header_from_layers_selection()

    def _preview_layer_order_for_renderer(self) -> list[str]:
        """Return generator preview layer order from the visible layer stack (top -> bottom).

        The mesh preview currently supports order-sensitive evaluation for generator layers
        (caves / ores). Non-generator layers are ignored by the renderer in this milestone.
        """
        out: list[str] = []
        try:
            metas = self.layers_panel.layer_stack_metas()
        except Exception:
            metas = []
        for m in metas:
            try:
                mm = dict(m or {})
            except Exception:
                continue
            if str(mm.get("kind", "")).lower() != "generator":
                continue
            if not bool(mm.get("checked", True)):
                continue
            key = str(mm.get("key", "")).strip().lower()
            if key in {"gen:caves", "gen:ores"} and key not in out:
                out.append(key)
        return out

    @QtCore.Slot()
    def _on_paint_realign_requested(self) -> None:
        try:
            self.renderer_mgr.request_paint_realign()
            self.statusBar().showMessage("Paint lock normal re-aligned to current hover")
        except Exception:
            log.exception("Failed to request painter re-align")

    def _paint_layer_data(self, name: str) -> dict:
        clean = (str(name or "Paint Layer").strip() or "Paint Layer")
        data = self._paint_layers.get(clean)
        if data is None:
            data = new_paint_layer(clean)
            self._paint_layers[clean] = data
        return data

    def _ordered_paint_preview_layers(self) -> list[dict]:
        out: list[dict] = []
        try:
            metas = self.layers_panel.layer_stack_metas()
        except Exception:
            metas = []
        seen: set[str] = set()
        for m in metas:
            try:
                mm = dict(m or {})
            except Exception:
                continue
            if str(mm.get("kind", "")).lower() != "paint":
                continue
            name = str(mm.get("name") or "").strip() or "Paint Layer"
            layer = self._paint_layer_data(name)
            layer["enabled"] = bool(mm.get("checked", True))
            layer["preview_visible"] = bool(mm.get("checked", True))
            if not layer.get("preview_visible", True):
                continue
            if name in seen:
                continue
            seen.add(name)
            settings = dict(layer.get("settings") or {})
            strokes = list(layer.get("strokes") or [])
            if not strokes:
                continue
            out.append({
                "name": name,
                "enabled": bool(layer.get("enabled", True)),
                "preview_visible": bool(layer.get("preview_visible", True)),
                "settings": settings,
                "strokes": strokes,
            })
        return out

    def _preview_settings_for_renderer(self, base: dict | None = None) -> dict:
        d = dict(base if base is not None else self.params_panel.preview_settings())
        order = self._preview_layer_order_for_renderer()
        if order:
            d["preview_layer_order"] = order
        else:
            d.pop("preview_layer_order", None)
        paint_layers = self._ordered_paint_preview_layers()
        if paint_layers:
            d["paint_layers"] = paint_layers
        else:
            d.pop("paint_layers", None)
        try:
            # Renderer hint: painted/replacement materials should appear as actual
            # block surfaces inside ghosted terrain, not just as a wire brush marker.
            d["paint_preview_block_faces"] = bool(self.paint_panel.settings().get("preview_block_faces", True))
        except Exception:
            d["paint_preview_block_faces"] = True
        return d

    def _push_preview_settings_to_renderer(self, base: dict | None = None, invalidate: bool = True) -> dict:
        settings = self._preview_settings_for_renderer(base)
        self.renderer_mgr.set_preview_settings(settings)
        if invalidate and hasattr(self.renderer_mgr, "invalidate_all_meshes"):
            # renderer may no-op if settings equality already triggered invalidation itself.
            pass
        return settings

    def _sync_preview_ui_state(self) -> None:
        try:
            labels = self.params_panel.active_generator_labels()
        except Exception:
            labels = []
        caves = "caves" in labels
        ores = "ores" in labels
        try:
            self.layers_panel.set_generator_preview_state(caves=caves, ores=ores)
        except Exception:
            pass
        if hasattr(self, "_sb_preview"):
            if not labels:
                self._sb_preview.setText("Preview: Off")
            else:
                self._sb_preview.setText("Preview: " + " + ".join(x.title() for x in labels))
            self._sync_workspace_header()

    def _reset_editing_session_for_new_world(self) -> None:
        # Inspect-first reset: loading a world should never appear pre-edited unless a project is loaded.
        try:
            self.params_panel.disable_all_generator_previews(emit=False)
        except Exception:
            pass
        try:
            self._push_preview_settings_to_renderer(self.params_panel.preview_settings())
        except Exception:
            pass
        try:
            self.layers_panel.clear_runtime_layers()
            self.layers_panel.remove_layers_with_prefix("[EditCore]")
        except Exception:
            pass
        try:
            self.edit_core.reset()
        except Exception:
            pass
        try:
            self.edit_core_panel.set_stats(
                "Developer / internal editing-core tools\n"
                "- Hidden by default in the workflow reset build\n"
                "- Use only for backend milestone testing"
            )
        except Exception:
            pass
        self._paint_layer_strokes.clear()
        self._paint_layers.clear()
        self._paint_layer_redo.clear()
        self._paint_layer_serial = 1
        self.state.paint_mode_enabled = False
        self.state.geological_analysis_manifest = None
        self._sb_tool.setText("Tool: Navigate")
        self._sync_workspace_header()
        if hasattr(self, "act_paint"):
            self.act_paint.blockSignals(True)
            self.act_paint.setChecked(False)
            self.act_paint.blockSignals(False)
        try:
            if hasattr(self.paint_panel, "paint_enabled"):
                self.paint_panel.paint_enabled.setChecked(False)
        except Exception:
            pass
        try:
            if hasattr(self, "inspector_tabs"):
                self.inspector_tabs.setCurrentWidget(self.params_panel)
                self._set_layer_editor_context(
                    "Scene Tools",
                    "Select a feature/layer on the left to edit it. If no layer is selected, scene cutaway + generator controls are shown."
                )
        except Exception:
            pass
        self._sync_preview_ui_state()
        self._update_undo_redo_actions()
        self.statusBar().showMessage("World loaded in Inspect mode. No edits or generator previews are active.")


    def _next_paint_layer_name(self) -> str:
        while True:
            name = f"Paint Layer {self._paint_layer_serial}"
            self._paint_layer_serial += 1
            if name not in self._paint_layer_strokes:
                return name

    def _focus_generate_tab(self) -> None:
        if hasattr(self, "inspector_tabs"):
            self.inspector_tabs.setCurrentWidget(self.params_panel)
            self._set_layer_editor_context("Generator Settings", "Tune the selected generator preview layer.")
            try:
                for i in range(self.params_panel.tabs.count()):
                    if self.params_panel.tabs.tabText(i).lower().startswith("generate"):
                        self.params_panel.tabs.setCurrentIndex(i)
                        break
            except Exception:
                pass

    def _focus_inspect_tab(self) -> None:
        if hasattr(self, "inspector_tabs"):
            self.inspector_tabs.setCurrentWidget(self.params_panel)
            self._set_layer_editor_context(
                "Scene Tools",
                "Inspect / cutaway settings for the loaded world. View mode is fixed to Surface in this build."
            )
            try:
                for i in range(self.params_panel.tabs.count()):
                    if self.params_panel.tabs.tabText(i).lower().startswith("inspect"):
                        self.params_panel.tabs.setCurrentIndex(i)
                        break
            except Exception:
                pass

    @QtCore.Slot()
    def _show_create_feature_dialog(self) -> None:
        kind = CreateFeatureDialog.get_feature_kind(self, show_dev=self._dev_tools_visible)
        if kind:
            self._create_feature(kind)

    @QtCore.Slot(str)
    def _on_quick_feature_requested(self, kind: str) -> None:
        self._create_feature(kind)

    def _create_feature(self, kind: str) -> None:
        kind = str(kind or "").strip().lower()
        if kind == "paint":
            layer_name = self._next_paint_layer_name()
            self._focus_paint_tab()
            self.paint_panel.select_or_create_layer(layer_name)
            self.paint_panel.paint_enabled.setChecked(True)
            self._paint_layer_data(layer_name)
            self.layers_panel.upsert_paint_layer(layer_name, self._paint_layer_strokes.get(layer_name, 0), select=True)
            self.state.active_paint_layer = layer_name
            self.statusBar().showMessage(
                f"Created '{layer_name}'. Drag in the 3D view to record preview strokes."
            )
            return

        if kind in {"caves", "ores", "caves+ores", "both"}:
            self._focus_generate_tab()
            if kind in {"caves+ores", "both"}:
                self.params_panel.enable_generator_preview("both", subtle=True, emit=True)
                self.statusBar().showMessage("Enabled subtle cave + ore previews (non-destructive)")
                self._sync_preview_ui_state()
                self.layers_panel.select_layer_by_key("gen:caves")
            else:
                self.params_panel.enable_generator_preview(kind, subtle=True, emit=True)
                self.statusBar().showMessage(f"Enabled {kind} preview (non-destructive)")
                self._sync_preview_ui_state()
                self.layers_panel.select_layer_by_key(f"gen:{kind}")
            return

        if kind == "box":
            self._set_dev_tools_visible(True)
            if hasattr(self, "act_dev_tools"):
                self.act_dev_tools.blockSignals(True)
                self.act_dev_tools.setChecked(True)
                self.act_dev_tools.blockSignals(False)
            if hasattr(self, "inspector_tabs") and self._edit_core_tab_index >= 0:
                self.inspector_tabs.setCurrentIndex(self._edit_core_tab_index)
                self._set_layer_editor_context("Advanced Layer (Dev)", "Internal editing-core controls for backend testing.")
            self.statusBar().showMessage("Developer Box Replace tool opened (backend test tool)")
            return


    def _update_edit_area_status(self) -> None:
        b = self.state.edit_area_chunk_bounds
        if not b:
            self._sb_area.setText("Area: not set")
            return
        min_cx, max_cx, min_cz, max_cz = [int(v) for v in b]
        w = max_cx - min_cx + 1
        h = max_cz - min_cz + 1
        tag = "Full" if self.state.edit_area_full_world else f"{w}x{h} ch"
        self._sb_area.setText(f"Area: {tag}")
        self._sync_workspace_header()

    def _apply_project_area_selection(self, bounds: tuple[int, int, int, int], *, full_world: bool = False, recenter: bool = True) -> None:
        min_cx, max_cx, min_cz, max_cz = [int(v) for v in bounds]
        if min_cx > max_cx:
            min_cx, max_cx = max_cx, min_cx
        if min_cz > max_cz:
            min_cz, max_cz = max_cz, min_cz
        self.state.edit_area_chunk_bounds = (min_cx, max_cx, min_cz, max_cz)
        self.state.edit_area_full_world = bool(full_world)
        try:
            self.renderer_mgr.set_edit_area_chunk_bounds(self.state.edit_area_chunk_bounds)
        except Exception:
            log.exception("Failed to apply project area to renderer")
        self._update_edit_area_status()
        if recenter:
            cx = (min_cx + max_cx) // 2
            cz = (min_cz + max_cz) // 2
            try:
                self.renderer_mgr.focus_chunk(cx, cz)
            except Exception:
                pass
        self.statusBar().showMessage(
            f"Project area set: X {min_cx}..{max_cx}, Z {min_cz}..{max_cz} ({max_cx-min_cx+1}x{max_cz-min_cz+1} chunks)"
        )

    def _open_project_area_dialog(self, *, initial_bounds=None) -> bool:
        if self._last_world_index is None:
            QtWidgets.QMessageBox.information(self, "Project Area", "Load a world first.")
            return False
        current = initial_bounds if initial_bounds is not None else self.state.edit_area_chunk_bounds
        sel = ProjectAreaDialog.get_selection(self._last_world_index, current_selection=current, parent=self)
        if sel is None:
            return False
        self._apply_project_area_selection(sel.chunk_bounds, full_world=sel.use_full_world, recenter=True)
        return True

    @QtCore.Slot()
    def edit_project_area(self) -> None:
        self._open_project_area_dialog()

    @QtCore.Slot()
    def show_startup_prompt(self) -> None:
        if self._startup_prompt_shown:
            return
        self._startup_prompt_shown = True
        if self.state.world_path is not None:
            return
        dlg = StartupDialog(self)
        if dlg.exec() != int(QtWidgets.QDialog.DialogCode.Accepted):
            self.statusBar().showMessage("Ready")
            return
        if dlg.choice == 'load_project':
            self.load_project()
        elif dlg.choice == 'open_world':
            self.open_world()
        elif dlg.choice == 'open_worldpainter':
            self.open_world_with_worldpainter()

    def _start_world_index_for_path(self, world_path: Path) -> None:
        self._worldpainter_import = None
        self.state.worldpainter_source_path = None
        self.state.worldpainter_package_path = None
        self.state.worldpainter_project_name = ""
        self.state.worldpainter_alignment_status = ""
        self.geology_analysis_panel.set_context(
            world_loaded=False,
            world_name="",
            worldpainter_available=False,
            worldpainter_name="",
        )
        self.state.world_path = world_path
        self.state.world_name = world_path.name
        self._sb_world.setText(f"World: {world_path.name} (indexing...)")
        self._sync_workspace_header()
        self.statusBar().showMessage(f"Indexing world: {world_path} ...")
        log.info("Opening world: %s", world_path)
        self._indexer.start_index(world_path)

    def _collect_project_payload(self) -> dict:
        selected_meta = self.layers_panel.current_layer_meta() if hasattr(self.layers_panel, "current_layer_meta") else {}
        paint_layers_store = serialize_paint_layers(self._paint_layers)
        return {
            'schema': 'worldgeolabs.project.v2',
            'world_path': str(self.state.world_path),
            'world_name': self.state.world_name,
            'worldpainter_source_path': str(self.state.worldpainter_source_path or ''),
            'worldpainter_package_path': str(self.state.worldpainter_package_path or ''),
            'worldpainter_project_name': self.state.worldpainter_project_name,
            'worldpainter_alignment_status': self.state.worldpainter_alignment_status,
            'geological_analysis_manifest': str(self.state.geological_analysis_manifest or ''),
            'chunk_bounds': list(self.state.chunk_bounds) if self.state.chunk_bounds else None,
            'height_range': list(self.state.height_range) if self.state.height_range else None,
            'spawn_chunk': list(self.state.spawn_chunk) if self.state.spawn_chunk else None,
            'edit_area_chunk_bounds': list(self.state.edit_area_chunk_bounds) if self.state.edit_area_chunk_bounds else None,
            'edit_area_full_world': bool(self.state.edit_area_full_world),
            'view_mode': self.state.view_mode,
            'preview_settings': self.params_panel.preview_settings(),
            'view_settings': self.params_panel.view_settings(),
            'paint_settings': self.paint_panel.settings(),
            'paint_layer_serial': int(self._paint_layer_serial),
            'paint_layers_store': paint_layers_store,
            'layer_stack': self.layers_panel.layer_stack_metas(),
            'selected_layer_key': str(selected_meta.get('key') or ''),
            'blocks_visibility': self.blocks_panel.visibility_map(),
            'performance_settings': self.renderer_mgr.get_performance_settings(),
            'dev_tools_visible': bool(self._dev_tools_visible),
        }

    @QtCore.Slot()
    def save_project(self) -> None:
        if self.state.world_path is None or self._last_world_index is None:
            QtWidgets.QMessageBox.information(self, "Save Project", "Open a world first.")
            return
        default_dir = str(self.state.world_path)
        default_name = str((self.state.world_path / f"{self.state.world_name}.mcgeo.json").resolve())
        path, _ = QtWidgets.QFileDialog.getSaveFileName(
            self,
            "Save WorldGeoLabs Project",
            default_name if Path(default_name).parent.exists() else default_dir,
            "WorldGeoLabs Project (*.mcgeo.json);;JSON (*.json)"
        )
        if not path:
            return
        p = Path(path)
        if p.suffix.lower() == '.json' and not p.name.endswith('.mcgeo.json'):
            pass
        elif p.suffix.lower() != '.json':
            p = p.with_suffix(p.suffix + '.json' if p.suffix else '.mcgeo.json')
        data = self._collect_project_payload()
        try:
            p.write_text(json.dumps(data, indent=2), encoding='utf-8')
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Save Project", f"Failed to save project\n{e}")
            return
        self.state.project_path = p
        self.statusBar().showMessage(f"Project saved: {p}")
        log.info("Saved project file: %s", p)

    def _restore_project_payload(self, data: dict) -> None:
        payload = dict(data or {})
        try:
            self._set_dev_tools_visible(bool(payload.get("dev_tools_visible", False)))
        except Exception:
            pass
        try:
            preview_settings = payload.get("preview_settings")
            if isinstance(preview_settings, dict):
                self.params_panel.apply_preview_settings(preview_settings, emit=False)
                self._on_preview_settings_changed(self.params_panel.preview_settings())
        except Exception:
            log.exception("Failed to restore preview settings from project")
        try:
            view_settings = payload.get("view_settings")
            if isinstance(view_settings, dict):
                self.params_panel.apply_view_settings(view_settings, emit=False)
                self._on_view_settings_changed(self.params_panel.view_settings())
        except Exception:
            log.exception("Failed to restore view settings from project")
        try:
            perf = payload.get("performance_settings")
            if isinstance(perf, dict) and perf:
                self.renderer_mgr.apply_performance_settings(perf)
                mode = str(perf.get("edit_mode", self.renderer_mgr.get_edit_mode())).lower()
                if hasattr(self, "act_lod_edit") and hasattr(self, "act_detailed_edit"):
                    self.act_lod_edit.blockSignals(True); self.act_detailed_edit.blockSignals(True)
                    self.act_lod_edit.setChecked(mode.startswith("lod"))
                    self.act_detailed_edit.setChecked(not mode.startswith("lod"))
                    self.act_lod_edit.blockSignals(False); self.act_detailed_edit.blockSignals(False)
        except Exception:
            log.exception("Failed to restore performance settings from project")
        self._paint_layer_strokes.clear()
        self._paint_layers.clear()
        self._paint_layer_redo.clear()
        self._paint_layer_serial = int(payload.get("paint_layer_serial", 1) or 1)
        self._paint_layers, self._paint_layer_strokes = restore_paint_layers(payload.get("paint_layers_store"))
        for clean in self._paint_layers:
            self.paint_panel.select_or_create_layer(clean, select_only=True)
        try:
            layer_stack = payload.get("layer_stack")
            selected_key = str(payload.get("selected_layer_key") or "")
            if isinstance(layer_stack, list) and layer_stack:
                self.layers_panel.restore_layer_stack(layer_stack, selected_key=selected_key or None)
            else:
                for name in self._paint_layers:
                    self.layers_panel.upsert_paint_layer(name, self._paint_layer_strokes.get(name, 0), select=False)
        except Exception:
            log.exception("Failed to restore layer stack from project")
        try:
            paint_settings = payload.get("paint_settings")
            if isinstance(paint_settings, dict):
                self.paint_panel.apply_settings(paint_settings, emit=False)
                self._on_paint_settings_changed(self.paint_panel.settings())
        except Exception:
            log.exception("Failed to restore paint settings from project")
        try:
            block_vis = payload.get("blocks_visibility")
            if isinstance(block_vis, dict) and block_vis:
                self.blocks_panel.set_visibility_map(block_vis, emit=False)
                self._on_blocks_visibility()
        except Exception:
            log.exception("Failed to restore block visibility from project")
        try:
            analysis_raw = str(payload.get("geological_analysis_manifest") or "").strip()
            if analysis_raw:
                analysis_path = Path(analysis_raw)
                if not analysis_path.is_absolute() and self.state.project_path is not None:
                    analysis_path = (self.state.project_path.parent / analysis_path).resolve()
                if analysis_path.is_file():
                    self.state.geological_analysis_manifest = analysis_path
                    self.geology_analysis_panel.load_manifest(analysis_path)
        except Exception:
            log.exception("Failed to restore geological analysis from project")
        self._push_preview_settings_to_renderer()
        self._sync_layer_header_from_layers_selection()
        self._sync_workspace_header()
        self._update_undo_redo_actions()

    def _build_apply_summary(self) -> dict:
        metas = self.layers_panel.layer_stack_metas()
        paint_layers = sum(1 for m in metas if str(m.get("kind", "")).lower() == "paint")
        generator_layers = sum(1 for m in metas if str(m.get("kind", "")).lower() == "generator")
        visible_paint = sum(1 for _name, layer in self._paint_layers.items() if bool(layer.get("preview_visible", True)) and list(layer.get("strokes") or []))
        stroke_count = sum(len(list(layer.get("strokes") or [])) for layer in self._paint_layers.values())
        area = self.state.edit_area_chunk_bounds
        if area is not None:
            min_cx, max_cx, min_cz, max_cz = area
            area_label = f"chunks {min_cx}..{max_cx}, {min_cz}..{max_cz}"
        else:
            area_label = "Area not selected"
        preview_labels = self.params_panel.active_generator_labels()
        paint_export_layers = self._ordered_paint_preview_layers()
        paint_export_strokes = sum(len(list(layer.get("strokes") or [])) for layer in paint_export_layers)
        if paint_export_strokes:
            preview_summary = f"{len(paint_export_layers)} visible paint layer(s), {paint_export_strokes} stroke(s)"
        else:
            preview_summary = "No visible paint strokes ready to export"
        if preview_labels:
            preview_summary += " | generator previews not exported in this pass: " + ", ".join(x.title() for x in preview_labels)
        warnings = []
        if self.state.world_path is None:
            warnings.append("No world is open.")
        if area is None:
            warnings.append("No project area is selected yet.")
        if preview_labels:
            warnings.append("Generator previews are still preview-only; this export pass writes Paint layers only.")
        if not paint_export_strokes:
            warnings.append("There are no visible/enabled paint strokes to export yet.")
        return {
            "world_name": self.state.world_name or "No world loaded",
            "world_path": str(self.state.world_path) if self.state.world_path else "",
            "project_path": str(self.state.project_path) if self.state.project_path else "",
            "area_label": area_label,
            "layer_summary": f"{paint_layers} paint layer(s), {generator_layers} generator preview layer(s)",
            "preview_summary": preview_summary,
            "notes": "Incremental export writes only region files that contain visible/enabled paint-layer changes. The recommended copy mode keeps the original world untouched.",
            "warnings": warnings,
        }

    @QtCore.Slot()
    def load_project(self) -> None:
        path, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Load WorldGeoLabs Project",
            str(Path.cwd()),
            "WorldGeoLabs Project (*.mcgeo.json);;JSON (*.json)"
        )
        if not path:
            return
        p = Path(path)
        try:
            data = json.loads(p.read_text(encoding='utf-8'))
        except Exception as e:
            QtWidgets.QMessageBox.critical(self, "Load Project", f"Failed to read project file\n{e}")
            return
        world_path_raw = str(data.get('world_path') or '').strip()
        if not world_path_raw:
            QtWidgets.QMessageBox.critical(self, "Load Project", "Project file is missing world_path.")
            return
        world_path = Path(world_path_raw)
        if not world_path.exists():
            rel = (p.parent / world_path_raw).resolve()
            if rel.exists():
                world_path = rel
        if not world_path.exists():
            QtWidgets.QMessageBox.critical(self, "Load Project", f"World path not found\n{world_path}")
            return
        self.state.project_path = p
        self._pending_project_payload = dict(data)
        wp_raw = str(data.get('worldpainter_source_path') or data.get('worldpainter_package_path') or '').strip()
        self._pending_worldpainter_source = Path(wp_raw) if wp_raw else None
        self._start_world_index_for_path(world_path)

    @QtCore.Slot()
    def open_world(self) -> None:
        path = QtWidgets.QFileDialog.getExistingDirectory(self, "Select Minecraft world folder")
        if not path:
            return
        self._start_world_index_for_path(Path(path))


    @QtCore.Slot()
    def open_world_with_worldpainter(self) -> None:
        world_path = QtWidgets.QFileDialog.getExistingDirectory(
            self, "Select exported Minecraft world folder"
        )
        if not world_path:
            return
        source, _ = QtWidgets.QFileDialog.getOpenFileName(
            self,
            "Select WorldPainter project or WorldGeoLabs analysis package",
            str(Path(world_path).parent),
            "WorldPainter/analysis (*.world *.zip *.wglwp);;WorldPainter Project (*.world);;Analysis Package (*.zip *.wglwp);;All Files (*)",
        )
        if not source:
            return
        self._pending_worldpainter_source = Path(source)
        self._start_world_index_for_path(Path(world_path))

    def _load_pending_worldpainter_source(self, world_index) -> None:
        source = self._pending_worldpainter_source
        self._pending_worldpainter_source = None
        if source is None:
            return
        try:
            cache_root = Path(world_index.world_path) / ".worldgeolabs" / "worldpainter_cache"
            result = import_worldpainter_source(
                source,
                app_root=Path(__file__).resolve().parents[2],
                cache_root=cache_root,
            )
            dimension = result.package.dimension_for_anchor("minecraft:overworld")
            if dimension is None:
                raise WorldPainterPackageError("The WorldPainter package has no usable dimension")
            report = compare_metadata(
                dimension,
                minecraft_chunk_bounds=world_index.chunk_bounds,
                minecraft_height_range=world_index.height_range,
            )
            self._worldpainter_import = result
            self.state.worldpainter_source_path = result.original_source
            self.state.worldpainter_package_path = result.package_path
            self.state.worldpainter_project_name = result.package.project_name
            self.state.worldpainter_alignment_status = report.status
            log.info(
                "WorldPainter source loaded: project=%s version=%s dimension=%s status=%s package=%s",
                result.package.project_name,
                result.package.worldpainter_version,
                dimension.name,
                report.status,
                result.package_path,
            )
            for message in report.messages:
                log.info("WorldPainter alignment: %s", message)
            details = "\n".join(report.messages)
            QtWidgets.QMessageBox.information(
                self,
                "WorldPainter source loaded",
                f"Project: {result.package.project_name}\n"
                f"Dimension: {dimension.name}\n"
                f"Datasets: {', '.join(sorted(dimension.datasets)) or 'metadata only'}\n"
                f"Alignment: {report.status}\n\n{details}",
            )
        except (WorldPainterBridgeError, WorldPainterPackageError, OSError, ValueError) as exc:
            log.warning("WorldPainter import unavailable: %s", exc)
            QtWidgets.QMessageBox.warning(
                self,
                "WorldPainter import",
                f"The Minecraft world will still open normally.\n\n{exc}",
            )


    @QtCore.Slot()
    def show_geological_analysis(self) -> None:
        if self.state.world_path is None or self._last_world_index is None:
            QtWidgets.QMessageBox.information(
                self, "Geological Analysis", "Open a Minecraft world first."
            )
            return
        if hasattr(self, "inspector_tabs"):
            self.inspector_tabs.setCurrentWidget(self.geology_analysis_panel)
        self._set_layer_editor_context(
            "Geological Analysis",
            "Build and inspect cached whole-map analysis before generating caves or mineral deposits.",
        )

    @QtCore.Slot(object)
    def _start_geological_analysis(self, settings: object) -> None:
        if self.state.world_path is None or self._last_world_index is None:
            QtWidgets.QMessageBox.information(
                self, "Geological Analysis", "Open a Minecraft world first."
            )
            return
        if self._analysis_thread is not None and self._analysis_thread.isRunning():
            QtWidgets.QMessageBox.information(
                self, "Geological Analysis", "An analysis is already running."
            )
            return

        values = dict(settings or {})
        scope = str(values.get("scope") or "full_world")
        if scope == "selected_area" and self.state.edit_area_chunk_bounds is not None:
            bounds = tuple(int(v) for v in self.state.edit_area_chunk_bounds)
        else:
            bounds = tuple(int(v) for v in self.state.chunk_bounds)

        wp_package = None
        if self._worldpainter_import is not None:
            wp_package = Path(self._worldpainter_import.package_path)
        elif self.state.worldpainter_package_path is not None:
            candidate = Path(self.state.worldpainter_package_path)
            if candidate.exists():
                wp_package = candidate

        source_mode = str(values.get("source_mode") or "auto")
        if source_mode == "worldpainter" and wp_package is None:
            QtWidgets.QMessageBox.warning(
                self,
                "Geological Analysis",
                "WorldPainter-only analysis was selected, but this world has no loaded WorldPainter analysis package.",
            )
            return

        options = AnalysisOptions(
            world_path=Path(self.state.world_path),
            chunk_bounds=bounds,
            height_range=tuple(int(v) for v in self.state.height_range),
            scope_name=scope,
            requested_step=int(values.get("requested_step", 8)),
            verification_step=int(values.get("verification_step", 32)),
            source_mode=source_mode,
            worldpainter_package=wp_package,
            block_profile=(
                Path(__file__).resolve().parents[2]
                / "config" / "geology" / "minecraft_26_2_block_categories.toml"
            ),
            geology_profile=(
                Path(__file__).resolve().parents[2]
                / "config" / "geology" / "world_geology_profile.toml"
            ),
            force_rebuild=bool(values.get("force_rebuild", False)),
            workers=int(values.get("workers", 0) or 0),
        )

        self._analysis_cancel_event = threading.Event()
        self._analysis_thread = QtCore.QThread(self)
        self._analysis_worker = GeologicalAnalysisWorker(
            options, self._analysis_cancel_event
        )
        self._analysis_worker.moveToThread(self._analysis_thread)
        self._analysis_thread.started.connect(self._analysis_worker.run)
        self._analysis_worker.progress.connect(self.geology_analysis_panel.set_progress)
        self._analysis_worker.finished.connect(self._on_geological_analysis_finished)
        self._analysis_worker.failed.connect(self._on_geological_analysis_failed)
        self._analysis_worker.cancelled.connect(self._on_geological_analysis_cancelled)
        self._analysis_worker.finished.connect(self._analysis_thread.quit)
        self._analysis_worker.failed.connect(self._analysis_thread.quit)
        self._analysis_worker.cancelled.connect(self._analysis_thread.quit)
        self._analysis_thread.finished.connect(self._cleanup_geological_analysis_worker)
        self.geology_analysis_panel.set_running(True)
        self.statusBar().showMessage("Geological analysis running…")
        self._analysis_thread.start()

    @QtCore.Slot()
    def _cancel_geological_analysis(self) -> None:
        if self._analysis_cancel_event is not None:
            self._analysis_cancel_event.set()
            self.geology_analysis_panel.set_progress(
                self.geology_analysis_panel.progress.value(),
                "Cancelling after the current analysis operation…",
            )

    @QtCore.Slot(object)
    def _on_geological_analysis_finished(self, report: object) -> None:
        self.state.geological_analysis_manifest = Path(report.manifest_path)
        self.geology_analysis_panel.set_report(report)
        analysis_layers = [
            ("Analysis: Geological Model", "geology_category"),
            ("Analysis: Surface Height", "surface_height"),
            ("Analysis: Slope", "slope_degrees"),
            ("Analysis: Drainage", "flow_accumulation"),
            ("Analysis: WorldPainter Terrain", "worldpainter_category"),
            ("Analysis: Minecraft Surface", "surface_category"),
            ("Analysis: Host Rock", "host_category"),
            ("Analysis: Soil Depth", "soil_depth"),
            ("Analysis: Structural Uplift", "uplift_score"),
            ("Analysis: Sedimentary Basins", "basin_score"),
            ("Analysis: Erosion / Exposure", "erosion_score"),
            ("Analysis: Fault / Fracture Corridors", "fracture_score"),
            ("Analysis: Hydrothermal Potential", "hydrothermal_score"),
            ("Analysis: Paleo-Organic Basins", "paleo_organic_score"),
            ("Analysis: Placer Potential", "placer_score"),
            ("Analysis: Orogenic Belts", "orogenic_score"),
            ("Analysis: Stable Deep Crust", "stable_craton_score"),
            ("Analysis: Folded Strata Warp", "structural_warp_blocks"),
        ]
        for label, dataset in reversed(analysis_layers):
            self.layers_panel.ensure_named_layer(
                label,
                checked=True,
                top=True,
                meta={
                    "kind": "analysis",
                    "key": f"analysis:{dataset}",
                    "label": label,
                    "dataset": dataset,
                    "manifest_path": str(report.manifest_path),
                    "checked": True,
                    "editable": False,
                },
                select=False,
            )
        self.statusBar().showMessage(
            f"Geological analysis ready: {report.grid_shape[1]:,}×{report.grid_shape[0]:,} cells"
        )
        log.info(
            "Geological analysis complete: manifest=%s source=%s chunks=%s sections=%s",
            report.manifest_path,
            report.source_summary,
            report.sampled_chunks,
            report.sampled_sections,
        )

    @QtCore.Slot(str)
    def _on_geological_analysis_failed(self, message: str) -> None:
        self.geology_analysis_panel.set_failure(message)
        self.statusBar().showMessage("Geological analysis failed")
        log.error("Geological analysis failed: %s", message)

    @QtCore.Slot()
    def _on_geological_analysis_cancelled(self) -> None:
        self.geology_analysis_panel.set_cancelled()
        self.statusBar().showMessage("Geological analysis cancelled")

    @QtCore.Slot()
    def _cleanup_geological_analysis_worker(self) -> None:
        if self._analysis_worker is not None:
            self._analysis_worker.deleteLater()
        if self._analysis_thread is not None:
            self._analysis_thread.deleteLater()
        self._analysis_worker = None
        self._analysis_thread = None
        self._analysis_cancel_event = None

    @QtCore.Slot(object)
    def _start_geological_resource_generation(self, settings: object) -> None:
        if self.state.geological_analysis_manifest is None:
            QtWidgets.QMessageBox.information(self, "Geological Resources", "Run Geological Analysis first.")
            return
        if self._resource_thread is not None and self._resource_thread.isRunning():
            QtWidgets.QMessageBox.information(self, "Geological Resources", "Resource generation is already running.")
            return
        if self._analysis_thread is not None and self._analysis_thread.isRunning():
            QtWidgets.QMessageBox.information(self, "Geological Resources", "Wait for Geological Analysis to finish first.")
            return
        values = dict(settings or {})
        manifest = Path(str(values.get("manifest_path") or self.state.geological_analysis_manifest))
        profile = Path(__file__).resolve().parents[2] / "config" / "geology" / "world_geology_profile.toml"
        options = ResourceGenerationOptions(
            manifest_path=manifest,
            profile_path=profile,
            seed=(int(values.get("seed")) if values.get("seed") is not None else None),
            population_scale=float(values.get("population_scale", 1.0)),
            write_suitability_arrays=True,
        )
        self._resource_cancel_event = threading.Event()
        self._resource_thread = QtCore.QThread(self)
        self._resource_worker = GeologicalResourceWorker(options, self._resource_cancel_event)
        self._resource_worker.moveToThread(self._resource_thread)
        self._resource_thread.started.connect(self._resource_worker.run)
        self._resource_worker.progress.connect(self.geology_analysis_panel.set_progress)
        self._resource_worker.finished.connect(self._on_geological_resource_finished)
        self._resource_worker.failed.connect(self._on_geological_resource_failed)
        self._resource_worker.cancelled.connect(self._on_geological_resource_cancelled)
        self._resource_worker.finished.connect(self._resource_thread.quit)
        self._resource_worker.failed.connect(self._resource_thread.quit)
        self._resource_worker.cancelled.connect(self._resource_thread.quit)
        self._resource_thread.finished.connect(self._cleanup_geological_resource_worker)
        self.geology_analysis_panel.set_resource_running(True)
        self.statusBar().showMessage("Generating whole-world geological resource plan…")
        self._resource_thread.start()

    @QtCore.Slot()
    def _cancel_geological_resource_generation(self) -> None:
        if self._resource_cancel_event is not None:
            self._resource_cancel_event.set()
            self.geology_analysis_panel.set_progress(
                self.geology_analysis_panel.progress.value(),
                "Cancelling geological resource generation…",
            )

    @QtCore.Slot(object)
    def _on_geological_resource_finished(self, report: object) -> None:
        self.geology_analysis_panel.set_resource_report(report)
        added = 0
        for layer_name, layer in dict(report.paint_layers or {}).items():
            self._paint_layers[str(layer_name)] = dict(layer)
            self._paint_layer_strokes[str(layer_name)] = len(list(layer.get("strokes") or []))
            self._paint_layer_redo[str(layer_name)] = []
            self.layers_panel.upsert_paint_layer(
                str(layer_name),
                stroke_count=self._paint_layer_strokes[str(layer_name)],
                select=False,
                checked=True,
            )
            added += 1
        # Add read-only suitability maps to the layer stack so users can inspect
        # why the generator preferred one province over another.
        try:
            manifest_doc = json.loads(Path(report.manifest_path).read_text(encoding="utf-8"))
            labels = {
                str(d.get("id")): str(d.get("label") or d.get("id"))
                for d in (manifest_doc.get("resource_deposits") or [])
            }
            arrays = dict(manifest_doc.get("arrays") or {})
            for dep_id in reversed(list(dict(report.deposit_counts or {}).keys())):
                dataset = f"resource_{dep_id}_suitability"
                if dataset not in arrays:
                    continue
                label = f"Suitability: {labels.get(dep_id, dep_id.replace('_', ' ').title())}"
                self.layers_panel.ensure_named_layer(
                    label, checked=True, top=True,
                    meta={
                        "kind": "analysis",
                        "key": f"analysis:{dataset}",
                        "label": label,
                        "dataset": dataset,
                        "manifest_path": str(report.manifest_path),
                        "checked": True,
                        "editable": False,
                    },
                    select=False,
                )
        except Exception:
            log.exception("Failed to add resource suitability layers")

        self._push_preview_settings_to_renderer(invalidate=True)
        total_deposits = int(sum(dict(report.deposit_counts or {}).values()))
        total_strokes = int(sum(dict(report.stroke_counts or {}).values()))
        self.statusBar().showMessage(
            f"Geological resource plan ready: {total_deposits:,} deposits in {added} layers / {total_strokes:,} edit strokes",
            12000,
        )
        log.info(
            "Geological resource plan ready: plan=%s deposits=%s strokes=%s layers=%s",
            report.plan_path, total_deposits, total_strokes, added,
        )

    @QtCore.Slot(str)
    def _on_geological_resource_failed(self, message: str) -> None:
        self.geology_analysis_panel.set_resource_failure(message)
        self.statusBar().showMessage("Geological resource generation failed")
        log.error("Geological resource generation failed: %s", message)

    @QtCore.Slot()
    def _on_geological_resource_cancelled(self) -> None:
        self.geology_analysis_panel.set_resource_cancelled()
        self.statusBar().showMessage("Geological resource generation cancelled")

    @QtCore.Slot()
    def _cleanup_geological_resource_worker(self) -> None:
        if self._resource_worker is not None:
            self._resource_worker.deleteLater()
        if self._resource_thread is not None:
            self._resource_thread.deleteLater()
        self._resource_worker = None
        self._resource_thread = None
        self._resource_cancel_event = None

    @QtCore.Slot(str)
    def _on_index_progress(self, msg: str) -> None:
        self.statusBar().showMessage(msg)

    def _preload_selected_area_regions(self, world_index, bounds: tuple[int, int, int, int]) -> None:
        """Read all region files intersecting the selected edit area before 3D streaming starts.

        This is an upfront warm-cache pass (with progress bar) so the first 3D session feels less
        like it is stalling on cold file reads. It preserves the detailed 2D overview map and does
        not change mesh quality.
        """
        try:
            region_files = region_files_for_chunk_bounds(Path(world_index.region_dir), bounds)
        except Exception:
            log.exception("Failed to enumerate selected-area region files for warmup")
            return
        total = len(region_files)
        if total <= 0:
            return
        warmup_limit = int(os.environ.get("WGL_REGION_WARMUP_FILE_LIMIT", "512") or "512")
        if total > warmup_limit:
            msg = (
                f"Huge edit area detected: skipping upfront region warmup for {total} region files "
                f"(limit {warmup_limit}). Terrain will stream on demand."
            )
            self.statusBar().showMessage(msg)
            log.info(msg)
            return

        dlg = QtWidgets.QProgressDialog("Preparing selected area…", None, 0, total, self)
        dlg.setWindowTitle("Preparing world data")
        dlg.setWindowModality(QtCore.Qt.WindowModality.WindowModal)
        dlg.setMinimumDuration(0)
        dlg.setAutoClose(False)
        dlg.setAutoReset(False)
        dlg.setValue(0)
        dlg.setLabelText(f"Reading {total} region file(s) for the selected edit area…")

        thread = QtCore.QThread(self)
        worker = RegionWarmupWorker(region_files, workers=max(1, (os.cpu_count() or 4)))
        worker.moveToThread(thread)

        loop = QtCore.QEventLoop(self)
        summary_box: dict[str, object] = {}
        error_box: dict[str, str] = {}

        @QtCore.Slot(int, int, str)
        def _on_prog(done: int, total_count: int, message: str) -> None:
            try:
                dlg.setMaximum(max(1, int(total_count)))
                dlg.setValue(max(0, min(int(done), int(total_count))))
                dlg.setLabelText(message)
                self.statusBar().showMessage(message)
            except Exception:
                pass

        @QtCore.Slot(object)
        def _on_done(summary) -> None:
            summary_box["summary"] = summary
            loop.quit()

        @QtCore.Slot(str)
        def _on_failed(err: str) -> None:
            error_box["error"] = str(err)
            loop.quit()

        worker.progress.connect(_on_prog)
        worker.finished.connect(_on_done)
        worker.failed.connect(_on_failed)
        thread.started.connect(worker.run)
        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)
        thread.finished.connect(worker.deleteLater)

        thread.start()
        dlg.show()
        loop.exec()

        try:
            thread.quit()
            thread.wait(2000)
        except Exception:
            pass
        try:
            dlg.setValue(dlg.maximum())
            dlg.close()
        except Exception:
            pass

        if "error" in error_box:
            log.warning("Selected-area region warmup failed: %s", error_box["error"])
            self.statusBar().showMessage("World indexed (warmup skipped due to error)")
            return

        summary = summary_box.get("summary")
        if summary is not None:
            try:
                mib = float(getattr(summary, "total_bytes", 0)) / (1024.0 * 1024.0)
                done_files = int(getattr(summary, "done_files", 0))
                total_files = int(getattr(summary, "total_files", 0))
                workers_used = int(getattr(summary, "workers", 0))
                msg = f"Prepared {done_files}/{total_files} region files ({mib:.1f} MiB) using {workers_used} workers"
                self.statusBar().showMessage(msg)
                log.info(msg)
            except Exception:
                pass

    def _preload_selected_area_meshes(self, bounds: tuple[int, int, int, int]) -> None:
        """Blocking selected-area decode/mesh preload with a progress dialog.

        Runs after the world/index + project area are known, but before interactive viewport timers
        resume. This front-loads chunk decode + greedy mesh generation into caches so the first 3D
        view comes up populated and later camera moves are mostly cache hits.
        """
        try:
            min_cx, max_cx, min_cz, max_cz = [int(v) for v in bounds]
            if min_cx > max_cx:
                min_cx, max_cx = max_cx, min_cx
            if min_cz > max_cz:
                min_cz, max_cz = max_cz, min_cz
        except Exception:
            return

        total = max(0, (max_cx - min_cx + 1) * (max_cz - min_cz + 1))
        if total <= 0:
            return
        preload_limit = int(os.environ.get("WGL_STARTUP_VOXEL_PRELOAD_LIMIT", "2048") or "2048")
        if total > preload_limit:
            msg = (
                f"Huge edit area streaming mode: selected {total:,} chunks, so startup will not build every voxel mesh "
                f"(limit {preload_limit:,}). Detailed chunks load around the camera/brush; surface LOD provides wider context."
            )
            self.statusBar().showMessage(msg)
            log.info(msg)
            return

        dlg = QtWidgets.QProgressDialog("Loading selected world area…", "Cancel", 0, total, self)
        dlg.setWindowTitle("Loading world")
        dlg.setWindowModality(QtCore.Qt.WindowModality.WindowModal)
        dlg.setMinimumDuration(0)
        dlg.setAutoClose(False)
        dlg.setAutoReset(False)
        dlg.setValue(0)
        dlg.setLabelText("Decoding chunks + building meshes for the selected area…")

        cancelled = {"flag": False}

        def _on_cancel() -> None:
            cancelled["flag"] = True

        dlg.canceled.connect(_on_cancel)
        dlg.show()
        QtWidgets.QApplication.processEvents()

        def _progress(done: int, total_count: int, message: str) -> None:
            try:
                dlg.setMaximum(max(1, int(total_count)))
                dlg.setValue(max(0, min(int(done), int(total_count))))
                dlg.setLabelText(str(message))
                self.statusBar().showMessage(str(message))
            except Exception:
                pass
            QtWidgets.QApplication.processEvents()

        try:
            summary = self.renderer_mgr.preload_selected_area_voxel_cache(
                (min_cx, max_cx, min_cz, max_cz),
                progress_cb=_progress,
                cancel_check=lambda: bool(cancelled.get("flag", False)),
            )
        finally:
            try:
                dlg.setValue(dlg.maximum())
                dlg.close()
            except Exception:
                pass

        try:
            if summary and summary.get("cancelled"):
                msg = (
                    f"World preload canceled at {int(summary.get('done', 0))}/{int(summary.get('total', 0))} chunks. "
                    "Continuing with interactive streaming."
                )
                self.statusBar().showMessage(msg)
                log.warning(msg)
            else:
                staged = dict(summary.get('staged') or {})
                upload = dict(summary.get('gpu_upload') or {})
                msg = (
                    f"Selected area preloaded: {int(summary.get('done', 0))}/{int(summary.get('total', 0))} chunks "
                    f"(built {int(summary.get('built', 0))}, failed {int(summary.get('failed', 0))}, staged {int(staged.get('emitted', 0))}, uploaded {int(upload.get('uploaded', 0))}) "
                    f"using {int(summary.get('workers', 0))} workers"
                )
                self.statusBar().showMessage(msg)
                log.info(msg)
                if upload.get('reason') == 'gl_not_ready':
                    log.warning("Startup preload staged meshes but GL uploads were deferred because the context was not ready yet")
        except Exception:
            pass

    @QtCore.Slot(object)
    def _on_index_done(self, world_index) -> None:
        self.state.chunk_bounds = world_index.chunk_bounds
        self.state.height_range = world_index.height_range
        self.state.spawn_chunk = world_index.spawn_chunk
        self._last_world_index = world_index
        self._anvil_world = AnvilWorld(world_index.world_path, getattr(world_index, "dimension_id", "minecraft:overworld"))
        if self._pending_worldpainter_source is not None:
            self._load_pending_worldpainter_source(world_index)

        pending = self._pending_project_payload or {}
        self._pending_project_payload = None
        project_area_bounds = None
        project_area_full = False
        loaded_from_project = False
        if pending:
            try:
                arr = pending.get('edit_area_chunk_bounds')
                if isinstance(arr, (list, tuple)) and len(arr) == 4:
                    project_area_bounds = tuple(int(v) for v in arr)
                project_area_full = bool(pending.get('edit_area_full_world', False))
                loaded_from_project = True
            except Exception:
                project_area_bounds = None

        if project_area_bounds is None:
            sel = ProjectAreaDialog.get_selection(world_index, current_selection=self.state.edit_area_chunk_bounds, parent=self)
            if sel is None:
                self.statusBar().showMessage("World indexed. Project area selection canceled.")
                self._sb_world.setText(f"World: {self.state.world_name} (indexed; area not selected)")
                self._sync_workspace_header()
                self._update_edit_area_status()
                return
            project_area_bounds = sel.chunk_bounds
            project_area_full = sel.use_full_world

        self.statusBar().showMessage(
            f"Loaded {self.state.world_name} | chunks {self.state.chunk_bounds} | y {self.state.height_range}"
        )
        self._sb_world.setText(
            f"World: {self.state.world_name} | y {self.state.height_range[0]}..{self.state.height_range[1]}"
        )
        self._sync_workspace_header()
        log.info(
            "World indexed: bounds=%s height=%s spawn_chunk=%s regions=%s/%s usable void=%s invalid=%s present_chunks=%s",
            self.state.chunk_bounds, self.state.height_range, self.state.spawn_chunk,
            getattr(world_index, "region_files_usable", 0), getattr(world_index, "region_files_total", 0),
            getattr(world_index, "region_files_void", 0), getattr(world_index, "region_files_invalid", 0),
            getattr(world_index, "present_chunk_count", 0),
        )
        self.geology_analysis_panel.set_context(
            world_loaded=True,
            world_name=self.state.world_name,
            worldpainter_available=self._worldpainter_import is not None,
            worldpainter_name=(
                self.state.worldpainter_project_name
                if self._worldpainter_import is not None else ""
            ),
        )
        # Upfront selected-area warmup: read the intersecting region files first (with progress bar),
        # then start the 3D streaming renderer. This keeps mesh detail unchanged while improving the
        # first-time experience on cold caches.
        try:
            self._preload_selected_area_regions(world_index, project_area_bounds)
        except Exception:
            log.exception("Selected-area warmup failed")

        # Pause viewport streaming/redraw during startup decode/mesh preload so CPU is spent on loading,
        # not incremental rendering. The 3D view resumes once the selected area is prepared.
        try:
            self.renderer_mgr.set_loading_paused(True)
        except Exception:
            pass
        try:
            self.renderer_mgr.set_world_index(world_index)
            self._apply_project_area_selection(project_area_bounds, full_world=project_area_full, recenter=True)
            try:
                self._preload_selected_area_meshes(project_area_bounds)
            except Exception:
                log.exception("Selected-area chunk preload failed")
        finally:
            try:
                self.renderer_mgr.set_loading_paused(False)
            except Exception:
                pass

        self._reset_editing_session_for_new_world()
        if loaded_from_project:
            try:
                self._restore_project_payload(pending)
            except Exception:
                log.exception("Failed to restore project payload after world load")
        if self._perf_dlg is not None:
            self._perf_dlg.refresh_from_renderer()
        if loaded_from_project:
            self.statusBar().showMessage(f"Project loaded: {self.state.project_path or '(unsaved)'}")

    @QtCore.Slot(str)
    def _on_index_failed(self, err: str) -> None:
        self._pending_project_payload = None
        self.statusBar().showMessage("Failed to open world")
        self._sb_world.setText("World: open failed")
        self._sync_workspace_header()
        QtWidgets.QMessageBox.critical(self, "World open failed", err)
        log.exception("World open failed: %s", err)

    @QtCore.Slot()
    def show_performance(self) -> None:
        if self._perf_dlg is None:
            self._perf_dlg = PerformanceDialog(self, self.renderer_mgr)
        self._perf_dlg.show()
        self._perf_dlg.raise_()
        self._perf_dlg.activateWindow()
        self._perf_dlg.refresh_from_renderer()

    @QtCore.Slot()
    def show_apply(self) -> None:
        summary = self._build_apply_summary()
        dlg = ApplyDialog(self, summary)
        if dlg.exec() != QtWidgets.QDialog.DialogCode.Accepted:
            return
        self._run_incremental_export(
            dlg.destination_mode(),
            dlg.export_seed(),
            region_workers=dlg.region_workers(),
            copy_workers=dlg.world_copy_workers(),
        )

    def _run_incremental_export(
        self,
        destination_mode: str,
        seed: int = 1337,
        *,
        region_workers: int = 0,
        copy_workers: int = 0,
    ) -> None:
        if self._export_thread is not None:
            QtWidgets.QMessageBox.information(self, "Export map", "An export is already running.")
            return
        if self.state.world_path is None:
            QtWidgets.QMessageBox.warning(self, "Export map", "Open a world before exporting changes.")
            return
        paint_layers = self._ordered_paint_preview_layers()
        stroke_count = sum(len(list(layer.get("strokes") or [])) for layer in paint_layers)
        if not stroke_count:
            QtWidgets.QMessageBox.information(self, "Export map", "There are no visible/enabled paint strokes to export.")
            return
        mode = str(destination_mode or "copy").strip().lower()
        if mode == "inplace":
            ret = QtWidgets.QMessageBox.warning(
                self,
                "Apply directly to opened world?",
                "This modifies the currently opened Minecraft world. Close Minecraft and make a backup first. Continue?",
                QtWidgets.QMessageBox.StandardButton.Yes | QtWidgets.QMessageBox.StandardButton.No,
                QtWidgets.QMessageBox.StandardButton.No,
            )
            if ret != QtWidgets.QMessageBox.StandardButton.Yes:
                return

        opts = IncrementalExportOptions(
            world_path=Path(self.state.world_path),
            paint_layers=paint_layers,
            destination_mode=mode,
            seed=int(seed),
            height_range=self.state.height_range,
            edit_area_chunk_bounds=self.state.edit_area_chunk_bounds,
            verify_after_write=True,
            workers=int(region_workers),
            copy_workers=int(copy_workers),
        )

        progress = QtWidgets.QProgressDialog("Preparing export…", None, 0, 100, self)
        progress.setWindowTitle("WorldGeoLabs Export")
        progress.setWindowModality(QtCore.Qt.WindowModality.ApplicationModal)
        progress.setMinimumDuration(0)
        progress.setCancelButton(None)
        progress.setAutoClose(False)
        progress.setAutoReset(False)
        progress.setValue(0)
        progress.setMinimumWidth(720)
        progress.show()
        self._export_progress = progress
        self._export_last_logged_progress = -10

        thread = QtCore.QThread(self)
        worker = IncrementalExportWorker(opts)
        worker.moveToThread(thread)
        thread.started.connect(worker.run)
        worker.stage.connect(self._on_export_stage)
        worker.progress.connect(self._on_export_progress)
        worker.finished.connect(self._on_incremental_export_finished)
        worker.failed.connect(self._on_incremental_export_failed)
        worker.finished.connect(thread.quit)
        worker.failed.connect(thread.quit)
        thread.finished.connect(self._cleanup_incremental_export_worker)
        self._export_thread = thread
        self._export_worker = worker
        self.statusBar().showMessage("Export running in background…")
        thread.start()

    @QtCore.Slot(str)
    def _on_export_stage(self, message: str) -> None:
        self.statusBar().showMessage(str(message))
        if self._export_progress is not None:
            self._export_progress.setLabelText(str(message))

    @QtCore.Slot(int, str)
    def _on_export_progress(self, percent: int, message: str) -> None:
        pct = max(0, min(100, int(percent)))
        text = str(message)
        self.statusBar().showMessage(f"Export {pct}% — {text}")
        if self._export_progress is not None:
            self._export_progress.setLabelText(text)
            self._export_progress.setValue(pct)
        if pct >= int(self._export_last_logged_progress) + 5 or pct >= 100:
            log.info("Export progress %d%%: %s", pct, text)
            self._export_last_logged_progress = pct

    @QtCore.Slot(object)
    def _on_incremental_export_finished(self, report: object) -> None:
        log.info("Incremental export complete: %s", report.summary_text().replace("\n", " | "))
        self.statusBar().showMessage(
            f"Export complete: {report.changed_blocks} block(s), {report.changed_chunks} chunk(s), {report.changed_regions} region file(s)"
        )
        QtWidgets.QMessageBox.information(self, "Export complete", report.summary_text())

    @QtCore.Slot(str)
    def _on_incremental_export_failed(self, message: str) -> None:
        log.error("Incremental export failed: %s", message)
        self.statusBar().showMessage("Export failed")
        QtWidgets.QMessageBox.critical(self, "Export failed", str(message))

    @QtCore.Slot()
    def _cleanup_incremental_export_worker(self) -> None:
        if self._export_progress is not None:
            self._export_progress.close()
            self._export_progress.deleteLater()
        if self._export_worker is not None:
            self._export_worker.deleteLater()
        if self._export_thread is not None:
            self._export_thread.deleteLater()
        self._export_progress = None
        self._export_worker = None
        self._export_thread = None

    @QtCore.Slot(str)
    def _on_view_mode(self, mode: str) -> None:
        self.state.view_mode = mode
        self._sb_view.setText("View: Surface")
        self._sync_workspace_header()
        self.renderer_mgr.set_view_mode(mode)
        self.renderer_mgr.set_view_settings(self.params_panel.view_settings())

    @QtCore.Slot(object)
    def _on_materials_changed(self, names) -> None:
        try:
            self.blocks_panel.set_blocks(list(names))
        except Exception:
            log.exception("Failed to update blocks list")

    @QtCore.Slot()
    def _on_blocks_visibility(self) -> None:
        vis = self.blocks_panel.visibility_map()
        self.renderer_mgr.set_material_visibility(vis)

    @QtCore.Slot(dict)
    def _on_preview_settings_changed(self, settings: dict) -> None:
        self._sync_preview_ui_state()
        settings2 = self._push_preview_settings_to_renderer(settings)
        if settings2.get("enabled"):
            order = settings2.get("preview_layer_order") or []
            if order:
                pretty = " → ".join("Caves" if x == "gen:caves" else "Ores" if x == "gen:ores" else str(x) for x in order)
                self.statusBar().showMessage(f"Updated non-destructive generator preview (eval order: {pretty})")
            else:
                self.statusBar().showMessage("Updated non-destructive generator preview")
        else:
            self.statusBar().showMessage("Generator previews are off (inspect mode)")

    @QtCore.Slot(dict)
    def _on_view_settings_changed(self, settings: dict) -> None:
        self.renderer_mgr.set_view_settings(settings)
        self.statusBar().showMessage("Updated cutaway / inspection settings")


    @QtCore.Slot(str)
    def _on_viewport_block_picked(self, block: str) -> None:
        block = str(block or "").strip()
        if not block:
            return
        try:
            self.paint_panel.select_block(block)
            self._focus_paint_tab()
            self.statusBar().showMessage(f"Picked block for Paint: {block}")
        except Exception:
            log.exception("Failed to apply picked block")

    @QtCore.Slot(dict)
    def _on_paint_settings_changed(self, settings: dict) -> None:
        self.state.paint_mode_enabled = bool(settings.get("enabled"))
        self.state.active_paint_layer = str(settings.get("active_layer") or "Paint Layer")
        layer = self._paint_layer_data(self.state.active_paint_layer)
        layer["settings"] = dict(settings or {})
        layer["name"] = self.state.active_paint_layer
        self.renderer_mgr.set_paint_settings(settings)
        self._sb_tool.setText("Tool: Paint" if self.state.paint_mode_enabled else "Tool: Navigate")
        self._sync_workspace_header()
        if hasattr(self, "act_paint"):
            self.act_paint.blockSignals(True)
            self.act_paint.setChecked(self.state.paint_mode_enabled)
            self.act_paint.blockSignals(False)
        if self.state.paint_mode_enabled:
            self.layers_panel.upsert_paint_layer(self.state.active_paint_layer, self._paint_layer_strokes.get(self.state.active_paint_layer, 0), select=False)
        self.statusBar().showMessage(
            f"Paint {'enabled' if self.state.paint_mode_enabled else 'disabled'} | "
            f"{settings.get('action','Brush')} | size {settings.get('size_blocks','?')}"
        )

    @QtCore.Slot(bool)
    def _on_toolbar_paint_toggled(self, checked: bool) -> None:
        if hasattr(self, "inspector_tabs"):
            idx = self.inspector_tabs.indexOf(self.paint_panel)
            if idx >= 0:
                self.inspector_tabs.setCurrentIndex(idx)
                self._set_layer_editor_context("Paint Layer", "3D paint settings for the active paint layer.")
        self.paint_panel.paint_enabled.setChecked(bool(checked))

    @QtCore.Slot()
    def _focus_paint_tab(self) -> None:
        if hasattr(self, "inspector_tabs"):
            idx = self.inspector_tabs.indexOf(self.paint_panel)
            if idx >= 0:
                self.inspector_tabs.setCurrentIndex(idx)
                self._set_layer_editor_context("Paint Layer", "3D paint settings for the active paint layer.")
        self.paint_panel.paint_enabled.setChecked(True)

    @QtCore.Slot()
    def _focus_scene_tools(self) -> None:
        if hasattr(self, "inspector_tabs"):
            self.inspector_tabs.setCurrentWidget(self.params_panel)
        self._set_layer_editor_context(
            "Scene / View Tools",
            "Cutaway, ghost terrain, and generator preview controls for inspecting the selected volume."
        )
        self.statusBar().showMessage("Focused Scene / View tools")

    @QtCore.Slot(bool)
    def _on_lod_edit_toggled(self, checked: bool) -> None:
        if not checked:
            return
        try:
            self.renderer_mgr.set_edit_mode("lod", move_to_camera=False)
            self.statusBar().showMessage("LOD Edit mode: whole-world coarse editing; real voxel streaming paused", 8000)
        except Exception:
            log.exception("Failed enabling LOD Edit mode")

    @QtCore.Slot(bool)
    def _on_detailed_edit_toggled(self, checked: bool) -> None:
        if not checked:
            return
        try:
            self.renderer_mgr.set_edit_mode("detailed", move_to_camera=True)
            self.statusBar().showMessage("Detailed Edit mode: movable 3D block box loaded at camera target", 8000)
        except Exception:
            log.exception("Failed enabling Detailed Edit mode")

    @QtCore.Slot()
    def _move_working_area_to_camera(self) -> None:
        """Explicitly load the detailed editable chunk bubble at the camera target."""
        try:
            moved = self.viewport.move_working_area_to_camera()
        except Exception:
            log.exception("Move Working Area failed")
            moved = None
        if moved is None:
            self.statusBar().showMessage("Working area unavailable until a Minecraft world is loaded")
            return
        cx, cz = moved
        self.statusBar().showMessage(
            f"Detailed 3D box moved to chunk {cx}, {cz} and camera Y. Loading only sections inside the box…",
            8000,
        )
        try:
            self._refresh_workspace_status()
        except Exception:
            pass

    @QtCore.Slot(str)
    def _on_add_paint_layer(self, name: str) -> None:
        name = (name or "Paint Layer").strip()
        self._paint_layer_data(name)
        self.paint_panel.select_or_create_layer(name, select_only=True)
        self.layers_panel.upsert_paint_layer(name, self._paint_layer_strokes.get(name, 0), select=True)
        self.state.active_paint_layer = name
        self._push_preview_settings_to_renderer()
        self.statusBar().showMessage(f"Added/selected paint layer: {name}")

    @QtCore.Slot()
    def _on_import_model_requested(self) -> None:
        QtWidgets.QMessageBox.information(
            self,
            "3D model stamps (next milestone)",
            "Planned pipeline:\n"
            "1) Import OBJ/GLB\n"
            "2) Voxelize to stamp volume\n"
            "3) Align/rotate/scale in viewport\n"
            "4) Apply as non-destructive layer"
        )

    @QtCore.Slot(dict)
    def _on_paint_hover_changed(self, info: dict) -> None:
        try:
            self.paint_panel.set_hover_info(info)
        except Exception:
            pass

    def _active_paint_layer_name(self) -> str:
        """Return the selected paint layer name without crossing layer boundaries."""
        try:
            meta = self.layers_panel.current_layer_meta()
            if isinstance(meta, dict) and str(meta.get("kind", "")).lower() == "paint":
                name = str(meta.get("name") or meta.get("label") or "").strip()
                if name:
                    return name
        except Exception:
            pass
        name = str(getattr(self.state, "active_paint_layer", "") or "").strip()
        return name or "Paint Layer"

    def _stroke_dirty_bbox_and_padding(self, stroke: dict) -> tuple[tuple[int, int, int, int, int, int] | None, int]:
        """Return the block-space bbox/padding needed to locally remesh one stroke."""
        try:
            size = max(1, int(stroke.get("size_blocks", 1)))
        except Exception:
            size = 1
        pad = max(1, size)
        bbox = stroke.get("bbox")
        if isinstance(bbox, (list, tuple)) and len(bbox) == 6:
            try:
                x0, y0, z0, x1, y1, z1 = [int(float(v)) for v in bbox]
                return (min(x0, x1), min(y0, y1), min(z0, z1), max(x0, x1), max(y0, y1), max(z0, z1)), pad
            except Exception:
                pass
        pts = stroke.get("points") or []
        xs: list[int] = []
        ys: list[int] = []
        zs: list[int] = []
        for p in pts:
            if not isinstance(p, (list, tuple)) or len(p) < 3:
                continue
            try:
                xs.append(int(float(p[0])))
                ys.append(int(float(p[1])))
                zs.append(int(float(p[2])))
            except Exception:
                continue
        if not xs:
            return None, pad
        return (min(xs), min(ys), min(zs), max(xs), max(ys), max(zs)), pad

    def _push_paint_layer_dirty_refresh(self, stroke: dict | None = None) -> tuple[int, int]:
        """Refresh preview meshes for a changed paint layer, preferably locally."""
        dirty_bbox = None
        pad = 0
        dirty_sections = 0
        dirty_columns = 0
        if stroke is not None:
            dirty_bbox, pad = self._stroke_dirty_bbox_and_padding(stroke)
            if dirty_bbox is not None:
                try:
                    section_keys = sections_for_block_box(dirty_bbox, padding_blocks=pad, include_neighbors=True)
                    dirty_sections = len(section_keys)
                    dirty_columns = len(chunk_columns_for_sections(section_keys))
                except Exception:
                    log.exception("Failed dirty-region section calculation for undo/redo")
                    dirty_bbox = None
        settings = self._preview_settings_for_renderer()
        if dirty_bbox is not None:
            self.renderer_mgr.set_preview_settings(settings, dirty_bbox=dirty_bbox, padding_blocks=pad)
        else:
            self.renderer_mgr.set_preview_settings(settings)
        return dirty_sections, dirty_columns

    def _refresh_paint_layer_row(self, layer: str, *, select: bool = True) -> int:
        layer_data = self._paint_layer_data(layer)
        count = len(list(layer_data.get("strokes") or []))
        self._paint_layer_strokes[layer] = count
        try:
            self.layers_panel.upsert_paint_layer(layer, count, select=select)
        except Exception:
            pass
        return count

    def _update_undo_redo_actions(self) -> None:
        layer = self._active_paint_layer_name()
        # Do not create a layer just to update action state.  Empty/new sessions
        # should keep Undo/Redo disabled until an actual paint layer receives work.
        layer_data = self._paint_layers.get(layer, {}) if layer else {}
        strokes = list(layer_data.get("strokes") or []) if isinstance(layer_data, dict) else []
        redo = list(self._paint_layer_redo.get(layer, [])) if layer else []
        if hasattr(self, "act_undo"):
            self.act_undo.setEnabled(bool(strokes))
            self.act_undo.setText("Undo")
            self.act_undo.setStatusTip(f"Undo the last stroke on selected paint layer: {layer}" if strokes else "Undo is available after painting on the selected layer")
        if hasattr(self, "act_redo"):
            self.act_redo.setEnabled(bool(redo))
            self.act_redo.setText("Redo")
            self.act_redo.setStatusTip(f"Redo the last undone stroke on selected paint layer: {layer}" if redo else "Redo is available after undoing a stroke on the selected layer")

    @QtCore.Slot()
    def _undo_active_paint_layer(self) -> None:
        layer = self._active_paint_layer_name()
        layer_data = self._paint_layer_data(layer)
        strokes = layer_data.setdefault("strokes", [])
        if not strokes:
            self.statusBar().showMessage(f"Nothing to undo on paint layer '{layer}'")
            self._update_undo_redo_actions()
            return
        stroke = deepcopy(strokes.pop())
        self._paint_layer_redo.setdefault(layer, []).append(stroke)
        count = self._refresh_paint_layer_row(layer, select=True)
        dirty_sections, dirty_columns = self._push_paint_layer_dirty_refresh(stroke)
        self._update_undo_redo_actions()
        if dirty_sections:
            self.statusBar().showMessage(
                f"Undo paint stroke on '{layer}' | {count} stroke(s) left | local remesh: {dirty_sections} section(s), {dirty_columns} column(s)"
            )
        else:
            self.statusBar().showMessage(f"Undo paint stroke on '{layer}' | {count} stroke(s) left")
        log.info("Undo paint stroke: layer=%s remaining=%d dirty_sections=%s dirty_columns=%s", layer, count, dirty_sections, dirty_columns)

    @QtCore.Slot()
    def _redo_active_paint_layer(self) -> None:
        layer = self._active_paint_layer_name()
        redo = self._paint_layer_redo.setdefault(layer, [])
        if not redo:
            self.statusBar().showMessage(f"Nothing to redo on paint layer '{layer}'")
            self._update_undo_redo_actions()
            return
        stroke = deepcopy(redo.pop())
        layer_data = self._paint_layer_data(layer)
        layer_data.setdefault("strokes", []).append(stroke)
        count = self._refresh_paint_layer_row(layer, select=True)
        dirty_sections, dirty_columns = self._push_paint_layer_dirty_refresh(stroke)
        self._update_undo_redo_actions()
        if dirty_sections:
            self.statusBar().showMessage(
                f"Redo paint stroke on '{layer}' | {count} stroke(s) | local remesh: {dirty_sections} section(s), {dirty_columns} column(s)"
            )
        else:
            self.statusBar().showMessage(f"Redo paint stroke on '{layer}' | {count} stroke(s)")
        log.info("Redo paint stroke: layer=%s count=%d dirty_sections=%s dirty_columns=%s", layer, count, dirty_sections, dirty_columns)

    @QtCore.Slot(dict)
    def _on_paint_stroke_committed(self, info: dict) -> None:
        layer = str(info.get("active_layer") or self.state.active_paint_layer or "Paint Layer")
        layer_data = self._paint_layer_data(layer)
        self._paint_layer_strokes[layer] = self._paint_layer_strokes.get(layer, 0) + 1
        self.layers_panel.upsert_paint_layer(layer, self._paint_layer_strokes[layer], select=True)
        try:
            self.paint_panel.set_stroke_info(info)
        except Exception:
            pass
        n = int(info.get("point_count", 0))

        stroke_payload = {
            "action": str(info.get("action", "Replace blocks")),
            "material": str(info.get("material", "minecraft:stone")),
            "shape": str(info.get("shape", "Sphere")),
            "size_blocks": int(info.get("size_blocks", 1)),
            "strength_pct": int(info.get("strength_pct", 100)),
            "axis_lock": str(info.get("axis_lock", layer_data.get("settings", {}).get("axis_lock", "None"))),
            "mirror": str(info.get("mirror", layer_data.get("settings", {}).get("mirror", "None"))),
            "host_only": bool(info.get("host_only", layer_data.get("settings", {}).get("host_only", False))),
            "protect_surface": bool(info.get("protect_surface", layer_data.get("settings", {}).get("protect_surface", False))),
            "surface_margin": int(info.get("surface_margin", layer_data.get("settings", {}).get("surface_margin", 6))),
            "points": [[float(p[0]), float(p[1]), float(p[2])] for p in (info.get("points") or [])[:4096] if isinstance(p, (list, tuple)) and len(p) >= 3],
            "bbox": list(info.get("bbox") or []),
        }
        layer_data.setdefault("strokes", []).append(stroke_payload)
        # New work on a layer invalidates redo history only for that layer.
        self._paint_layer_redo[layer] = []
        self._update_undo_redo_actions()

        # Dirty-region preview remesh: push the new preview settings and the dirty
        # block box in the same call.  Older builds pushed settings first, which
        # changed the global preview signature and invalidated every voxel mesh
        # before the local bbox invalidation had a chance to help.
        dirty_columns = 0
        dirty_sections = 0
        dirty_bbox = None
        pad = 0
        bbox = info.get("bbox")
        if isinstance(bbox, (list, tuple)) and len(bbox) == 6:
            try:
                brush_size = int(info.get("size_blocks", self.paint_panel.settings().get("size_blocks", 1)))
            except Exception:
                brush_size = 1
            pad = max(1, brush_size)
            try:
                x0, y0, z0, x1, y1, z1 = [int(v) for v in bbox]
                dirty_bbox = (x0, y0, z0, x1, y1, z1)
                section_keys = sections_for_block_box(dirty_bbox, padding_blocks=pad, include_neighbors=True)
                dirty_sections = len(section_keys)
                dirty_columns = len(chunk_columns_for_sections(section_keys))
            except Exception:
                log.exception("Failed dirty-region section calculation for paint stroke")
                dirty_bbox = None

        settings = self._preview_settings_for_renderer()
        if dirty_bbox is not None:
            self.renderer_mgr.set_preview_settings(settings, dirty_bbox=dirty_bbox, padding_blocks=pad)
        else:
            self.renderer_mgr.set_preview_settings(settings)

        log.info(
            "Paint stroke recorded: layer=%s points=%d action=%s dirty_sections=%s dirty_columns=%s",
            layer, n, info.get("action"), dirty_sections or 0, dirty_columns or 0
        )
        if dirty_sections > 0:
            self.statusBar().showMessage(
                f"Recorded paint preview stroke on '{layer}' ({n} samples) | local remesh: {dirty_sections} section(s), {dirty_columns} column(s)"
            )
        else:
            self.statusBar().showMessage(f"Recorded paint preview stroke on '{layer}' ({n} samples)")


    @QtCore.Slot(object)
    def _on_layer_selected(self, meta: object) -> None:
        try:
            m = dict(meta or {})
        except Exception:
            m = {}
        self._sync_layer_header_from_layers_selection()
        kind = str(m.get("kind", "")).lower()
        key = str(m.get("key", ""))
        if not m:
            self._focus_inspect_tab()
            return
        if kind == "paint":
            name = str(m.get("name") or m.get("label") or "Paint Layer")
            self._focus_paint_tab()
            try:
                self._paint_layer_data(name)
                self.paint_panel.select_or_create_layer(name, select_only=True)
            except Exception:
                pass
            self.state.active_paint_layer = name
            self._set_layer_editor_context(f"Edit Paint Layer: {name}", "Use Paint to add/remove/recolor preview strokes on this layer.")
            self.statusBar().showMessage(f"Selected paint layer: {name}")
            self._update_undo_redo_actions()
            return
        if kind == "generator":
            self._focus_generate_tab()
            gk = str(m.get("generator_kind", "")).lower()
            self._set_layer_editor_context(
                f"Edit { (gk or 'generator').title() } Preview",
                "Non-destructive preview settings. Disable or delete the layer to remove the preview."
            )
            self.statusBar().showMessage(f"Selected {gk or 'generator'} preview layer")
            return
        if kind == "analysis":
            self.show_geological_analysis()
            dataset = str(m.get("dataset") or "surface_height")
            manifest_raw = str(m.get("manifest_path") or "").strip()
            manifest_path = Path(manifest_raw) if manifest_raw else self.state.geological_analysis_manifest
            if manifest_path is not None:
                self.geology_analysis_panel.focus_dataset(dataset, Path(manifest_path))
            self._set_layer_editor_context(
                str(m.get("label") or "Geological Analysis"),
                "Read-only cached analysis layer. Regenerate from the Geological Analysis tab to change its resolution or source.",
            )
            self.statusBar().showMessage(f"Selected analysis layer: {dataset}")
            return
        if kind == "editcore":
            if self._dev_tools_visible and hasattr(self, "inspector_tabs") and self._edit_core_tab_index >= 0:
                self.inspector_tabs.setCurrentIndex(self._edit_core_tab_index)
                self._set_layer_editor_context("Advanced Layer (Dev)", "Internal editing-core controls for backend testing.")
            self.statusBar().showMessage("Selected advanced box-replace layer (developer tool)")
            return

    @QtCore.Slot(object)
    def _on_layer_edit_requested(self, meta: object) -> None:
        self._on_layer_selected(meta)

    @QtCore.Slot(object)
    def _on_layer_remove_requested(self, meta: object) -> None:
        try:
            m = dict(meta or {})
        except Exception:
            m = {}
        kind = str(m.get("kind", "")).lower()
        if kind == "generator":
            gk = str(m.get("generator_kind", "")).lower()
            if gk == "caves":
                self.params_panel.caves_enabled.setChecked(False)
                self.params_panel.emit_preview_settings()
            elif gk == "ores":
                self.params_panel.ores_enabled.setChecked(False)
                self.params_panel.emit_preview_settings()
            self._sync_preview_ui_state()
            self.statusBar().showMessage(f"Removed {gk or 'generator'} preview layer")
            return
        if kind == "paint":
            name = str(m.get("name") or "")
            self._paint_layer_strokes.pop(name, None)
            self._paint_layers.pop(name, None)
            self._paint_layer_redo.pop(name, None)
            self._push_preview_settings_to_renderer()
            self._update_undo_redo_actions()
            self.statusBar().showMessage(f"Removed paint layer '{name}'")
            return
        if kind == "editcore":
            self.statusBar().showMessage("Removed advanced box-replace layer entry")
            return

    @QtCore.Slot(object)
    def _on_layer_duplicate_requested(self, meta: object) -> None:
        try:
            m = dict(meta or {})
        except Exception:
            m = {}
        kind = str(m.get("kind", "")).lower()
        if kind == "paint":
            base = str(m.get("name") or "Paint Layer").strip() or "Paint Layer"
            copy_name = base + " Copy"
            n = 2
            while copy_name in self._paint_layer_strokes:
                copy_name = f"{base} Copy {n}"
                n += 1
            self._paint_layer_strokes[copy_name] = 0
            src_layer = self._paint_layer_data(base)
            copied = {"name": copy_name, "enabled": True, "preview_visible": True, "settings": dict(src_layer.get("settings") or {}), "strokes": [dict(s) for s in (src_layer.get("strokes") or [])]}
            self._paint_layers[copy_name] = copied
            self._paint_layer_strokes[copy_name] = len(copied.get("strokes") or [])
            self._paint_layer_redo[copy_name] = []
            self.paint_panel.select_or_create_layer(copy_name, select_only=True)
            self.layers_panel.upsert_paint_layer(copy_name, self._paint_layer_strokes.get(copy_name, 0), select=True)
            self._push_preview_settings_to_renderer()
            self._update_undo_redo_actions()
            self.statusBar().showMessage(f"Duplicated paint layer as '{copy_name}'")
            return
        if kind == "generator":
            self.statusBar().showMessage("Generator previews are singleton layers right now (duplicate not needed)")
            return
        if kind == "editcore":
            self.statusBar().showMessage("Advanced box replace duplication is not implemented yet")
            return

    @QtCore.Slot(object, str)
    def _on_layer_renamed(self, meta: object, new_label: str) -> None:
        try:
            m = dict(meta or {})
        except Exception:
            m = {}
        kind = str(m.get("kind", "")).lower()
        if kind == "paint":
            old_name = str(m.get("name") or "").strip()
            # Expect labels like "Paint • Name  (N strokes)" -> derive display name back out.
            name = str(new_label or "").strip()
            if name.lower().startswith("paint •"):
                name = name.split("•", 1)[1].strip()
            if "  (" in name:
                name = name.split("  (", 1)[0].rstrip()
            name = name or "Paint Layer"
            if old_name and old_name != name:
                self._paint_layer_strokes[name] = self._paint_layer_strokes.pop(old_name, 0)
                self._paint_layer_redo[name] = self._paint_layer_redo.pop(old_name, [])
                layer_data = self._paint_layers.pop(old_name, None)
                if layer_data is not None:
                    layer_data["name"] = name
                    self._paint_layers[name] = layer_data
                try:
                    self.paint_panel.rename_layer_entry(old_name, name)
                except Exception:
                    pass
                self.state.active_paint_layer = name
                # normalize layer row label back to styled label
                self.layers_panel.upsert_paint_layer(name, self._paint_layer_strokes.get(name, 0), select=True)
                self._push_preview_settings_to_renderer()
                self._update_undo_redo_actions()
                self.statusBar().showMessage(f"Renamed paint layer to '{name}'")
            return
        if kind == "generator":
            # Preserve canonical labels to avoid confusion; revert on next sync.
            self._sync_preview_ui_state()
            self.statusBar().showMessage("Generator layer names are fixed in this milestone")
            return

    @QtCore.Slot(object, bool)
    def _on_layer_visibility_changed(self, meta: object, visible: bool) -> None:
        try:
            m = dict(meta or {})
        except Exception:
            m = {}
        kind = str(m.get("kind", "")).lower()
        if kind == "generator":
            gk = str(m.get("generator_kind", "")).lower()
            if gk == "caves" and bool(self.params_panel.caves_enabled.isChecked()) != bool(visible):
                self.params_panel.caves_enabled.setChecked(bool(visible))
                self.params_panel.emit_preview_settings()
            elif gk == "ores" and bool(self.params_panel.ores_enabled.isChecked()) != bool(visible):
                self.params_panel.ores_enabled.setChecked(bool(visible))
                self.params_panel.emit_preview_settings()
            self._sync_preview_ui_state()
            settings = self._push_preview_settings_to_renderer(self.params_panel.preview_settings())
            order = settings.get("preview_layer_order") or []
            suffix = ""
            if order:
                pretty = " → ".join("Caves" if x == "gen:caves" else "Ores" if x == "gen:ores" else str(x) for x in order)
                suffix = f" | eval order: {pretty}"
            self.statusBar().showMessage(f"{'Enabled' if visible else 'Hid'} {gk or 'generator'} preview layer{suffix}")
            return
        if kind == "paint":
            name = str(m.get("name") or "Paint Layer")
            layer = self._paint_layer_data(name)
            layer["enabled"] = bool(visible)
            layer["preview_visible"] = bool(visible)
            self._push_preview_settings_to_renderer()
            self.statusBar().showMessage(
                f"{'Showing' if visible else 'Hiding'} paint layer '{name}' preview"
            )
            return
        if kind == "editcore":
            self.statusBar().showMessage(
                f"{'Enabled' if visible else 'Disabled'} advanced box-replace layer entry"
            )

    @QtCore.Slot()
    def _on_layer_reordered(self) -> None:
        # Wire visible generator order into renderer preview evaluation (caves/ores for now).
        settings = self._push_preview_settings_to_renderer(self.params_panel.preview_settings())
        order = settings.get("preview_layer_order") or []
        if order:
            pretty = " → ".join("Caves" if x == "gen:caves" else "Ores" if x == "gen:ores" else str(x) for x in order)
            self.statusBar().showMessage(f"Layer order updated (preview eval order: {pretty})")
        else:
            self.statusBar().showMessage("Layer order updated")
        self._push_preview_settings_to_renderer()

    @QtCore.Slot(dict)
    def _on_edit_core_box_params_changed(self, params: dict) -> None:
        self._edit_core_box_params = dict(params or {})

    @QtCore.Slot()
    def _on_edit_core_add_box_layer(self) -> None:
        params = self.edit_core_panel.params()
        layer = self.edit_core.add_or_replace_box_layer(params)
        self.layers_panel.ensure_named_layer(
            f"Box Replace • {layer.name}",
            checked=layer.enabled,
            top=True,
            meta={"kind": "editcore", "key": "editcore:box_replace", "name": layer.name},
            select=True,
        )
        self.edit_core_panel.append_stats(
            f"Layer loaded: {layer.name} | mode={layer.combine_mode} | "
            f"box=({layer.min_x},{layer.min_y},{layer.min_z})..({layer.max_x},{layer.max_y},{layer.max_z})"
        )
        self.statusBar().showMessage(f"Editing Core: configured '{layer.name}'")

    def _make_edit_eval_chunks(self) -> list:
        # Prefer a real decoded chunk near spawn if available; otherwise use demo adapter.
        h = self.state.height_range or (-64, 320)
        min_y, max_y = int(h[0]), int(h[1])
        spawn = self.state.spawn_chunk or (0, 0)
        cx, cz = int(spawn[0]), int(spawn[1])

        if self._anvil_world is not None:
            try:
                model = self._anvil_world.read_chunk(cx, cz)
                if model is not None:
                    class _ChunkModelAdapter:
                        def __init__(self, m, min_y_, max_y_):
                            self._m = m
                            self.chunk_x = int(m.cx)
                            self.chunk_z = int(m.cz)
                            self.min_y = int(min_y_)
                            self.max_y = int(max_y_)

                        def get_block(self, x: int, y: int, z: int) -> str:
                            return self._m.get_block(x, y, z)

                    return [_ChunkModelAdapter(model, min_y, max_y)]
            except Exception:
                log.exception("Editing Core: failed to decode real chunk for preview; using demo chunk")
        return [DemoChunkAdapter(cx, cz, min_y=min_y, max_y=max_y)]

    def _run_edit_core_eval(self, apply_demo: bool = False) -> None:
        params = self.edit_core_panel.params()
        layer = self.edit_core.add_or_replace_box_layer(params)
        chunks = self._make_edit_eval_chunks()
        deltas, stats = self.edit_core.preview_chunks(chunks)
        dirty = sorted(self.edit_core.consume_dirty_chunks())
        mode_label = "Apply (demo)" if apply_demo else "Preview"
        source_label = "real chunk" if chunks and chunks[0].__class__.__name__ != "DemoChunkAdapter" else "demo chunk"

        lines = [
            f"{mode_label}: layer={layer.name}",
            f"Source: {source_label} @ chunk ({chunks[0].chunk_x}, {chunks[0].chunk_z})",
            f"Changed chunks: {stats.get('changed_chunks', 0)}",
            f"Changed blocks: {stats.get('changed_blocks', 0)}",
            f"Evaluated layers: {stats.get('evaluated_layers', 0)}",
            f"Stack version: {stats.get('stack_version', '?')}",
            f"Dirty chunks (for future remesh injection): {dirty[:8]}{' ...' if len(dirty) > 8 else ''}",
        ]
        if deltas:
            d0 = deltas[0]
            lines.append(f"First delta chunk: ({d0.chunk_x}, {d0.chunk_z}) with {d0.changed_block_count} changes")
        else:
            lines.append("No changes produced (check box bounds/selector/target chunk).")
        self.edit_core_panel.set_stats("\n".join(lines))

        log.info(
            "Editing Core %s evaluated: changed_chunks=%s changed_blocks=%s dirty=%s source=%s",
            "apply-demo" if apply_demo else "preview",
            stats.get("changed_chunks"),
            stats.get("changed_blocks"),
            dirty,
            source_label,
        )
        if apply_demo:
            self.statusBar().showMessage(
                "Editing Core Apply (demo): same evaluator path executed (no world writes yet)"
            )
        else:
            self.statusBar().showMessage(
                "Editing Core Preview evaluated (stats only; mesh injection to renderer is next milestone)"
            )

    @QtCore.Slot()
    def _on_edit_core_preview(self) -> None:
        self._run_edit_core_eval(apply_demo=False)

    @QtCore.Slot()
    def _on_edit_core_apply_demo(self) -> None:
        self._run_edit_core_eval(apply_demo=True)

    @QtCore.Slot()
    def _refresh_status_snapshot(self) -> None:
        try:
            snap = self.renderer_mgr.get_performance_snapshot() or {}
        except Exception:
            return
        fps = snap.get("fps")
        resident = snap.get("resident_chunks")
        inflight = snap.get("inflight")
        if fps is None and resident is None:
            return
        fps_txt = "--" if fps is None else str(fps)
        res_txt = "--" if resident is None else str(resident)
        inflight_txt = "" if inflight is None else f" | Inflight: {inflight}"
        self._sb_perf.setText(f"FPS: {fps_txt} | Resident: {res_txt}{inflight_txt}")
        self._sync_workspace_header()
