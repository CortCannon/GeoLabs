from __future__ import annotations

from PySide6 import QtCore, QtWidgets


class WorkspaceShell(QtWidgets.QWidget):
    """Central viewport workspace with a small, task-oriented header.

    MainWindow owns application state and orchestration. This widget owns only the
    visual shell around the viewport: workflow buttons, status chips, and the
    card that contains the OpenGL viewport. Keeping this separate prevents the
    main window from becoming the only place where every layout decision lives.
    """

    open_world_requested = QtCore.Signal()
    project_area_requested = QtCore.Signal()
    create_feature_requested = QtCore.Signal()
    focus_paint_requested = QtCore.Signal()

    def __init__(self, viewport: QtWidgets.QWidget, parent: QtWidgets.QWidget | None = None) -> None:
        super().__init__(parent)
        self.setObjectName("WorkspaceRoot")
        self._viewport = viewport
        self._build_ui()

    def _build_ui(self) -> None:
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)
        layout.setSpacing(10)

        header = QtWidgets.QFrame()
        header.setObjectName("WorkspaceHeader")
        hl = QtWidgets.QHBoxLayout(header)
        hl.setContentsMargins(14, 12, 14, 12)
        hl.setSpacing(14)

        title_col = QtWidgets.QVBoxLayout()
        title_col.setSpacing(4)
        self.title = QtWidgets.QLabel("WorldGeoLabs Workspace")
        self.title.setObjectName("WorkspaceTitle")
        self.subtitle = QtWidgets.QLabel(
            "Open a world, choose a project area, then build non-destructive underground feature layers."
        )
        self.subtitle.setObjectName("SubtleHint")
        self.subtitle.setWordWrap(True)
        title_col.addWidget(self.title)
        title_col.addWidget(self.subtitle)
        hl.addLayout(title_col, 1)

        status_col = QtWidgets.QVBoxLayout()
        status_col.setSpacing(6)
        self.world_chip = QtWidgets.QLabel("World: none")
        self.area_chip = QtWidgets.QLabel("Area: not set")
        self.tool_chip = QtWidgets.QLabel("Tool: Navigate")
        for chip in (self.world_chip, self.area_chip, self.tool_chip):
            chip.setObjectName("HeaderPill")
            chip.setMinimumWidth(190)
            status_col.addWidget(chip)
        hl.addLayout(status_col)

        actions = QtWidgets.QVBoxLayout()
        actions.setSpacing(6)
        top_actions = QtWidgets.QHBoxLayout()
        top_actions.setSpacing(6)
        self.open_button = QtWidgets.QPushButton("Open World")
        self.open_button.setObjectName("PrimaryButton")
        self.area_button = QtWidgets.QPushButton("Project Area")
        self.feature_button = QtWidgets.QPushButton("Create Feature")
        self.paint_button = QtWidgets.QPushButton("Paint")
        self.paint_button.setToolTip("Focus the Paint workspace and enable paint mode.")
        top_actions.addWidget(self.open_button)
        top_actions.addWidget(self.area_button)
        top_actions.addWidget(self.feature_button)
        top_actions.addWidget(self.paint_button)
        actions.addLayout(top_actions)

        self.workflow_hint = QtWidgets.QLabel("Workflow: 1 Open World  →  2 Select Area  →  3 Create Feature  →  4 Preview  →  5 Apply Copy")
        self.workflow_hint.setObjectName("MicroHint")
        self.workflow_hint.setWordWrap(True)
        actions.addWidget(self.workflow_hint)
        hl.addLayout(actions)

        self.open_button.clicked.connect(self.open_world_requested.emit)
        self.area_button.clicked.connect(self.project_area_requested.emit)
        self.feature_button.clicked.connect(self.create_feature_requested.emit)
        self.paint_button.clicked.connect(self.focus_paint_requested.emit)

        viewport_frame = QtWidgets.QFrame()
        viewport_frame.setObjectName("ViewportCard")
        vf = QtWidgets.QVBoxLayout(viewport_frame)
        vf.setContentsMargins(1, 1, 1, 1)
        vf.setSpacing(0)
        vf.addWidget(self._viewport, 1)

        layout.addWidget(header)
        layout.addWidget(viewport_frame, 1)

    def sync(self, *, world_name: str, area_text: str, tool_text: str, preview_text: str) -> None:
        world_clean = (world_name or "").strip()
        if world_clean:
            self.world_chip.setText(f"World: {world_clean}")
            self.subtitle.setText(
                "Layer-first workflow: select a feature on the left, tune it on the right, and preview safely in 3D before applying."
            )
            self.open_button.setText("Change World")
        else:
            self.world_chip.setText("World: none")
            self.subtitle.setText(
                "Open a world, choose a project area, then build non-destructive underground feature layers."
            )
            self.open_button.setText("Open World")
        self.area_chip.setText(f"{area_text}  •  {preview_text}")
        self.tool_chip.setText(tool_text or "Tool: Navigate")

    def set_paint_active(self, active: bool) -> None:
        self.paint_button.setProperty("active", bool(active))
        self.paint_button.style().unpolish(self.paint_button)
        self.paint_button.style().polish(self.paint_button)
