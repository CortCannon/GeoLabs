from __future__ import annotations

from pathlib import Path
from typing import Any
import json
import os

import numpy as np
from PySide6 import QtCore, QtGui, QtWidgets


class GeologyAnalysisPanel(QtWidgets.QWidget):
    analysis_requested = QtCore.Signal(object)
    resource_generation_requested = QtCore.Signal(object)
    cancel_requested = QtCore.Signal()
    resource_cancel_requested = QtCore.Signal()

    def __init__(self, parent=None) -> None:
        super().__init__(parent)
        self._manifest_path: Path | None = None
        self._world_loaded = False
        self._worldpainter_available = False
        self._resource_running = False
        self._build_ui()

    def _build_ui(self) -> None:
        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        title = QtWidgets.QLabel("Geological Analysis")
        title.setObjectName("PanelTitle")
        layout.addWidget(title)

        intro = QtWidgets.QLabel(
            "Build a disk-backed whole-map model of height, slope, drainage, "
            "surface material, soil depth, host rock, fluids, and 16×16×16 sections."
        )
        intro.setWordWrap(True)
        intro.setObjectName("SubtleHint")
        layout.addWidget(intro)

        source_box = QtWidgets.QGroupBox("Analysis source")
        source_form = QtWidgets.QFormLayout(source_box)
        self.source_combo = QtWidgets.QComboBox()
        self.source_combo.addItem("Automatic: WorldPainter + Minecraft verification", "auto")
        self.source_combo.addItem("WorldPainter overview only", "worldpainter")
        self.source_combo.addItem("Minecraft Anvil only", "minecraft")
        self.source_status = QtWidgets.QLabel("No world loaded")
        self.source_status.setWordWrap(True)
        self.source_status.setObjectName("SubtleHint")
        source_form.addRow("Mode", self.source_combo)
        source_form.addRow("Available", self.source_status)
        layout.addWidget(source_box)

        settings_box = QtWidgets.QGroupBox("Whole-map settings")
        settings_form = QtWidgets.QFormLayout(settings_box)
        self.scope_combo = QtWidgets.QComboBox()
        self.scope_combo.addItem("Entire indexed world", "full_world")
        self.scope_combo.addItem("Selected project area", "selected_area")

        self.resolution_combo = QtWidgets.QComboBox()
        for label, value in [
            ("4 blocks — detailed", 4),
            ("8 blocks — recommended", 8),
            ("16 blocks — fast", 16),
            ("32 blocks — coarse", 32),
        ]:
            self.resolution_combo.addItem(label, value)
        self.resolution_combo.setCurrentIndex(1)

        self.verify_combo = QtWidgets.QComboBox()
        for label, value in [
            ("Every chunk — detailed block verification", 16),
            ("Every 2 chunks — detailed large-map", 32),
            ("Every 4 chunks — recommended for 16k maps", 64),
            ("Every 8 chunks — quick", 128),
        ]:
            self.verify_combo.addItem(label, value)
        self.verify_combo.setCurrentIndex(2)

        cpu_count = max(1, int(os.cpu_count() or 1))
        self.analysis_workers = QtWidgets.QSpinBox()
        self.analysis_workers.setRange(0, max(cpu_count * 2, 64))
        self.analysis_workers.setValue(0)
        self.analysis_workers.setSpecialValueText(f"Auto — all {cpu_count} logical CPUs")
        self.analysis_workers.setToolTip(
            "0 uses every logical CPU reported by Windows. Geological verification is process-parallel; "
            "some dependency-ordered raster stages may use less than 100% CPU."
        )
        self.force_check = QtWidgets.QCheckBox("Force rebuild instead of reusing cache")
        settings_form.addRow("Scope", self.scope_combo)
        settings_form.addRow("Surface grid", self.resolution_combo)
        settings_form.addRow("Minecraft verification", self.verify_combo)
        settings_form.addRow("Analysis workers", self.analysis_workers)
        settings_form.addRow("", self.force_check)
        layout.addWidget(settings_box)

        resource_box = QtWidgets.QGroupBox("Whole-world geology / resources")
        resource_form = QtWidgets.QFormLayout(resource_box)
        self.resource_seed_override = QtWidgets.QCheckBox("Override profile seed")
        self.resource_seed = QtWidgets.QSpinBox()
        self.resource_seed.setRange(-2147483647, 2147483647)
        self.resource_seed.setValue(1337)
        self.resource_seed.setEnabled(False)
        self.resource_seed_override.toggled.connect(self.resource_seed.setEnabled)
        self.resource_population = QtWidgets.QDoubleSpinBox()
        self.resource_population.setRange(0.0, 10.0)
        self.resource_population.setDecimals(2)
        self.resource_population.setSingleStep(0.1)
        self.resource_population.setValue(1.0)
        self.resource_population.setToolTip("Global multiplier applied to every deposit population in world_geology_profile.toml")
        self.generate_resources_button = QtWidgets.QPushButton("Generate Geological Resources")
        self.generate_resources_button.setObjectName("PrimaryButton")
        self.generate_resources_button.setEnabled(False)
        self.edit_geology_button = QtWidgets.QPushButton("Edit Geology / Resource Rules")
        self.resource_hint = QtWidgets.QLabel(
            "Analyze first. Then generate deterministic seams, lenses, veins, stockworks, pipes and placers from the editable TOML geology profile. Generated resources become ordinary GeoLabs paint layers and can be exported with the existing safe Anvil writer."
        )
        self.resource_hint.setWordWrap(True)
        self.resource_hint.setObjectName("SubtleHint")
        resource_form.addRow(self.resource_seed_override)
        resource_form.addRow("Generation seed", self.resource_seed)
        resource_form.addRow("Population scale", self.resource_population)
        resource_form.addRow(self.generate_resources_button)
        resource_form.addRow(self.edit_geology_button)
        resource_form.addRow(self.resource_hint)
        layout.addWidget(resource_box)

        button_row = QtWidgets.QHBoxLayout()
        self.start_button = QtWidgets.QPushButton("Run Geological Analysis")
        self.start_button.setObjectName("PrimaryButton")
        self.cancel_button = QtWidgets.QPushButton("Cancel")
        self.cancel_button.setEnabled(False)
        self.open_cache_button = QtWidgets.QPushButton("Open Cache")
        self.open_cache_button.setEnabled(False)
        self.open_profile_button = QtWidgets.QPushButton("Edit Block Categories")
        button_row.addWidget(self.start_button, 1)
        button_row.addWidget(self.cancel_button)
        button_row.addWidget(self.open_cache_button)
        button_row.addWidget(self.open_profile_button)
        layout.addLayout(button_row)

        self.progress = QtWidgets.QProgressBar()
        self.progress.setRange(0, 100)
        self.progress.setValue(0)
        self.progress_label = QtWidgets.QLabel("Ready")
        self.progress_label.setWordWrap(True)
        self.progress_label.setObjectName("SubtleHint")
        layout.addWidget(self.progress)
        layout.addWidget(self.progress_label)

        preview_box = QtWidgets.QGroupBox("Analysis preview")
        preview_layout = QtWidgets.QVBoxLayout(preview_box)
        self.preview_combo = QtWidgets.QComboBox()
        self.preview_combo.addItem("Surface height", "surface_height")
        self.preview_combo.addItem("Slope", "slope_degrees")
        self.preview_combo.addItem("Drainage / flow accumulation", "flow_accumulation")
        self.preview_combo.addItem("Combined geological model", "geology_category")
        self.preview_combo.addItem("WorldPainter terrain category", "worldpainter_category")
        self.preview_combo.addItem("Minecraft surface category", "surface_category")
        self.preview_combo.addItem("Host-rock category", "host_category")
        self.preview_combo.addItem("Soil depth", "soil_depth")
        self.preview_combo.addItem("Structural uplift", "uplift_score")
        self.preview_combo.addItem("Sedimentary basin potential", "basin_score")
        self.preview_combo.addItem("Erosion / exposure", "erosion_score")
        self.preview_combo.addItem("Fault / fracture corridors", "fracture_score")
        self.preview_combo.addItem("Hydrothermal potential", "hydrothermal_score")
        self.preview_combo.addItem("Paleo-organic basin potential", "paleo_organic_score")
        self.preview_combo.addItem("Placer concentration potential", "placer_score")
        self.preview_combo.addItem("Orogenic / mountain-belt score", "orogenic_score")
        self.preview_combo.addItem("Stable deep-crust / craton proxy", "stable_craton_score")
        self.preview_combo.addItem("Folded strata warp (blocks)", "structural_warp_blocks")
        self.preview_label = QtWidgets.QLabel("Run analysis to create a preview.")
        self.preview_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignCenter)
        self.preview_label.setMinimumHeight(240)
        self.preview_label.setFrameShape(QtWidgets.QFrame.Shape.StyledPanel)
        self.preview_label.setScaledContents(False)
        preview_layout.addWidget(self.preview_combo)
        preview_layout.addWidget(self.preview_label, 1)
        layout.addWidget(preview_box, 1)

        summary_box = QtWidgets.QGroupBox("Analysis report")
        summary_layout = QtWidgets.QVBoxLayout(summary_box)
        self.summary_text = QtWidgets.QPlainTextEdit()
        self.summary_text.setReadOnly(True)
        self.summary_text.setMaximumBlockCount(5000)
        self.summary_text.setPlaceholderText(
            "Height range, slopes, category counts, unknown blocks, and cache details will appear here."
        )
        summary_layout.addWidget(self.summary_text)
        layout.addWidget(summary_box, 1)

        self.start_button.clicked.connect(self._request_analysis)
        self.cancel_button.clicked.connect(self.cancel_requested.emit)
        self.open_cache_button.clicked.connect(self._open_cache)
        self.open_profile_button.clicked.connect(self._open_profile)
        self.edit_geology_button.clicked.connect(self._open_geology_profile)
        self.generate_resources_button.clicked.connect(self._request_resource_generation)
        self.preview_combo.currentIndexChanged.connect(self.refresh_preview)

    def set_context(
        self,
        *,
        world_loaded: bool,
        world_name: str = "",
        worldpainter_available: bool = False,
        worldpainter_name: str = "",
    ) -> None:
        self._world_loaded = bool(world_loaded)
        self._worldpainter_available = bool(worldpainter_available)
        self.start_button.setEnabled(self._world_loaded and not self._resource_running)
        if not world_loaded:
            self.source_status.setText("No world loaded")
        elif worldpainter_available:
            self.source_status.setText(
                f"Minecraft: {world_name}\nWorldPainter: {worldpainter_name or 'paired source available'}"
            )
        else:
            self.source_status.setText(
                f"Minecraft: {world_name}\nWorldPainter: not paired; Anvil-only analysis is available."
            )
        wp_index = self.source_combo.findData("worldpainter")
        if wp_index >= 0:
            model = self.source_combo.model()
            item = model.item(wp_index)
            if item is not None:
                item.setEnabled(worldpainter_available)
        if not worldpainter_available and self.source_combo.currentData() == "worldpainter":
            self.source_combo.setCurrentIndex(0)

    def _request_analysis(self) -> None:
        if not self._world_loaded:
            return
        self.analysis_requested.emit({
            "source_mode": str(self.source_combo.currentData()),
            "scope": str(self.scope_combo.currentData()),
            "requested_step": int(self.resolution_combo.currentData()),
            "verification_step": int(self.verify_combo.currentData()),
            "workers": int(self.analysis_workers.value()),
            "force_rebuild": bool(self.force_check.isChecked()),
        })

    def set_running(self, running: bool) -> None:
        self.start_button.setEnabled(self._world_loaded and not running)
        self.cancel_button.setEnabled(running)
        self.source_combo.setEnabled(not running)
        self.scope_combo.setEnabled(not running)
        self.resolution_combo.setEnabled(not running)
        self.verify_combo.setEnabled(not running)
        self.analysis_workers.setEnabled(not running)
        self.force_check.setEnabled(not running)
        if running:
            self.progress.setValue(0)
            self.progress_label.setText("Starting geological analysis…")

    @QtCore.Slot(int, str)
    def set_progress(self, value: int, message: str) -> None:
        self.progress.setValue(max(0, min(100, int(value))))
        self.progress_label.setText(str(message))

    def set_failure(self, message: str) -> None:
        self.set_running(False)
        self.progress_label.setText("Analysis failed")
        self.summary_text.setPlainText(str(message))

    def set_cancelled(self) -> None:
        self.set_running(False)
        self.progress_label.setText("Analysis cancelled")

    def set_report(self, report: Any) -> None:
        self.set_running(False)
        self.progress.setValue(100)
        self._manifest_path = Path(report.manifest_path)
        self.open_cache_button.setEnabled(True)
        self.generate_resources_button.setEnabled(True)
        self._sync_resource_preview_entries()
        status = "Loaded cached result" if report.reused_cache else "Analysis complete"
        self.progress_label.setText(
            f"{status} in {report.elapsed_seconds:.1f}s — "
            f"{report.grid_shape[1]:,}×{report.grid_shape[0]:,} cells at {report.effective_step}-block spacing"
        )
        summary = dict(report.summary or {})
        category_counts = dict(summary.get("surface_category_counts") or {})
        category_lines = "\n".join(
            f"  {name}: {count:,}" for name, count in
            sorted(category_counts.items(), key=lambda item: item[1], reverse=True)
        ) or "  No Minecraft category samples"
        self.summary_text.setPlainText(
            f"Source\n  {report.source_summary}\n\n"
            f"Grid\n  {report.grid_shape[1]:,} × {report.grid_shape[0]:,}\n"
            f"  Spacing: {report.effective_step} blocks\n\n"
            f"Surface\n"
            f"  Samples: {int(summary.get('surface_sample_count', 0)):,}\n"
            f"  Height: {summary.get('height_min', 0):.1f} .. {summary.get('height_max', 0):.1f}\n"
            f"  Mean height: {summary.get('height_mean', 0):.1f}\n"
            f"  Mean slope: {summary.get('slope_mean_degrees', 0):.2f}°\n"
            f"  Maximum slope: {summary.get('slope_max_degrees', 0):.2f}°\n\n"
            f"Minecraft verification\n"
            f"  Sampled chunks: {report.sampled_chunks:,}\n"
            f"  16×16×16 summaries: {report.sampled_sections:,}\n"
            f"  Unknown blocks: {report.unknown_blocks:,}\n\n"
            f"Geological categories\n{category_lines}\n\n"
            f"Cache\n  {report.cache_dir}"
        )
        self.refresh_preview()

    def focus_dataset(self, dataset: str, manifest_path: Path | None = None) -> None:
        if manifest_path is not None:
            self.load_manifest(Path(manifest_path))
        index = self.preview_combo.findData(str(dataset))
        if index >= 0:
            self.preview_combo.setCurrentIndex(index)
        self.refresh_preview()

    def load_manifest(self, manifest_path: Path) -> None:
        path = Path(manifest_path)
        if not path.is_file():
            return
        self._manifest_path = path
        self.open_cache_button.setEnabled(True)
        self.generate_resources_button.setEnabled(True)
        self._sync_resource_preview_entries()
        self.refresh_preview()

    def _open_cache(self) -> None:
        if self._manifest_path is None:
            return
        QtGui.QDesktopServices.openUrl(
            QtCore.QUrl.fromLocalFile(str(self._manifest_path.parent))
        )

    def _request_resource_generation(self) -> None:
        if self._manifest_path is None or not self._manifest_path.is_file():
            return
        self.resource_generation_requested.emit({
            "manifest_path": str(self._manifest_path),
            "seed": int(self.resource_seed.value()) if self.resource_seed_override.isChecked() else None,
            "population_scale": float(self.resource_population.value()),
        })

    def set_resource_running(self, running: bool) -> None:
        self._resource_running = bool(running)
        self.generate_resources_button.setEnabled(bool(self._manifest_path) and not running)
        self.start_button.setEnabled(self._world_loaded and not running)
        self.cancel_button.setEnabled(running)
        self.resource_seed_override.setEnabled(not running)
        self.resource_seed.setEnabled((not running) and self.resource_seed_override.isChecked())
        self.resource_population.setEnabled(not running)
        self.edit_geology_button.setEnabled(not running)
        self.source_combo.setEnabled(not running)
        self.scope_combo.setEnabled(not running)
        self.resolution_combo.setEnabled(not running)
        self.verify_combo.setEnabled(not running)
        self.analysis_workers.setEnabled(not running)
        self.force_check.setEnabled(not running)
        if running:
            self.progress.setValue(0)
            self.progress_label.setText("Generating geological resources…")

    def set_resource_report(self, report: Any) -> None:
        self.set_resource_running(False)
        self.progress.setValue(100)
        self.progress_label.setText(
            f"Resource generation complete in {report.elapsed_seconds:.1f}s — "
            f"{sum(report.deposit_counts.values()):,} deposits / {sum(report.stroke_counts.values()):,} edit strokes"
        )
        counts = "\n".join(
            f"  {name}: {count:,} deposits ({int(report.stroke_counts.get(name, 0)):,} strokes)"
            for name, count in sorted(report.deposit_counts.items())
        ) or "  No deposits selected"
        current = self.summary_text.toPlainText().rstrip()
        self.summary_text.setPlainText(
            current + "\n\nGenerated geological resources\n" + counts +
            f"\n\nResource plan\n  {report.plan_path}"
        )
        self._manifest_path = Path(report.manifest_path)
        self._sync_resource_preview_entries()
        self.refresh_preview()

    def set_resource_failure(self, message: str) -> None:
        self.set_resource_running(False)
        self.progress_label.setText("Resource generation failed")
        self.summary_text.appendPlainText(f"\n\nResource generation failed:\n{message}")

    def set_resource_cancelled(self) -> None:
        self.set_resource_running(False)
        self.progress_label.setText("Resource generation cancelled")

    def _sync_resource_preview_entries(self) -> None:
        if self._manifest_path is None or not self._manifest_path.is_file():
            return
        try:
            manifest = json.loads(self._manifest_path.read_text(encoding="utf-8"))
            arrays = dict(manifest.get("arrays") or {})
            existing = {str(self.preview_combo.itemData(i)) for i in range(self.preview_combo.count())}
            deposits = {str(x.get("id")): str(x.get("label") or x.get("id")) for x in (manifest.get("resource_deposits") or [])}
            for name in sorted(arrays):
                if not name.startswith("resource_") or not name.endswith("_suitability") or name in existing:
                    continue
                deposit_id = name[len("resource_"):-len("_suitability")]
                label = deposits.get(deposit_id, deposit_id.replace("_", " ").title())
                self.preview_combo.addItem(f"Resource suitability: {label}", name)
        except Exception:
            pass

    def _open_geology_profile(self) -> None:
        profile = Path(__file__).resolve().parents[3] / "config" / "geology" / "world_geology_profile.toml"
        if profile.exists():
            QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(str(profile)))

    def _open_profile(self) -> None:
        profile = Path(__file__).resolve().parents[3] / "config" / "geology" / "minecraft_26_2_block_categories.toml"
        if profile.exists():
            QtGui.QDesktopServices.openUrl(QtCore.QUrl.fromLocalFile(str(profile)))

    @QtCore.Slot()
    def refresh_preview(self) -> None:
        if self._manifest_path is None or not self._manifest_path.is_file():
            return
        try:
            manifest = json.loads(self._manifest_path.read_text(encoding="utf-8"))
            array_name = str(self.preview_combo.currentData())
            spec = dict((manifest.get("arrays") or {}).get(array_name) or {})
            if not spec:
                self.preview_label.setText(f"No {array_name} array is available.")
                return
            shape = tuple(int(v) for v in spec["shape"])
            data = np.memmap(
                self._manifest_path.parent / str(spec["file"]),
                mode="r",
                dtype=np.dtype(str(spec["dtype"])),
                shape=shape,
            )
            rgb = self._render_array(array_name, np.asarray(data), manifest)
            image = QtGui.QImage(
                rgb.data,
                rgb.shape[1],
                rgb.shape[0],
                rgb.strides[0],
                QtGui.QImage.Format.Format_RGB888,
            ).copy()
            target = self.preview_label.size()
            pixmap = QtGui.QPixmap.fromImage(image).scaled(
                max(64, target.width() - 8),
                max(64, target.height() - 8),
                QtCore.Qt.AspectRatioMode.KeepAspectRatio,
                QtCore.Qt.TransformationMode.SmoothTransformation,
            )
            self.preview_label.setPixmap(pixmap)
        except Exception as exc:
            self.preview_label.setText(f"Could not render preview:\n{exc}")

    @staticmethod
    def _downsample(array: np.ndarray, max_size: int = 900) -> np.ndarray:
        rows, cols = array.shape[:2]
        stride = max(1, int(max(rows, cols) / max_size))
        return array[::stride, ::stride]

    def _render_array(self, name: str, source: np.ndarray, manifest: dict) -> np.ndarray:
        data = self._downsample(source)
        if name in {"geology_category", "worldpainter_category", "surface_category", "host_category"}:
            categories = manifest.get("categories") or []
            result = np.zeros((data.shape[0], data.shape[1], 3), dtype=np.uint8)
            palette = np.asarray([
                [
                    (37 * (i + 3)) % 220 + 25,
                    (83 * (i + 5)) % 220 + 25,
                    (131 * (i + 7)) % 220 + 25,
                ]
                for i in range(max(1, len(categories)))
            ], dtype=np.uint8)
            valid = (data >= 0) & (data < len(palette))
            result[valid] = palette[data[valid].astype(np.int64)]
            return np.ascontiguousarray(result)

        values = data.astype(np.float32)
        valid = np.isfinite(values)
        if name == "soil_depth":
            valid &= values >= 0
        if not np.any(valid):
            return np.zeros((values.shape[0], values.shape[1], 3), dtype=np.uint8)

        if name == "flow_accumulation":
            values = np.log1p(np.maximum(values, 0.0))
        if name == "structural_warp_blocks":
            vmax = float(np.nanpercentile(np.abs(values[valid]), 98.0)) if np.any(valid) else 1.0
            vmax = max(1.0, vmax)
            normal = np.clip((values + vmax) / (2.0 * vmax), 0.0, 1.0)
            red = (normal * 255).astype(np.uint8)
            green = (110 + (1.0 - np.abs(normal - 0.5) * 2.0) * 100).astype(np.uint8)
            blue = ((1.0 - normal) * 255).astype(np.uint8)
            rgb = np.dstack((red, green, blue))
            rgb[~valid] = 0
            return np.ascontiguousarray(rgb)
        lo, hi = np.nanpercentile(values[valid], [2.0, 98.0])
        if not np.isfinite(lo) or not np.isfinite(hi) or hi <= lo:
            lo = float(np.nanmin(values[valid]))
            hi = float(np.nanmax(values[valid])) + 1.0
        normal = np.clip((values - lo) / (hi - lo), 0.0, 1.0)
        normal[~valid] = 0.0

        if name == "flow_accumulation":
            red = (normal * 70).astype(np.uint8)
            green = (normal * 170).astype(np.uint8)
            blue = (normal * 255).astype(np.uint8)
        elif name == "slope_degrees":
            red = (normal * 255).astype(np.uint8)
            green = ((1.0 - normal) * 190).astype(np.uint8)
            blue = ((1.0 - normal) * 90).astype(np.uint8)
        elif name == "soil_depth":
            red = (80 + normal * 130).astype(np.uint8)
            green = (55 + normal * 110).astype(np.uint8)
            blue = (30 + normal * 45).astype(np.uint8)
        elif name.startswith("resource_") and name.endswith("_suitability"):
            red = (normal * 255).astype(np.uint8)
            green = (normal * normal * 220).astype(np.uint8)
            blue = ((1.0 - normal) * 60).astype(np.uint8)
        elif name in {"uplift_score", "orogenic_score", "fracture_score", "hydrothermal_score"}:
            red = (normal * 255).astype(np.uint8)
            green = (normal * 150).astype(np.uint8)
            blue = ((1.0 - normal) * 120).astype(np.uint8)
        elif name in {"basin_score", "paleo_organic_score", "placer_score"}:
            red = ((1.0 - normal) * 70).astype(np.uint8)
            green = (normal * 220).astype(np.uint8)
            blue = (80 + normal * 160).astype(np.uint8)
        else:
            red = (normal * 220).astype(np.uint8)
            green = (normal * 235).astype(np.uint8)
            blue = (normal * 255).astype(np.uint8)

        rgb = np.dstack((red, green, blue))
        rgb[~valid] = 0
        return np.ascontiguousarray(rgb)
