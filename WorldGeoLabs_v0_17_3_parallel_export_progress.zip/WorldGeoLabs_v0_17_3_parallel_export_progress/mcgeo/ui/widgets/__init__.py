"""Reusable Qt widgets used by the WorldGeoLabs main window."""
