from __future__ import annotations

from PySide6 import QtWidgets, QtCore


class PaintPanel(QtWidgets.QWidget):
    paint_settings_changed = QtCore.Signal(dict)
    add_layer_requested = QtCore.Signal(str)
    import_model_requested = QtCore.Signal()
    focus_paint_requested = QtCore.Signal()
    realign_requested = QtCore.Signal()

    COMMON_BLOCKS = [
        "minecraft:stone", "minecraft:deepslate", "minecraft:tuff", "minecraft:calcite",
        "minecraft:granite", "minecraft:diorite", "minecraft:andesite", "minecraft:dripstone_block",
        "minecraft:cobblestone", "minecraft:mossy_cobblestone", "minecraft:basalt", "minecraft:smooth_basalt",
        "minecraft:blackstone", "minecraft:netherrack", "minecraft:end_stone", "minecraft:obsidian", "minecraft:bedrock",
        "minecraft:gravel", "minecraft:sand", "minecraft:red_sand", "minecraft:clay", "minecraft:dirt",
        "minecraft:coarse_dirt", "minecraft:rooted_dirt", "minecraft:mud", "minecraft:grass_block",
        "minecraft:air", "minecraft:cave_air", "minecraft:water", "minecraft:lava",
        "minecraft:coal_ore", "minecraft:deepslate_coal_ore",
        "minecraft:iron_ore", "minecraft:deepslate_iron_ore",
        "minecraft:copper_ore", "minecraft:deepslate_copper_ore",
        "minecraft:gold_ore", "minecraft:deepslate_gold_ore",
        "minecraft:redstone_ore", "minecraft:deepslate_redstone_ore",
        "minecraft:lapis_ore", "minecraft:deepslate_lapis_ore",
        "minecraft:diamond_ore", "minecraft:deepslate_diamond_ore",
        "minecraft:emerald_ore", "minecraft:deepslate_emerald_ore",
        "minecraft:nether_gold_ore", "minecraft:nether_quartz_ore", "minecraft:ancient_debris",
        "minecraft:raw_iron_block", "minecraft:raw_copper_block", "minecraft:raw_gold_block",
        "minecraft:amethyst_block", "minecraft:budding_amethyst", "minecraft:glowstone", "minecraft:magma_block",
    ]

    CATEGORY_FILTERS = {
        "All blocks": lambda b: True,
        "Common terrain": lambda b: any(k in b for k in ("stone", "deepslate", "tuff", "granite", "diorite", "andesite", "basalt", "blackstone", "dirt", "sand", "gravel", "clay")) and "ore" not in b,
        "Ores": lambda b: ("_ore" in b) or ("ancient_debris" in b) or b.endswith("raw_iron_block") or b.endswith("raw_copper_block") or b.endswith("raw_gold_block"),
        "Deepslate ores": lambda b: "deepslate_" in b and ("_ore" in b),
        "Cave / carve": lambda b: b in {"minecraft:air", "minecraft:cave_air", "minecraft:water", "minecraft:lava"},
        "Fluids / light": lambda b: any(k in b for k in ("water", "lava", "glowstone", "magma")),
    }

    QUICK_BLOCK_GROUPS = [
        ("Ores", [
            ("Iron", "minecraft:iron_ore"), ("Deep iron", "minecraft:deepslate_iron_ore"),
            ("Copper", "minecraft:copper_ore"), ("Gold", "minecraft:gold_ore"),
            ("Redstone", "minecraft:redstone_ore"), ("Lapis", "minecraft:lapis_ore"),
            ("Diamond", "minecraft:diamond_ore"), ("Deep diamond", "minecraft:deepslate_diamond_ore"),
            ("Emerald", "minecraft:emerald_ore"), ("Ancient debris", "minecraft:ancient_debris"),
        ]),
        ("Terrain", [
            ("Stone", "minecraft:stone"), ("Deepslate", "minecraft:deepslate"),
            ("Tuff", "minecraft:tuff"), ("Calcite", "minecraft:calcite"),
            ("Granite", "minecraft:granite"), ("Diorite", "minecraft:diorite"),
            ("Andesite", "minecraft:andesite"), ("Gravel", "minecraft:gravel"),
        ]),
        ("Carve / fluids", [
            ("Air / carve", "minecraft:air"), ("Cave air", "minecraft:cave_air"),
            ("Water", "minecraft:water"), ("Lava", "minecraft:lava"),
            ("Obsidian", "minecraft:obsidian"), ("Magma", "minecraft:magma_block"),
        ]),
    ]

    BRUSH_PRESETS = {
        "Custom": {},
        "Ore pocket": {
            "action": "Paint ore mask", "shape": "Blob", "size_blocks": 7,
            "strength_pct": 75, "spacing_pct_radius": 35, "falloff": "Noise edge",
            "host_only": True, "protect_surface": True,
        },
        "Ore seam": {
            "action": "Paint ore mask", "shape": "Disc", "size_blocks": 12,
            "strength_pct": 60, "spacing_pct_radius": 30, "falloff": "Smoothstep",
            "host_only": True, "protect_surface": True,
        },
        "Cave carve": {
            "action": "Carve cave (preview)", "shape": "Sphere", "material": "minecraft:air",
            "size_blocks": 14, "strength_pct": 100, "spacing_pct_radius": 45,
            "falloff": "Smoothstep", "host_only": False, "protect_surface": True,
        },
        "Tunnel brush": {
            "action": "Carve cave (preview)", "shape": "Tunnel brush", "material": "minecraft:air",
            "size_blocks": 10, "strength_pct": 100, "spacing_pct_radius": 30,
            "falloff": "Smoothstep", "host_only": False, "protect_surface": True,
        },
        "Rock replace": {
            "action": "Replace blocks", "shape": "Sphere", "size_blocks": 16,
            "strength_pct": 100, "spacing_pct_radius": 50, "falloff": "Linear",
            "host_only": False, "protect_surface": False,
        },
        "Detail brush": {
            "action": "Replace blocks", "shape": "Sphere", "size_blocks": 3,
            "strength_pct": 100, "spacing_pct_radius": 25, "falloff": "Constant",
            "host_only": False, "protect_surface": False,
        },
    }

    def __init__(self) -> None:
        super().__init__()
        self.setObjectName("PaintPanel")
        self._updating_block_filter = False

        layout = QtWidgets.QVBoxLayout(self)
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(8)

        title = QtWidgets.QLabel("Paint")
        title.setObjectName("PanelTitle")
        layout.addWidget(title)

        subtitle = QtWidgets.QLabel(
            "Brushes, block selection, and free-3D placement for non-destructive preview edits. "
            "Block transparency now lives in Scene / Preview > View."
        )
        subtitle.setObjectName("SubtleHint")
        subtitle.setWordWrap(True)
        layout.addWidget(subtitle)

        quick = QtWidgets.QGroupBox("Paint workflow")
        qg = QtWidgets.QGridLayout(quick)
        qg.setHorizontalSpacing(8)
        qg.setVerticalSpacing(6)

        self.paint_enabled = QtWidgets.QCheckBox("Enable paint mode")
        self.paint_enabled.setChecked(False)
        self.btn_focus = QtWidgets.QPushButton("Use Paint Tool")
        self.btn_add_layer = QtWidgets.QPushButton("Add paint layer")

        self.active_layer = QtWidgets.QComboBox()
        self.active_layer.setEditable(True)
        self.active_layer.addItems(["Paint: Ore pass A", "Paint: Cave carve A"])
        self.active_layer.setEditText("Paint: Ore pass A")

        qg.addWidget(self.paint_enabled, 0, 0, 1, 2)
        qg.addWidget(self.btn_focus, 0, 2)
        qg.addWidget(self.btn_add_layer, 0, 3)
        qg.addWidget(QtWidgets.QLabel("Active layer"), 1, 0)
        qg.addWidget(self.active_layer, 1, 1, 1, 3)
        layout.addWidget(quick)

        self.tabs = QtWidgets.QTabWidget()
        self.tabs.setDocumentMode(True)
        layout.addWidget(self.tabs, 1)

        self._build_brush_tab()
        self._build_blocks_tab()
        self._build_placement_tab()
        self._build_info_tab()

        # Slider/spin sync
        self.size.valueChanged.connect(self.size_spin.setValue)
        self.size_spin.valueChanged.connect(self.size.setValue)
        self.strength.valueChanged.connect(self.strength_spin.setValue)
        self.strength_spin.valueChanged.connect(self.strength.setValue)
        self.spacing.valueChanged.connect(self.spacing_spin.setValue)
        self.spacing_spin.valueChanged.connect(self.spacing.setValue)

        for w in self._settings_widgets():
            if isinstance(w, QtWidgets.QAbstractButton):
                w.toggled.connect(self.emit_paint_settings)
            elif isinstance(w, QtWidgets.QComboBox):
                if w.isEditable() and w.lineEdit() is not None:
                    w.lineEdit().editingFinished.connect(self.emit_paint_settings)
                w.currentTextChanged.connect(lambda *_: self.emit_paint_settings())
            elif isinstance(w, (QtWidgets.QSpinBox, QtWidgets.QDoubleSpinBox)):
                w.valueChanged.connect(lambda *_: self.emit_paint_settings())
            elif isinstance(w, QtWidgets.QSlider):
                w.valueChanged.connect(lambda *_: self.emit_paint_settings())
            elif isinstance(w, QtWidgets.QLineEdit):
                w.editingFinished.connect(self._apply_typed_block)

        self.btn_add_layer.clicked.connect(self._on_add_layer)
        self.btn_focus.clicked.connect(self.focus_paint_requested)
        self.btn_import_model.clicked.connect(self.import_model_requested)
        self.btn_library.clicked.connect(lambda: QtWidgets.QToolTip.showText(self.mapToGlobal(self.rect().center()), "Stamp library is a future milestone.", self))
        self.btn_realign.clicked.connect(self.realign_requested.emit)
        self.btn_offset_closer.clicked.connect(lambda: self._nudge_brush_offset(+1.0))
        self.btn_offset_farther.clicked.connect(lambda: self._nudge_brush_offset(-1.0))
        self.btn_reset_brush_controls.clicked.connect(self._reset_brush_controls)
        self.brush_preset.currentTextChanged.connect(self._on_brush_preset_changed)
        self.block_category.currentTextChanged.connect(lambda *_: self._filter_block_list(self.block_search.text()))
        self.block_search.textChanged.connect(self._filter_block_list)
        self.block_list.itemSelectionChanged.connect(self._on_block_list_selection)
        self.block_list.itemDoubleClicked.connect(lambda item: self._select_block(item.data(QtCore.Qt.ItemDataRole.UserRole) or item.text()))
        self.btn_clear_block_search.clicked.connect(lambda: self.block_search.setText(""))
        self.btn_apply_typed_block.clicked.connect(self._apply_typed_block)
        self.btn_copy_block.clicked.connect(self._copy_selected_block)
        self.action.currentTextChanged.connect(self._refresh_ui)
        self.protect_surface.toggled.connect(self._refresh_ui)
        self.paint_enabled.toggled.connect(self._refresh_ui)
        self.align_mode.currentTextChanged.connect(self._refresh_ui)

        self._filter_block_list("")
        self._refresh_ui()

    def _build_brush_tab(self) -> None:
        tab = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(tab)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(8)

        brush = QtWidgets.QGroupBox("Brush")
        bg = QtWidgets.QGridLayout(brush)
        bg.setHorizontalSpacing(8)
        bg.setVerticalSpacing(6)

        self.brush_preset = QtWidgets.QComboBox()
        self.brush_preset.addItems(list(self.BRUSH_PRESETS.keys()))
        self.brush_preset.setToolTip("Presets set action, size, falloff, and useful constraints. Change any setting afterward to make a custom brush.")

        self.action = QtWidgets.QComboBox()
        self.action.addItems(["Replace blocks", "Fill material", "Erase blocks", "Carve cave (preview)", "Paint ore mask", "Stamp blueprint (preview)"])

        self.material = QtWidgets.QComboBox()
        self.material.setEditable(True)
        self.material.addItems(self.COMMON_BLOCKS)
        self.material.setCurrentText("minecraft:iron_ore")
        self.material.setInsertPolicy(QtWidgets.QComboBox.InsertPolicy.InsertAtTop)
        self.material.setToolTip("Selected paint block. The Blocks tab gives a larger, easier picker.")

        self.shape = QtWidgets.QComboBox()
        self.shape.addItems(["Sphere", "Blob", "Disc", "Tunnel brush", "Box"])

        self.size = QtWidgets.QSlider(QtCore.Qt.Orientation.Horizontal)
        self.size.setRange(1, 64)
        self.size.setValue(8)
        self.size_spin = QtWidgets.QSpinBox()
        self.size_spin.setRange(1, 64)
        self.size_spin.setValue(8)
        self.size_spin.setSuffix(" b")

        self.strength = QtWidgets.QSlider(QtCore.Qt.Orientation.Horizontal)
        self.strength.setRange(1, 100)
        self.strength.setValue(100)
        self.strength_spin = QtWidgets.QSpinBox()
        self.strength_spin.setRange(1, 100)
        self.strength_spin.setValue(100)
        self.strength_spin.setSuffix(" %")

        self.spacing = QtWidgets.QSlider(QtCore.Qt.Orientation.Horizontal)
        self.spacing.setRange(1, 200)
        self.spacing.setValue(25)
        self.spacing_spin = QtWidgets.QSpinBox()
        self.spacing_spin.setRange(1, 200)
        self.spacing_spin.setValue(25)
        self.spacing_spin.setSuffix(" % radius")

        self.falloff = QtWidgets.QComboBox()
        self.falloff.addItems(["Constant", "Linear", "Smoothstep", "Noise edge"])

        row = 0
        bg.addWidget(QtWidgets.QLabel("Preset"), row, 0)
        bg.addWidget(self.brush_preset, row, 1)
        bg.addWidget(QtWidgets.QLabel("Action"), row, 2)
        bg.addWidget(self.action, row, 3)
        row += 1
        bg.addWidget(QtWidgets.QLabel("Block / material"), row, 0)
        bg.addWidget(self.material, row, 1, 1, 3)
        row += 1
        bg.addWidget(QtWidgets.QLabel("Shape"), row, 0)
        bg.addWidget(self.shape, row, 1)
        bg.addWidget(QtWidgets.QLabel("Falloff"), row, 2)
        bg.addWidget(self.falloff, row, 3)
        row += 1
        bg.addWidget(QtWidgets.QLabel("Brush size"), row, 0)
        bg.addWidget(self.size, row, 1, 1, 2)
        bg.addWidget(self.size_spin, row, 3)
        row += 1
        bg.addWidget(QtWidgets.QLabel("Strength"), row, 0)
        bg.addWidget(self.strength, row, 1, 1, 2)
        bg.addWidget(self.strength_spin, row, 3)
        row += 1
        bg.addWidget(QtWidgets.QLabel("Stroke spacing"), row, 0)
        bg.addWidget(self.spacing, row, 1, 1, 2)
        bg.addWidget(self.spacing_spin, row, 3)
        layout.addWidget(brush)

        stamps = QtWidgets.QGroupBox("Models / stamps")
        sg = QtWidgets.QHBoxLayout(stamps)
        self.btn_import_model = QtWidgets.QPushButton("Import 3D model (OBJ/GLB)")
        self.btn_library = QtWidgets.QPushButton("Stamp library")
        self.btn_import_model.setToolTip("UI stub for upcoming voxelized model stamps.")
        self.btn_library.setToolTip("Future reusable stamp/brush library.")
        sg.addWidget(self.btn_import_model)
        sg.addWidget(self.btn_library)
        layout.addWidget(stamps)

        hint = QtWidgets.QLabel("Brush presets are workflow shortcuts. Strokes are still stored as editable, non-destructive preview data on the selected paint layer.")
        hint.setObjectName("SubtleHint")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        layout.addStretch(1)
        self.tabs.addTab(tab, "Brush")

    def _build_blocks_tab(self) -> None:
        tab = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(tab)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(8)

        selected = QtWidgets.QGroupBox("Selected paint block")
        sg = QtWidgets.QGridLayout(selected)
        sg.setHorizontalSpacing(8)
        sg.setVerticalSpacing(6)
        self.selected_block_label = QtWidgets.QLabel(self.material.currentText())
        self.selected_block_label.setTextInteractionFlags(QtCore.Qt.TextInteractionFlag.TextSelectableByMouse)
        self.typed_block = QtWidgets.QLineEdit(self.material.currentText())
        self.typed_block.setPlaceholderText("minecraft:block_name")
        self.btn_apply_typed_block = QtWidgets.QPushButton("Use typed block")
        self.btn_copy_block = QtWidgets.QPushButton("Copy name")
        self.preview_block_faces = QtWidgets.QCheckBox("Render painted blocks as real block surfaces")
        self.preview_block_faces.setChecked(True)
        self.preview_block_faces.setToolTip("Painted ores/replacements show material-boundary block faces inside terrain instead of only a brush marker.")
        sg.addWidget(QtWidgets.QLabel("Current"), 0, 0)
        sg.addWidget(self.selected_block_label, 0, 1, 1, 3)
        sg.addWidget(QtWidgets.QLabel("Type/custom"), 1, 0)
        sg.addWidget(self.typed_block, 1, 1)
        sg.addWidget(self.btn_apply_typed_block, 1, 2)
        sg.addWidget(self.btn_copy_block, 1, 3)
        sg.addWidget(self.preview_block_faces, 2, 0, 1, 4)
        layout.addWidget(selected)

        quick_tabs = QtWidgets.QTabWidget()
        quick_tabs.setDocumentMode(True)
        for group_name, entries in self.QUICK_BLOCK_GROUPS:
            page = QtWidgets.QWidget()
            grid = QtWidgets.QGridLayout(page)
            grid.setContentsMargins(4, 4, 4, 4)
            grid.setHorizontalSpacing(5)
            grid.setVerticalSpacing(5)
            for i, (label, block) in enumerate(entries):
                btn = QtWidgets.QPushButton(label)
                btn.setToolTip(block)
                btn.clicked.connect(lambda _checked=False, b=block: self._select_block(b))
                grid.addWidget(btn, i // 3, i % 3)
            grid.setRowStretch((len(entries) + 2) // 3, 1)
            quick_tabs.addTab(page, group_name)
        layout.addWidget(quick_tabs)

        picker = QtWidgets.QGroupBox("Block palette")
        pg = QtWidgets.QGridLayout(picker)
        pg.setHorizontalSpacing(8)
        pg.setVerticalSpacing(6)
        self.block_category = QtWidgets.QComboBox()
        self.block_category.addItems(list(self.CATEGORY_FILTERS.keys()))
        self.block_search = QtWidgets.QLineEdit()
        self.block_search.setPlaceholderText("Search blocks, e.g. ore, deepslate, lava")
        self.block_search.setClearButtonEnabled(True)
        self.btn_clear_block_search = QtWidgets.QToolButton()
        self.btn_clear_block_search.setText("Clear")
        self.block_list = QtWidgets.QListWidget()
        self.block_list.setSelectionMode(QtWidgets.QAbstractItemView.SelectionMode.SingleSelection)
        self.block_list.setAlternatingRowColors(True)
        self.block_list.setMinimumHeight(210)
        self.replace_mode = QtWidgets.QComboBox()
        self.replace_mode.addItems([
            "Replace any visible solid block",
            "Only host rock / stone-like blocks",
            "Only same family as selected block",
            "Only air/fluid cavities",
        ])
        self.replace_mode.setToolTip("Preview rule for future layer evaluation. Current paint preview stores the rule with each stroke/layer.")
        pg.addWidget(QtWidgets.QLabel("Category"), 0, 0)
        pg.addWidget(self.block_category, 0, 1)
        pg.addWidget(QtWidgets.QLabel("Search"), 1, 0)
        pg.addWidget(self.block_search, 1, 1)
        pg.addWidget(self.btn_clear_block_search, 1, 2)
        pg.addWidget(self.block_list, 2, 0, 1, 3)
        pg.addWidget(QtWidgets.QLabel("Replace rule"), 3, 0)
        pg.addWidget(self.replace_mode, 3, 1, 1, 2)
        layout.addWidget(picker, 1)

        hint = QtWidgets.QLabel("Tip: use the category tabs for common picks, or type any valid Minecraft block ID above. Transparency controls are in Scene / Preview > View.")
        hint.setObjectName("SubtleHint")
        hint.setWordWrap(True)
        layout.addWidget(hint)
        self.tabs.addTab(tab, "Blocks")

    def _build_placement_tab(self) -> None:
        tab = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(tab)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(8)

        target = QtWidgets.QGroupBox("Brush placement / constraints")
        tg = QtWidgets.QGridLayout(target)
        tg.setHorizontalSpacing(8)
        tg.setVerticalSpacing(6)
        self.target_help = QtWidgets.QLabel(
            "Free 3D cursor: the brush reprojects under the mouse on a camera-facing 3D plane instead of re-snapping to the surface. Alt+Wheel, [ / ], or PageUp/PageDown move the gizmo up/down in world Y; Shift remains camera-down."
        )
        self.target_help.setObjectName("SubtleHint")
        self.target_help.setWordWrap(True)
        self.axis_lock = QtWidgets.QComboBox(); self.axis_lock.addItems(["None", "X", "Y", "Z"])
        self.mirror = QtWidgets.QComboBox(); self.mirror.addItems(["None", "Mirror X", "Mirror Z", "Mirror X+Z"])
        self.host_only = QtWidgets.QCheckBox("Host-rock aware filter"); self.host_only.setChecked(True)
        self.protect_surface = QtWidgets.QCheckBox("Protect surface / topsoil"); self.protect_surface.setChecked(True)
        self.surface_margin = QtWidgets.QSpinBox(); self.surface_margin.setRange(0, 128); self.surface_margin.setValue(6); self.surface_margin.setSuffix(" b")
        self.live_overlay = QtWidgets.QCheckBox("Show brush overlay"); self.live_overlay.setChecked(True)
        self.snap_to_surface = QtWidgets.QCheckBox("Exact surface snap")
        self.snap_to_surface.setChecked(False)
        self.snap_to_surface.setToolTip("When enabled, the brush stays exactly on the surface. Leave this off for depth-based 3D painting.")
        self.align_mode = QtWidgets.QComboBox(); self.align_mode.addItems(["Follow hit normal (auto)", "Lock normal (re-align)", "Manual (no auto align)"])
        self.btn_realign = QtWidgets.QPushButton("Re-align now")
        self.btn_realign.setToolTip("In lock-normal mode, capture the current surface normal again.")
        self.brush_roll = QtWidgets.QSpinBox(); self.brush_roll.setRange(-180, 180); self.brush_roll.setValue(0); self.brush_roll.setSuffix("°")
        self.brush_offset = QtWidgets.QDoubleSpinBox()
        self.brush_offset.setRange(-8192.0, 8192.0)
        self.brush_offset.setDecimals(1)
        self.brush_offset.setSingleStep(1.0)
        self.brush_offset.setValue(0.0)
        self.brush_offset.setSuffix(" b")
        self.brush_offset.setToolTip("Moves the persistent free paint cursor up/down in world Y. Use Alt+Wheel or these Y+/Y- buttons without interfering with Shift camera descent.")
        self.btn_offset_closer = QtWidgets.QToolButton(); self.btn_offset_closer.setText("Y+"); self.btn_offset_closer.setAutoRepeat(True)
        self.btn_offset_farther = QtWidgets.QToolButton(); self.btn_offset_farther.setText("Y-"); self.btn_offset_farther.setAutoRepeat(True)
        self.btn_reset_brush_controls = QtWidgets.QPushButton("Reset brush controls")
        self.btn_reset_brush_controls.setToolTip("Return placement controls to a safe free-3D baseline: snap off, no axis lock, no mirror, manual align, zero Y offset.")

        tg.addWidget(QtWidgets.QLabel("Placement"), 0, 0)
        self.placement_label = QtWidgets.QLabel("Free 3D cursor")
        self.placement_label.setObjectName("StatusPill")
        tg.addWidget(self.placement_label, 0, 1)
        tg.addWidget(self.target_help, 1, 1, 1, 3)
        tg.addWidget(QtWidgets.QLabel("Axis lock"), 2, 0); tg.addWidget(self.axis_lock, 2, 1)
        tg.addWidget(QtWidgets.QLabel("Symmetry"), 2, 2); tg.addWidget(self.mirror, 2, 3)
        tg.addWidget(self.host_only, 3, 0, 1, 2)
        tg.addWidget(self.protect_surface, 3, 2); tg.addWidget(self.surface_margin, 3, 3)
        tg.addWidget(self.snap_to_surface, 4, 0, 1, 2)
        tg.addWidget(self.live_overlay, 4, 2, 1, 2)
        offset_tools = QtWidgets.QWidget()
        offset_lay = QtWidgets.QHBoxLayout(offset_tools)
        offset_lay.setContentsMargins(0, 0, 0, 0)
        offset_lay.setSpacing(6)
        offset_lay.addWidget(self.brush_offset, 1)
        offset_lay.addWidget(self.btn_offset_closer)
        offset_lay.addWidget(self.btn_offset_farther)
        tg.addWidget(QtWidgets.QLabel("Brush align"), 5, 0); tg.addWidget(self.align_mode, 5, 1)
        tg.addWidget(QtWidgets.QLabel("Brush roll"), 5, 2); tg.addWidget(self.brush_roll, 5, 3)
        tg.addWidget(QtWidgets.QLabel("Lock normal"), 6, 0); tg.addWidget(self.btn_realign, 6, 1)
        tg.addWidget(QtWidgets.QLabel("Height / depth Y"), 6, 2); tg.addWidget(offset_tools, 6, 3)
        tg.addWidget(self.btn_reset_brush_controls, 7, 1, 1, 3)
        quick_keys = QtWidgets.QLabel("Alt+Wheel or [ / ] = move brush Y level  •  Ctrl+Wheel or - / = brush size  •  Shift = camera down  •  Q/E = roll  •  \\ = reacquire brush level")
        quick_keys.setObjectName("SubtleHint")
        quick_keys.setWordWrap(True)
        tg.addWidget(QtWidgets.QLabel("Quick keys"), 8, 0)
        tg.addWidget(quick_keys, 8, 1, 1, 3)
        layout.addWidget(target)
        layout.addStretch(1)
        self.tabs.addTab(tab, "Placement")

    def _build_info_tab(self) -> None:
        tab = QtWidgets.QWidget()
        layout = QtWidgets.QVBoxLayout(tab)
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(8)
        info = QtWidgets.QGroupBox("Live paint info")
        ig = QtWidgets.QGridLayout(info)
        self.hover_label = QtWidgets.QLabel("Hover: --")
        self.stroke_label = QtWidgets.QLabel("Last stroke: none")
        self.shortcut_label = QtWidgets.QLabel(
            "Shortcuts: Axiom mode uses LMB camera rotate, RMB paint, MMB pick, WASD fly, Space up, Shift down | Alt+Wheel or [ / ] move brush Y | Ctrl+Wheel or - / = size | Q/E roll | Ctrl+RMB pan | Ctrl+Z undo layer stroke | Ctrl+Y redo | \\ reacquire Y | R re-align | F focus under cursor"
        )
        self.shortcut_label.setWordWrap(True)
        self.shortcut_label.setObjectName("SubtleHint")
        ig.addWidget(self.hover_label, 0, 0, 1, 2)
        ig.addWidget(self.stroke_label, 1, 0, 1, 2)
        ig.addWidget(self.shortcut_label, 2, 0, 1, 2)
        layout.addWidget(info)
        layout.addStretch(1)
        self.tabs.addTab(tab, "Info")

    def _settings_widgets(self) -> list[QtWidgets.QWidget]:
        return [
            self.paint_enabled, self.active_layer, self.brush_preset, self.action, self.material, self.shape,
            self.size_spin, self.strength_spin, self.spacing_spin, self.falloff, self.replace_mode,
            self.axis_lock, self.mirror, self.host_only, self.protect_surface, self.surface_margin,
            self.snap_to_surface, self.live_overlay, self.align_mode, self.brush_roll, self.brush_offset,
            self.preview_block_faces, self.typed_block,
        ]

    def settings(self) -> dict:
        return {
            "enabled": bool(self.paint_enabled.isChecked()),
            "active_layer": self.active_layer.currentText().strip() or "Paint Layer",
            "brush_preset": self.brush_preset.currentText(),
            "action": self.action.currentText(),
            "material": self.material.currentText().strip() or "minecraft:stone",
            "shape": self.shape.currentText(),
            "size_blocks": int(self.size_spin.value()),
            "strength_pct": int(self.strength_spin.value()),
            "spacing_pct_radius": int(self.spacing_spin.value()),
            "falloff": self.falloff.currentText(),
            "replace_mode": self.replace_mode.currentText(),
            "target_mode": "volume",
            "axis_lock": self.axis_lock.currentText(),
            "mirror": self.mirror.currentText(),
            "host_only": bool(self.host_only.isChecked()),
            "protect_surface": bool(self.protect_surface.isChecked()),
            "surface_margin": int(self.surface_margin.value()),
            "snap_to_surface": bool(self.snap_to_surface.isChecked()),
            "show_overlay": bool(self.live_overlay.isChecked()),
            "align_mode": self.align_mode.currentText(),
            "brush_roll_deg": int(self.brush_roll.value()),
            "brush_offset_blocks": float(self.brush_offset.value()),
            "preview_block_faces": bool(self.preview_block_faces.isChecked()),
        }

    @QtCore.Slot()
    def emit_paint_settings(self) -> None:
        self.selected_block_label.setText(self.material.currentText().strip() or "minecraft:stone")
        if self.typed_block.text().strip() != self.material.currentText().strip():
            self.typed_block.blockSignals(True)
            self.typed_block.setText(self.material.currentText().strip())
            self.typed_block.blockSignals(False)
        self.paint_settings_changed.emit(self.settings())

    @QtCore.Slot()
    def _on_add_layer(self) -> None:
        name = (self.active_layer.currentText() or "").strip() or "Paint Layer"
        self.active_layer.setEditText(name)
        if self.active_layer.findText(name) < 0:
            self.active_layer.insertItem(0, name)
            self.active_layer.setCurrentIndex(0)
        self.add_layer_requested.emit(name)
        self.emit_paint_settings()

    def _display_block_name(self, block: str) -> str:
        b = str(block or "").strip()
        if b.startswith("minecraft:"):
            short = b.split(":", 1)[1]
            return short.replace("_", " ").title() + f"  —  {b}"
        return b

    def select_block(self, block: str) -> None:
        """Public block-pick API used by the viewport's Axiom-style MMB picker."""
        self._select_block(block)

    def _select_block(self, block: str) -> None:
        block = (block or "minecraft:stone").strip()
        idx = self.material.findText(block)
        if idx < 0:
            self.material.insertItem(0, block)
            idx = 0
        self.material.setCurrentIndex(idx)
        self.selected_block_label.setText(block)
        self.typed_block.blockSignals(True)
        self.typed_block.setText(block)
        self.typed_block.blockSignals(False)
        for i in range(self.block_list.count()):
            item = self.block_list.item(i)
            if str(item.data(QtCore.Qt.ItemDataRole.UserRole) or item.text()) == block:
                self.block_list.setCurrentItem(item)
                break
        self.emit_paint_settings()

    def _apply_typed_block(self) -> None:
        block = self.typed_block.text().strip()
        if not block:
            return
        if ":" not in block:
            block = "minecraft:" + block
        self._select_block(block)

    def _copy_selected_block(self) -> None:
        QtWidgets.QApplication.clipboard().setText(self.material.currentText().strip() or "minecraft:stone")

    def _filter_block_list(self, text: str) -> None:
        self._updating_block_filter = True
        try:
            cur = self.material.currentText().strip()
            query = (text or "").lower().strip()
            cat = self.block_category.currentText() if hasattr(self, "block_category") else "All blocks"
            pred = self.CATEGORY_FILTERS.get(cat, self.CATEGORY_FILTERS["All blocks"])
            blocks = list(dict.fromkeys(self.COMMON_BLOCKS + [cur]))
            self.block_list.clear()
            for block in blocks:
                if not pred(block):
                    continue
                if query and query not in block.lower() and query not in self._display_block_name(block).lower():
                    continue
                item = QtWidgets.QListWidgetItem(self._display_block_name(block))
                item.setData(QtCore.Qt.ItemDataRole.UserRole, block)
                item.setToolTip(block)
                self.block_list.addItem(item)
                if block == cur:
                    self.block_list.setCurrentItem(item)
        finally:
            self._updating_block_filter = False

    def _on_block_list_selection(self) -> None:
        if self._updating_block_filter:
            return
        item = self.block_list.currentItem()
        if item is None:
            return
        self._select_block(str(item.data(QtCore.Qt.ItemDataRole.UserRole) or item.text()))

    def _on_brush_preset_changed(self, name: str) -> None:
        preset = dict(self.BRUSH_PRESETS.get(str(name), {}))
        if not preset:
            return
        self.apply_settings({**self.settings(), **preset, "brush_preset": name}, emit=True)

    def _nudge_brush_offset(self, delta: float) -> None:
        try:
            cur = float(self.brush_offset.value())
        except Exception:
            cur = 0.0
        self.brush_offset.setValue(max(self.brush_offset.minimum(), min(self.brush_offset.maximum(), cur + float(delta))))

    @QtCore.Slot()
    def _refresh_ui(self) -> None:
        act = self.action.currentText().lower()
        needs_material = "carve" not in act
        self.material.setEnabled(needs_material)
        self.block_list.setEnabled(needs_material)
        self.block_search.setEnabled(needs_material)
        self.block_category.setEnabled(needs_material)
        self.typed_block.setEnabled(needs_material)
        self.btn_apply_typed_block.setEnabled(needs_material)
        self.surface_margin.setEnabled(self.protect_surface.isChecked())
        self.host_only.setEnabled(("ore" in act) or ("replace" in act) or ("fill" in act))
        lock_mode = self.align_mode.currentText().lower().startswith("lock")
        self.btn_realign.setEnabled(lock_mode and self.paint_enabled.isChecked())
        if self.snap_to_surface.isChecked():
            self.placement_label.setText("Exact surface snap")
            self.target_help.setText("Exact surface snap is on: the brush follows the solid block under the mouse. Turn this off for depth-based volume painting.")
        else:
            self.placement_label.setText("Free 3D cursor")
            self.target_help.setText("Free 3D cursor is on: the brush is a persistent 3D gizmo inside the selected volume. Use the Y controls to move it up/down without surface snap.")
        self.btn_import_model.setDefault("stamp" in act)


    def _reset_brush_controls(self) -> None:
        self.axis_lock.setCurrentText("None")
        self.mirror.setCurrentText("None")
        self.snap_to_surface.setChecked(False)
        self.align_mode.setCurrentText("Manual (no auto align)")
        self.brush_roll.setValue(0)
        self.brush_offset.setValue(0.0)
        self.live_overlay.setChecked(True)
        self.emit_paint_settings()

    def select_or_create_layer(self, name: str, select_only: bool = False) -> None:
        name = (name or "Paint Layer").strip() or "Paint Layer"
        idx = self.active_layer.findText(name)
        if idx < 0:
            self.active_layer.insertItem(0, name)
            idx = self.active_layer.findText(name)
        if idx >= 0:
            self.active_layer.setCurrentIndex(idx)
        else:
            self.active_layer.setEditText(name)
        if not select_only:
            self.emit_paint_settings()

    def rename_layer_entry(self, old_name: str, new_name: str) -> None:
        old_name = (old_name or "").strip()
        new_name = (new_name or "").strip() or "Paint Layer"
        if not old_name:
            self.select_or_create_layer(new_name, select_only=False)
            return
        idx = self.active_layer.findText(old_name)
        if idx >= 0:
            self.active_layer.setItemText(idx, new_name)
            self.active_layer.setCurrentIndex(idx)
        elif self.active_layer.currentText().strip() == old_name:
            self.active_layer.setEditText(new_name)
        else:
            self.select_or_create_layer(new_name, select_only=False)
            return
        self.emit_paint_settings()

    def apply_settings(self, settings: dict, *, emit: bool = True) -> None:
        data = dict(settings or {})

        def _set_combo(combo: QtWidgets.QComboBox, value: object) -> None:
            text = str(value or "").strip()
            if combo.isEditable() and combo.findText(text) < 0 and text:
                combo.insertItem(0, text)
            idx = combo.findText(text)
            if idx >= 0:
                combo.setCurrentIndex(idx)
            elif combo.isEditable():
                combo.setEditText(text)

        widgets = self._settings_widgets()
        for w in widgets:
            w.blockSignals(True)
        try:
            self.paint_enabled.setChecked(bool(data.get("enabled", self.paint_enabled.isChecked())))
            _set_combo(self.active_layer, data.get("active_layer", self.active_layer.currentText()))
            _set_combo(self.brush_preset, data.get("brush_preset", self.brush_preset.currentText()))
            _set_combo(self.action, data.get("action", self.action.currentText()))
            _set_combo(self.material, data.get("material", self.material.currentText()))
            _set_combo(self.shape, data.get("shape", self.shape.currentText()))
            self.size_spin.setValue(max(self.size_spin.minimum(), min(self.size_spin.maximum(), int(data.get("size_blocks", self.size_spin.value())))))
            self.size.setValue(self.size_spin.value())
            self.strength_spin.setValue(max(self.strength_spin.minimum(), min(self.strength_spin.maximum(), int(data.get("strength_pct", self.strength_spin.value())))))
            self.strength.setValue(self.strength_spin.value())
            self.spacing_spin.setValue(max(self.spacing_spin.minimum(), min(self.spacing_spin.maximum(), int(data.get("spacing_pct_radius", self.spacing_spin.value())))))
            self.spacing.setValue(self.spacing_spin.value())
            _set_combo(self.falloff, data.get("falloff", self.falloff.currentText()))
            _set_combo(self.replace_mode, data.get("replace_mode", self.replace_mode.currentText()))
            _set_combo(self.axis_lock, data.get("axis_lock", self.axis_lock.currentText()))
            _set_combo(self.mirror, data.get("mirror", self.mirror.currentText()))
            self.host_only.setChecked(bool(data.get("host_only", self.host_only.isChecked())))
            self.protect_surface.setChecked(bool(data.get("protect_surface", self.protect_surface.isChecked())))
            self.surface_margin.setValue(max(self.surface_margin.minimum(), min(self.surface_margin.maximum(), int(data.get("surface_margin", self.surface_margin.value())))))
            self.snap_to_surface.setChecked(bool(data.get("snap_to_surface", self.snap_to_surface.isChecked())))
            self.live_overlay.setChecked(bool(data.get("show_overlay", self.live_overlay.isChecked())))
            _set_combo(self.align_mode, data.get("align_mode", self.align_mode.currentText()))
            self.brush_roll.setValue(max(self.brush_roll.minimum(), min(self.brush_roll.maximum(), int(round(float(data.get("brush_roll_deg", self.brush_roll.value())))))))
            self.brush_offset.setValue(max(self.brush_offset.minimum(), min(self.brush_offset.maximum(), float(data.get("brush_offset_blocks", self.brush_offset.value())))))
            self.preview_block_faces.setChecked(bool(data.get("preview_block_faces", self.preview_block_faces.isChecked())))
            self.typed_block.setText(self.material.currentText().strip() or "minecraft:stone")
        finally:
            for w in widgets:
                w.blockSignals(False)
        self.selected_block_label.setText(self.material.currentText().strip() or "minecraft:stone")
        self._filter_block_list(self.block_search.text())
        self._refresh_ui()
        if emit:
            self.emit_paint_settings()

    def set_hover_info(self, info: dict | None) -> None:
        if not info or not info.get("valid"):
            self.hover_label.setText("Hover: --")
            return
        x = info.get("x"); y = info.get("y"); z = info.get("z")
        mode = "3D brush cursor"
        resolved = info.get("resolved_pick")
        if resolved and str(resolved) == "surface":
            mode = "Exact surface snap"
        bsz = info.get("brush_size")
        roll = info.get("brush_roll_deg")
        offset = info.get("brush_offset_blocks")
        align_mode = info.get("align_mode")
        try:
            if bsz is not None and self.size_spin.value() != int(bsz):
                self.size_spin.blockSignals(True); self.size.blockSignals(True)
                self.size_spin.setValue(max(self.size_spin.minimum(), min(self.size_spin.maximum(), int(bsz))))
                self.size.setValue(self.size_spin.value())
                self.size.blockSignals(False); self.size_spin.blockSignals(False)
        except Exception:
            pass
        try:
            if roll is not None and self.brush_roll.value() != int(round(float(roll))):
                self.brush_roll.blockSignals(True)
                self.brush_roll.setValue(max(self.brush_roll.minimum(), min(self.brush_roll.maximum(), int(round(float(roll))))))
                self.brush_roll.blockSignals(False)
        except Exception:
            pass
        try:
            if offset is not None and abs(self.brush_offset.value() - float(offset)) > 1e-6:
                self.brush_offset.blockSignals(True)
                self.brush_offset.setValue(max(self.brush_offset.minimum(), min(self.brush_offset.maximum(), float(offset))))
                self.brush_offset.blockSignals(False)
        except Exception:
            pass
        extra = []
        if bsz is not None:
            extra.append(f"brush={int(bsz)}b")
        if offset is not None:
            extra.append(f"Y-offset={float(offset):.1f}b")
        if roll is not None:
            extra.append(f"roll={int(round(float(roll)))}°")
        am = str(align_mode or "manual").lower()
        if am.startswith("follow") or am.startswith("auto"):
            extra.append("align=follow")
        elif am.startswith("lock"):
            extra.append("align=lock")
        else:
            extra.append("align=manual")
        suffix = ("  " + "  ".join(extra)) if extra else ""
        self.hover_label.setText(f"Hover: ({x}, {y}, {z})  [{mode}]" + suffix)

    def set_stroke_info(self, info: dict | None) -> None:
        if not info:
            self.stroke_label.setText("Last stroke: none")
            return
        n = int(info.get("point_count", 0))
        layer = str(info.get("active_layer", "Paint Layer"))
        bbox = info.get("bbox")
        if bbox and len(bbox) == 6:
            self.stroke_label.setText(f"Last stroke: {n} samples on '{layer}'  bbox=({bbox[0]},{bbox[1]},{bbox[2]})→({bbox[3]},{bbox[4]},{bbox[5]})")
        else:
            self.stroke_label.setText(f"Last stroke: {n} samples on '{layer}'")
