from __future__ import annotations

from PySide6 import QtCore

from ..world.exporter import IncrementalExportOptions, export_paint_layers_incremental


class IncrementalExportWorker(QtCore.QObject):
    """Run copying and changed-region export off the GUI thread."""

    stage = QtCore.Signal(str)
    progress = QtCore.Signal(int, str)
    finished = QtCore.Signal(object)
    failed = QtCore.Signal(str)

    def __init__(self, options: IncrementalExportOptions) -> None:
        super().__init__()
        self.options = options

    @QtCore.Slot()
    def run(self) -> None:
        try:
            self.options.progress = lambda pct, msg: self.progress.emit(int(pct), str(msg))
            if str(self.options.destination_mode).lower() == "copy":
                self.stage.emit("Preparing independent world copy and edit plan…")
            else:
                self.stage.emit("Preparing in-place edit plan…")
            report = export_paint_layers_incremental(self.options)
        except Exception as exc:
            self.failed.emit(str(exc))
        else:
            self.finished.emit(report)
