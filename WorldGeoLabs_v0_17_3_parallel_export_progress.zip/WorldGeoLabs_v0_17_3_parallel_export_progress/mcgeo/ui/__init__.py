"""Qt UI package for WorldGeoLabs."""
