"""Whole-world geological interpretation and resource-generation subsystem."""

from .profile import WorldGeologyProfile, DepositProfile
from .world_model import build_world_geology_fields
from .deposits import GeologicalResourceGenerator, ResourceGenerationOptions, ResourceGenerationReport

__all__ = [
    "WorldGeologyProfile", "DepositProfile", "build_world_geology_fields",
    "GeologicalResourceGenerator", "ResourceGenerationOptions", "ResourceGenerationReport",
]
