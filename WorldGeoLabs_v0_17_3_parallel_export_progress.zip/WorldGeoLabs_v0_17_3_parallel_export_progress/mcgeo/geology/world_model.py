from __future__ import annotations

from typing import Any
import math
import numpy as np

from .profile import WorldGeologyProfile


def _finite_fill(a: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    arr = np.asarray(a, dtype=np.float32)
    valid = np.isfinite(arr)
    if not np.any(valid):
        return np.zeros(arr.shape, dtype=np.float32), valid
    med = float(np.nanmedian(arr[valid]))
    return np.where(valid, arr, med).astype(np.float32, copy=False), valid


def _robust01(a: np.ndarray, valid: np.ndarray | None = None, low: float = 2.0, high: float = 98.0) -> np.ndarray:
    arr = np.asarray(a, dtype=np.float32)
    if valid is None:
        valid = np.isfinite(arr)
    out = np.zeros(arr.shape, dtype=np.float32)
    if not np.any(valid):
        return out
    lo, hi = np.nanpercentile(arr[valid], [low, high])
    if not np.isfinite(lo):
        lo = float(np.nanmin(arr[valid]))
    if not np.isfinite(hi) or hi <= lo:
        hi = lo + 1.0
    out[valid] = np.clip((arr[valid] - lo) / (hi - lo), 0.0, 1.0)
    return out


def _box_blur(a: np.ndarray, radius: int) -> np.ndarray:
    """Separable edge-padded box blur using cumulative sums (NumPy only)."""
    radius = max(0, int(radius))
    arr = np.asarray(a, dtype=np.float32)
    if radius <= 0:
        return arr.copy()
    width = radius * 2 + 1
    # horizontal
    p = np.pad(arr, ((0, 0), (radius, radius)), mode="edge")
    cs = np.cumsum(p, axis=1, dtype=np.float64)
    cs = np.pad(cs, ((0, 0), (1, 0)), mode="constant")
    h = ((cs[:, width:] - cs[:, :-width]) / float(width)).astype(np.float32)
    # vertical
    p = np.pad(h, ((radius, radius), (0, 0)), mode="edge")
    cs = np.cumsum(p, axis=0, dtype=np.float64)
    cs = np.pad(cs, ((1, 0), (0, 0)), mode="constant")
    return ((cs[width:, :] - cs[:-width, :]) / float(width)).astype(np.float32)


def _category_mask(category_grid: np.ndarray, index_by_id: dict[str, int], ids: tuple[str, ...] | list[str]) -> np.ndarray:
    out = np.zeros(category_grid.shape, dtype=np.float32)
    for category_id in ids:
        idx = index_by_id.get(str(category_id))
        if idx is not None:
            out[np.asarray(category_grid) == int(idx)] = 1.0
    return out


def _write(cache, name: str, data: np.ndarray) -> np.memmap:
    mm = cache.create_array(name, data.shape, "float32", fill=0.0, nodata=0.0)
    mm[...] = np.asarray(data, dtype=np.float32)
    mm.flush()
    return mm


def build_world_geology_fields(
    *,
    cache,
    surface_height: np.ndarray,
    slope_degrees: np.ndarray,
    flow_accumulation: np.ndarray,
    water_level: np.ndarray,
    geology_category: np.ndarray,
    categories: list[dict[str, Any]],
    effective_step: int,
    origin: tuple[int, int],
    profile: WorldGeologyProfile,
) -> dict[str, Any]:
    """Infer terrain-scale geological history proxies from the analyzed world.

    These are *interpretive* fields, not claims about actual Earth history. They give
    deposit rules reusable signals such as uplift, sedimentary basin, erosion,
    structural fracture, hydrothermal activity, paleo-organic basin potential and
    placer concentration potential.
    """
    height, valid = _finite_fill(surface_height)
    slope = np.nan_to_num(np.asarray(slope_degrees, dtype=np.float32), nan=0.0)
    flow = np.nan_to_num(np.asarray(flow_accumulation, dtype=np.float32), nan=0.0)
    cats = np.asarray(geology_category)
    index_by_id = {str(item.get("id")): int(item.get("index", i)) for i, item in enumerate(categories or [])}

    step = max(1, int(effective_step))
    smooth_radius = max(1, int(round(profile.terrain_smoothing_blocks / step / 2.0)))
    # Cap the kernel on extremely detailed full-world grids to avoid a needlessly
    # enormous blur while preserving broad landform interpretation.
    smooth_radius = min(smooth_radius, 96)
    local_mean = _box_blur(height, smooth_radius)
    residual = height - local_mean
    abs_residual = np.abs(residual)

    elevation = _robust01(height, valid)
    relief = _robust01(abs_residual, valid)
    convex = _robust01(np.maximum(residual, 0.0), valid)
    concave = _robust01(np.maximum(-residual, 0.0), valid)
    slope_n = np.clip(slope / float(profile.slope_reference_degrees), 0.0, 1.0).astype(np.float32)
    flow_log = np.log1p(np.maximum(flow, 0.0)).astype(np.float32)
    flow_n = _robust01(flow_log, valid)

    sedimentary = _category_mask(cats, index_by_id, ["sedimentary", "carbonate", "loose_sediment", "clay_mud"])
    organic_surface = _category_mask(cats, index_by_id, ["organic_soil", "vegetation", "soil", "clay_mud"])
    igneous = _category_mask(cats, index_by_id, ["intrusive_igneous", "volcanic"])
    metamorphic = _category_mask(cats, index_by_id, ["metamorphic_deep"])
    generic_rock = _category_mask(cats, index_by_id, ["generic_rock"])

    water = np.asarray(water_level)
    water_present = (water > -32000).astype(np.float32)
    water_radius = max(1, min(48, int(round(192.0 / step))))
    water_near = np.clip(_box_blur(water_present, water_radius) * 4.0, 0.0, 1.0)

    low_slope = 1.0 - slope_n
    lowland = 1.0 - elevation
    uplift = np.clip(0.42 * elevation + 0.28 * relief + 0.20 * convex + 0.10 * slope_n, 0.0, 1.0)
    basin = np.clip(0.34 * concave + 0.24 * lowland + 0.18 * low_slope + 0.16 * sedimentary + 0.08 * water_near, 0.0, 1.0)
    erosion = np.clip(0.44 * slope_n + 0.24 * relief + 0.22 * flow_n + 0.10 * uplift, 0.0, 1.0)

    # Deterministic synthetic structural lineaments. Their influence is strongest
    # in rugged/orogenic terrain, producing faults/veins that bend across the map
    # rather than axis-aligned random ore clouds.
    rows, cols = height.shape
    x0, z0 = int(origin[0]), int(origin[1])
    xs = x0 + np.arange(cols, dtype=np.float32) * float(step)
    zs = z0 + np.arange(rows, dtype=np.float32) * float(step)
    seed = int(profile.seed) & 0xFFFFFFFF
    angle1 = math.radians(18.0 + (seed % 61))
    angle2 = angle1 + math.radians(63.0)
    spacing = float(profile.fault_spacing_blocks)
    width = max(float(step), float(profile.fault_width_blocks))

    def line_family(angle: float, phase: float) -> np.ndarray:
        coord = (np.cos(angle) * xs[None, :] + np.sin(angle) * zs[:, None] + phase)
        # Distance to nearest periodic line in world-block units.
        folded = np.abs(((coord + spacing * 0.5) % spacing) - spacing * 0.5)
        return np.exp(-np.square(folded / width)).astype(np.float32)

    fault_base = np.maximum(
        line_family(angle1, float((seed * 1103515245 + 12345) & 0xFFFF)),
        line_family(angle2, float((seed * 2654435761) & 0xFFFF)),
    )
    fracture = np.clip(fault_base * (0.38 + 0.42 * uplift + 0.20 * relief), 0.0, 1.0)

    hydrothermal = np.clip(fracture * (0.35 + 0.42 * igneous + 0.23 * uplift), 0.0, 1.0)
    paleo_organic = np.clip(
        0.35 * basin + 0.20 * sedimentary + 0.20 * low_slope + 0.15 * water_near + 0.10 * organic_surface,
        0.0, 1.0,
    )
    placer = np.clip(flow_n * (0.35 + 0.45 * erosion + 0.20 * low_slope), 0.0, 1.0)
    orogenic = np.clip(0.55 * uplift + 0.25 * fracture + 0.20 * metamorphic, 0.0, 1.0)
    stable_craton = np.clip((0.55 * metamorphic + 0.30 * generic_rock + 0.15 * low_slope) * (1.0 - 0.45 * igneous), 0.0, 1.0)

    # Folded strata displacement: broad sinusoidal layers are amplified in uplifted
    # terrain and subside in interpreted basins. Deposit seam/vein geometry can use
    # this Y offset so geology visibly waves through mountain belts.
    wave1 = (
        np.cos(angle1) * xs[None, :] + np.sin(angle1) * zs[:, None]
    ) / float(profile.structural_wavelength_blocks)
    wave2 = (
        np.cos(angle2) * xs[None, :] + np.sin(angle2) * zs[:, None]
    ) / float(profile.structural_secondary_wavelength_blocks)
    warp = profile.structural_amplitude_blocks * (
        0.70 * np.sin(wave1 * math.tau + (seed % 113) * 0.031)
        + 0.30 * np.sin(wave2 * math.tau + (seed % 47) * 0.071)
    )
    warp = (warp * (0.20 + 0.80 * uplift) - basin * profile.structural_amplitude_blocks * 0.35).astype(np.float32)

    fields = {
        "uplift_score": uplift,
        "basin_score": basin,
        "erosion_score": erosion,
        "fracture_score": fracture,
        "hydrothermal_score": hydrothermal,
        "paleo_organic_score": paleo_organic,
        "placer_score": placer,
        "orogenic_score": orogenic,
        "stable_craton_score": stable_craton,
        "structural_warp_blocks": warp,
    }
    for name, data in fields.items():
        data = np.asarray(data, dtype=np.float32)
        data[~valid] = 0.0
        _write(cache, name, data)

    return {
        "geology_profile": str(profile.path),
        "geology_profile_id": profile.profile_id,
        "geology_profile_fingerprint": profile.fingerprint(),
        "terrain_smoothing_radius_cells": smooth_radius,
        "mean_uplift_score": float(np.mean(uplift[valid])) if np.any(valid) else 0.0,
        "mean_basin_score": float(np.mean(basin[valid])) if np.any(valid) else 0.0,
        "mean_erosion_score": float(np.mean(erosion[valid])) if np.any(valid) else 0.0,
        "mean_fracture_score": float(np.mean(fracture[valid])) if np.any(valid) else 0.0,
        "mean_paleo_organic_score": float(np.mean(paleo_organic[valid])) if np.any(valid) else 0.0,
        "mean_placer_score": float(np.mean(placer[valid])) if np.any(valid) else 0.0,
        "structural_warp_min": float(np.min(warp[valid])) if np.any(valid) else 0.0,
        "structural_warp_max": float(np.max(warp[valid])) if np.any(valid) else 0.0,
    }
