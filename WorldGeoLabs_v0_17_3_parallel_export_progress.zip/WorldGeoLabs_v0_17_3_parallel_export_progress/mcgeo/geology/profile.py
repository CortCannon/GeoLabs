from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
import hashlib
import json
try:
    import tomllib
except ImportError:  # pragma: no cover
    import tomli as tomllib


@dataclass(frozen=True)
class FactorWeight:
    name: str
    weight: float


@dataclass(frozen=True)
class DepositProfile:
    id: str
    label: str
    enabled: bool
    material: str
    shape: str
    density_per_million_blocks2: float
    min_count: int
    max_count: int
    min_spacing_blocks: float
    score_threshold: float
    size_min: float
    size_max: float
    thickness_min: float
    thickness_max: float
    length_min: float
    length_max: float
    depth_min: float
    depth_max: float
    depth_reference: str
    strength_pct: int
    protect_surface: bool
    surface_margin: int
    host_only: bool
    replace_only: tuple[str, ...]
    host_categories: tuple[str, ...]
    weights: tuple[FactorWeight, ...]
    notes: str = ""


@dataclass(frozen=True)
class WorldGeologyProfile:
    path: Path
    profile_id: str
    description: str
    seed: int
    population_scale: float
    structural_wavelength_blocks: float
    structural_secondary_wavelength_blocks: float
    structural_amplitude_blocks: float
    fault_spacing_blocks: float
    fault_width_blocks: float
    terrain_smoothing_blocks: float
    slope_reference_degrees: float
    deposits: dict[str, DepositProfile] = field(default_factory=dict)

    @classmethod
    def load(cls, path: Path) -> "WorldGeologyProfile":
        path = Path(path)
        raw = tomllib.loads(path.read_text(encoding="utf-8"))
        p = dict(raw.get("profile") or {})
        structure = dict(raw.get("structure") or {})
        defaults = dict(raw.get("deposit_defaults") or {})
        deposits: dict[str, DepositProfile] = {}
        for deposit_id, value in dict(raw.get("deposits") or {}).items():
            d = dict(defaults)
            d.update(dict(value or {}))
            weight_table = dict(d.pop("weights", {}) or {})
            # TOML nested tables are removed from the scalar table by tomllib only
            # when authored as [deposits.foo.weights]; support both representations.
            original = dict(value or {})
            if isinstance(original.get("weights"), dict):
                weight_table.update(original.get("weights") or {})
            deposits[str(deposit_id)] = DepositProfile(
                id=str(deposit_id),
                label=str(d.get("label") or str(deposit_id).replace("_", " ").title()),
                enabled=bool(d.get("enabled", True)),
                material=_block_id(d.get("material", f"minecraft:{deposit_id}_ore")),
                shape=str(d.get("shape") or "blob").strip().lower(),
                density_per_million_blocks2=max(0.0, float(d.get("density_per_million_blocks2", 2.0))),
                min_count=max(0, int(d.get("min_count", 0))),
                max_count=max(0, int(d.get("max_count", 1000000))),
                min_spacing_blocks=max(1.0, float(d.get("min_spacing_blocks", 96.0))),
                score_threshold=max(0.0, min(1.0, float(d.get("score_threshold", 0.42)))),
                size_min=max(1.0, float(d.get("size_min", 4.0))),
                size_max=max(1.0, float(d.get("size_max", 16.0))),
                thickness_min=max(1.0, float(d.get("thickness_min", 1.0))),
                thickness_max=max(1.0, float(d.get("thickness_max", 4.0))),
                length_min=max(1.0, float(d.get("length_min", 16.0))),
                length_max=max(1.0, float(d.get("length_max", 96.0))),
                depth_min=float(d.get("depth_min", 8.0)),
                depth_max=float(d.get("depth_max", 160.0)),
                depth_reference=str(d.get("depth_reference") or "below_surface").strip().lower(),
                strength_pct=max(1, min(100, int(d.get("strength_pct", 85)))),
                protect_surface=bool(d.get("protect_surface", True)),
                surface_margin=max(0, int(d.get("surface_margin", 6))),
                host_only=bool(d.get("host_only", True)),
                replace_only=tuple(_block_id(x) for x in (d.get("replace_only") or [])),
                host_categories=tuple(str(x) for x in (d.get("host_categories") or [])),
                weights=tuple(
                    FactorWeight(str(name), float(weight))
                    for name, weight in sorted(weight_table.items())
                ),
                notes=str(d.get("notes") or ""),
            )

        return cls(
            path=path,
            profile_id=str(p.get("id") or "worldgeolabs_default_geology"),
            description=str(p.get("description") or ""),
            seed=int(p.get("seed", 1337)),
            population_scale=max(0.0, float(p.get("population_scale", 1.0))),
            structural_wavelength_blocks=max(64.0, float(structure.get("fold_wavelength_blocks", 1400.0))),
            structural_secondary_wavelength_blocks=max(32.0, float(structure.get("secondary_fold_wavelength_blocks", 480.0))),
            structural_amplitude_blocks=max(0.0, float(structure.get("fold_amplitude_blocks", 96.0))),
            fault_spacing_blocks=max(64.0, float(structure.get("fault_spacing_blocks", 1800.0))),
            fault_width_blocks=max(8.0, float(structure.get("fault_width_blocks", 90.0))),
            terrain_smoothing_blocks=max(32.0, float(structure.get("terrain_smoothing_blocks", 256.0))),
            slope_reference_degrees=max(1.0, float(structure.get("slope_reference_degrees", 38.0))),
            deposits=deposits,
        )

    def fingerprint(self) -> str:
        return hashlib.sha256(self.path.read_bytes()).hexdigest()[:24]

    def serializable_deposits(self) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for dep in self.deposits.values():
            out.append({
                "id": dep.id,
                "label": dep.label,
                "enabled": dep.enabled,
                "material": dep.material,
                "shape": dep.shape,
                "density_per_million_blocks2": dep.density_per_million_blocks2,
                "score_threshold": dep.score_threshold,
                "weights": {w.name: w.weight for w in dep.weights},
                "notes": dep.notes,
            })
        return out


def _block_id(value: Any) -> str:
    text = str(value or "minecraft:stone").strip().lower()
    return text if ":" in text else f"minecraft:{text}"
