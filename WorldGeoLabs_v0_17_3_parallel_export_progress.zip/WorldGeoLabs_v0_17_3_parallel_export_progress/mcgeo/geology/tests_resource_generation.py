from __future__ import annotations

import tempfile
from pathlib import Path

from ..analysis.engine import AnalysisOptions, GeologicalAnalyzer
from ..world.exporter import IncrementalExportOptions, export_paint_layers_incremental
from ..world.tests_exporter_roundtrip import _make_world
from .deposits import GeologicalResourceGenerator, ResourceGenerationOptions


def run() -> None:
    with tempfile.TemporaryDirectory(prefix="wgl_geology_resource_test_") as td:
        root = Path(td)
        world = _make_world(root)
        profile = root / "test_geology.toml"
        profile.write_text(
            '''
[profile]
id = "test"
seed = 99
population_scale = 1.0

[structure]
fold_wavelength_blocks = 128
secondary_fold_wavelength_blocks = 64
fold_amplitude_blocks = 8
fault_spacing_blocks = 96
fault_width_blocks = 16
terrain_smoothing_blocks = 32
slope_reference_degrees = 35

[deposit_defaults]
min_count = 0
max_count = 100
min_spacing_blocks = 1
score_threshold = 0
size_min = 3
size_max = 3
thickness_min = 2
thickness_max = 2
length_min = 8
length_max = 8
depth_min = 2
depth_max = 2
depth_reference = "below_surface"
strength_pct = 100
protect_surface = false
surface_margin = 0
host_only = false

[deposits.test_iron]
label = "Test Iron"
material = "minecraft:iron_ore"
shape = "blob"
density_per_million_blocks2 = 0
min_count = 2
replace_only = ["minecraft:stone"]

[deposits.test_iron.weights]
base = 1.0
''',
            encoding="utf-8",
        )
        report = GeologicalAnalyzer(AnalysisOptions(
            world_path=world,
            chunk_bounds=(0, 0, 0, 0),
            height_range=(0, 16),
            requested_step=8,
            verification_step=16,
            source_mode="minecraft",
            geology_profile=profile,
            force_rebuild=True,
        )).run()
        generated = GeologicalResourceGenerator(ResourceGenerationOptions(
            manifest_path=report.manifest_path,
            profile_path=profile,
            seed=99,
            population_scale=1.0,
        )).run()
        assert generated.deposit_counts["test_iron"] >= 1
        assert generated.stroke_counts["test_iron"] >= 1
        assert generated.paint_layers
        dst = root / "GeologyExport"
        exported = export_paint_layers_incremental(IncrementalExportOptions(
            world_path=world,
            paint_layers=list(generated.paint_layers.values()),
            destination_mode="copy",
            destination_path=dst,
            verify_after_write=True,
            edit_area_chunk_bounds=(0, 0, 0, 0),
        ))
        assert exported.changed_blocks > 0, exported.summary_text()
        assert exported.verified_chunks > 0, exported.summary_text()
        assert generated.plan_path.is_file()
    print("Whole-world geology/resource generation test OK")


if __name__ == "__main__":
    run()
