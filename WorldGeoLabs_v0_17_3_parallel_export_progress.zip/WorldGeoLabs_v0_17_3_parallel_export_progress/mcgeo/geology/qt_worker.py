from __future__ import annotations

from threading import Event
from PySide6 import QtCore

from .deposits import (
    GeologicalResourceGenerator,
    GeologicalResourceGenerationCancelled,
    ResourceGenerationOptions,
)


class GeologicalResourceWorker(QtCore.QObject):
    progress = QtCore.Signal(int, str)
    finished = QtCore.Signal(object)
    failed = QtCore.Signal(str)
    cancelled = QtCore.Signal()

    def __init__(self, options: ResourceGenerationOptions, cancel_event: Event) -> None:
        super().__init__()
        self.options = options
        self.cancel_event = cancel_event

    @QtCore.Slot()
    def run(self) -> None:
        generator = GeologicalResourceGenerator(
            self.options,
            progress=lambda pct, msg: self.progress.emit(int(pct), str(msg)),
            cancelled=self.cancel_event.is_set,
        )
        try:
            report = generator.run()
        except GeologicalResourceGenerationCancelled:
            self.cancelled.emit()
        except Exception as exc:
            self.failed.emit(str(exc))
        else:
            self.finished.emit(report)
        finally:
            generator.close()
