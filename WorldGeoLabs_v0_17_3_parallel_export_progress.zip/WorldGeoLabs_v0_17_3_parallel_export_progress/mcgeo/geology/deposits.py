from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable
import hashlib
import json
import math
import os
import sqlite3
import time

import numpy as np

from .profile import DepositProfile, WorldGeologyProfile

ProgressCallback = Callable[[int, str], None]
CancelCallback = Callable[[], bool]


@dataclass(frozen=True)
class ResourceGenerationOptions:
    manifest_path: Path
    profile_path: Path
    seed: int | None = None
    population_scale: float = 1.0
    enabled_deposits: tuple[str, ...] | None = None
    write_suitability_arrays: bool = True


@dataclass(frozen=True)
class ResourceGenerationReport:
    plan_path: Path
    manifest_path: Path
    profile_path: Path
    elapsed_seconds: float
    seed: int
    deposit_counts: dict[str, int]
    stroke_counts: dict[str, int]
    paint_layers: dict[str, dict[str, Any]]
    summary: dict[str, Any]


class GeologicalResourceGenerationCancelled(RuntimeError):
    pass


class GeologicalResourceGenerator:
    OFFSETS = [
        (-1, 0), (-1, 1), (0, 1), (1, 1),
        (1, 0), (1, -1), (0, -1), (-1, -1),
    ]

    def __init__(
        self,
        options: ResourceGenerationOptions,
        *,
        progress: ProgressCallback | None = None,
        cancelled: CancelCallback | None = None,
    ) -> None:
        self.options = options
        self.progress = progress or (lambda _pct, _msg: None)
        self.cancelled = cancelled or (lambda: False)
        self.profile = WorldGeologyProfile.load(Path(options.profile_path))
        self.manifest_path = Path(options.manifest_path)
        self.manifest = json.loads(self.manifest_path.read_text(encoding="utf-8"))
        self.root = self.manifest_path.parent
        self.arrays = dict(self.manifest.get("arrays") or {})
        self.step = max(1, int(self.manifest.get("effective_step", 8)))
        self.origin = tuple(int(v) for v in (self.manifest.get("origin") or [0, 0]))
        self.height_range = tuple(int(v) for v in (self.manifest.get("height_range") or [-64, 320]))
        self.seed = int(options.seed if options.seed is not None else self.profile.seed)
        self.rng = np.random.default_rng(self.seed & 0xFFFFFFFFFFFFFFFF)
        self._opened: dict[str, np.memmap] = {}
        self._section_db: sqlite3.Connection | None = None
        self._section_db_path: Path | None = None
        section_name = str((self.manifest.get("summary") or {}).get("section_database") or "").strip()
        if section_name:
            candidate = self.root / section_name
            if candidate.is_file():
                self._section_db_path = candidate

    def _emit(self, pct: int, message: str) -> None:
        if self.cancelled():
            raise GeologicalResourceGenerationCancelled("Geological resource generation cancelled")
        self.progress(max(0, min(100, int(pct))), str(message))

    def close(self) -> None:
        if self._section_db is not None:
            try:
                self._section_db.close()
            finally:
                self._section_db = None
        self._opened.clear()

    def _array(self, name: str) -> np.ndarray:
        if name in self._opened:
            return self._opened[name]
        spec = dict(self.arrays.get(name) or {})
        if not spec:
            raise KeyError(f"Analysis array is missing: {name}")
        arr = np.memmap(
            self.root / str(spec["file"]),
            mode="r",
            dtype=np.dtype(str(spec["dtype"])),
            shape=tuple(int(v) for v in spec["shape"]),
        )
        self._opened[name] = arr
        return arr

    @staticmethod
    def _normalise(a: np.ndarray, valid: np.ndarray | None = None) -> np.ndarray:
        a = np.asarray(a, dtype=np.float32)
        if valid is None:
            valid = np.isfinite(a)
        out = np.zeros(a.shape, dtype=np.float32)
        if not np.any(valid):
            return out
        lo, hi = np.nanpercentile(a[valid], [2.0, 98.0])
        if not np.isfinite(lo):
            lo = float(np.nanmin(a[valid]))
        if not np.isfinite(hi) or hi <= lo:
            hi = lo + 1.0
        out[valid] = np.clip((a[valid] - lo) / (hi - lo), 0.0, 1.0)
        return out

    def _factor_fields(self) -> dict[str, np.ndarray]:
        height = np.asarray(self._array("surface_height"), dtype=np.float32)
        valid = np.isfinite(height)
        slope = np.nan_to_num(np.asarray(self._array("slope_degrees"), dtype=np.float32), nan=0.0)
        flow = np.nan_to_num(np.asarray(self._array("flow_accumulation"), dtype=np.float32), nan=0.0)
        fields: dict[str, np.ndarray] = {
            "base": np.ones(height.shape, dtype=np.float32),
            "elevation": self._normalise(height, valid),
            "slope": np.clip(slope / 40.0, 0.0, 1.0).astype(np.float32),
            "flow": self._normalise(np.log1p(np.maximum(flow, 0.0)), valid),
        }
        for name in (
            "uplift_score", "basin_score", "erosion_score", "fracture_score",
            "hydrothermal_score", "paleo_organic_score", "placer_score",
            "orogenic_score", "stable_craton_score",
        ):
            if name in self.arrays:
                fields[name.removesuffix("_score")] = np.asarray(self._array(name), dtype=np.float32)
        fields["low_slope"] = 1.0 - fields["slope"]
        fields["lowland"] = 1.0 - fields["elevation"]
        fields["valid"] = valid.astype(np.float32)
        return fields

    def _host_factor(self, dep: DepositProfile) -> np.ndarray:
        grid = np.asarray(self._array("geology_category"))
        if not dep.host_categories:
            return np.ones(grid.shape, dtype=np.float32)
        categories = list(self.manifest.get("categories") or [])
        ids = {str(c.get("id")): int(c.get("index", i)) for i, c in enumerate(categories)}
        out = np.zeros(grid.shape, dtype=np.float32)
        for category_id in dep.host_categories:
            idx = ids.get(category_id)
            if idx is not None:
                out[grid == int(idx)] = 1.0
        # Analysis samples can be sparse. Unknown host cells remain possible but less preferred.
        out[grid < 0] = 0.35
        return out

    def _score(self, dep: DepositProfile, fields: dict[str, np.ndarray]) -> np.ndarray:
        valid = fields["valid"] > 0.5
        host = self._host_factor(dep)
        numer = np.zeros(host.shape, dtype=np.float32)
        denom = 0.0
        if dep.weights:
            for item in dep.weights:
                factor = fields.get(item.name)
                if factor is None:
                    continue
                w = float(item.weight)
                if w >= 0:
                    numer += np.float32(w) * np.asarray(factor, dtype=np.float32)
                    denom += abs(w)
                else:
                    numer += np.float32(abs(w)) * (1.0 - np.asarray(factor, dtype=np.float32))
                    denom += abs(w)
        else:
            numer += 1.0
            denom = 1.0
        score = numer / max(1e-6, denom)
        # Host compatibility is a soft gate rather than a binary one because the
        # whole-world analysis intentionally samples Minecraft host rock sparsely.
        score *= (0.25 + 0.75 * host)
        score[~valid] = 0.0
        return np.clip(score, 0.0, 1.0).astype(np.float32)

    def _write_suitability(self, deposit_id: str, score: np.ndarray) -> dict[str, Any]:
        safe = "".join(c if c.isalnum() or c in "._-" else "_" for c in deposit_id)
        name = f"resource_{safe}_suitability"
        file_rel = Path("arrays") / f"{name}.dat"
        path = self.root / file_rel
        mm = np.memmap(path, mode="w+", dtype=np.dtype("float16"), shape=score.shape)
        mm[...] = score.astype(np.float16)
        mm.flush()
        del mm
        spec = {
            "name": name,
            "dtype": np.dtype("float16").str,
            "shape": [int(v) for v in score.shape],
            "file": str(file_rel),
            "nodata": 0.0,
        }
        self.arrays[name] = spec
        return spec

    def _desired_count(self, dep: DepositProfile, shape: tuple[int, int], valid_cells: int | None = None) -> int:
        # Population is based on *existing Minecraft terrain area*, not the
        # rectangular analysis envelope.  This prevents void borders/holes from
        # inflating deposit populations.
        if valid_cells is None:
            valid_cells = int(shape[0] * shape[1])
        area_blocks2 = float(max(0, int(valid_cells))) * float(self.step * self.step)
        count = int(round(
            area_blocks2 / 1_000_000.0
            * dep.density_per_million_blocks2
            * self.profile.population_scale
            * max(0.0, float(self.options.population_scale))
        ))
        count = max(dep.min_count, count)
        if dep.max_count > 0:
            count = min(dep.max_count, count)
        return max(0, count)

    def _select_centres(self, dep: DepositProfile, score: np.ndarray, desired: int) -> list[tuple[int, int, float]]:
        if desired <= 0:
            return []
        flat = score.ravel()
        eligible = np.flatnonzero(flat >= np.float32(dep.score_threshold))
        # min_count is a true population floor where the analysis contains any
        # plausible cells. If an aggressive suitability threshold leaves too few
        # candidates, supplement it with the best non-zero cells rather than
        # silently producing no examples of a configured rare resource.
        if eligible.size < int(dep.min_count):
            plausible = np.flatnonzero(flat > 0.0)
            if plausible.size:
                need_pool = min(plausible.size, max(int(dep.min_count) * 16, 128))
                vals = flat[plausible]
                kth = max(0, vals.size - need_pool)
                top = plausible[np.argpartition(vals, kth)[kth:]] if vals.size > need_pool else plausible
                eligible = np.unique(np.concatenate((eligible, top)))
        if eligible.size == 0:
            return []
        pool_size = min(eligible.size, max(desired * 48, desired + 64, 1024))
        if eligible.size > pool_size:
            vals = flat[eligible]
            kth = max(0, vals.size - pool_size)
            pick = np.argpartition(vals, kth)[kth:]
            eligible = eligible[pick]
        # Prefer high suitability while retaining deterministic variation so deposits
        # populate a province rather than all stacking on the single best pixel.
        values = flat[eligible]
        jitter = self.rng.random(eligible.size, dtype=np.float32) * 0.18
        order = np.argsort(values + jitter)[::-1]
        eligible = eligible[order]

        rows, cols = score.shape
        spacing = max(float(self.step), dep.min_spacing_blocks)
        bucket_size = spacing
        buckets: dict[tuple[int, int], list[tuple[float, float]]] = {}
        selected: list[tuple[int, int, float]] = []

        def can_place(wx: float, wz: float) -> bool:
            bx = int(math.floor(wx / bucket_size))
            bz = int(math.floor(wz / bucket_size))
            for zz in range(bz - 1, bz + 2):
                for xx in range(bx - 1, bx + 2):
                    for px, pz in buckets.get((xx, zz), ()):
                        if (px - wx) ** 2 + (pz - wz) ** 2 < spacing ** 2:
                            return False
            buckets.setdefault((bx, bz), []).append((wx, wz))
            return True

        for idx in eligible:
            row, col = divmod(int(idx), cols)
            wx = self.origin[0] + col * self.step + self.step * 0.5
            wz = self.origin[1] + row * self.step + self.step * 0.5
            if can_place(wx, wz):
                selected.append((row, col, float(score[row, col])))
                if len(selected) >= desired:
                    break
        return selected

    def _sample_field(self, name: str, wx: float, wz: float, default: float = 0.0) -> float:
        if name not in self.arrays:
            return default
        arr = self._array(name)
        col = int(round((wx - self.origin[0]) / self.step))
        row = int(round((wz - self.origin[1]) / self.step))
        row = max(0, min(arr.shape[0] - 1, row))
        col = max(0, min(arr.shape[1] - 1, col))
        try:
            return float(arr[row, col])
        except Exception:
            return default

    def _ensure_section_db(self) -> sqlite3.Connection | None:
        if self._section_db is not None:
            return self._section_db
        if self._section_db_path is None or not self._section_db_path.is_file():
            return None
        uri = f"file:{self._section_db_path.as_posix()}?mode=ro"
        self._section_db = sqlite3.connect(uri, uri=True)
        return self._section_db

    def _adjust_y_to_host_section(self, dep: DepositProfile, wx: float, wz: float, target_y: float) -> float:
        if dep.shape == "placer" or not dep.host_categories:
            return target_y
        connection = self._ensure_section_db()
        if connection is None:
            return target_y
        bounds = self.manifest.get("chunk_bounds") or [0, 0, 0, 0]
        min_cx, max_cx, min_cz, max_cz = [int(v) for v in bounds]
        stride = max(1, int(self.manifest.get("verification_step", 32)) // 16)
        cx = math.floor(wx / 16.0)
        cz = math.floor(wz / 16.0)
        sample_cx = min_cx + int(round((cx - min_cx) / float(stride))) * stride
        sample_cz = min_cz + int(round((cz - min_cz) / float(stride))) * stride
        sample_cx = max(min_cx, min(max_cx, sample_cx))
        sample_cz = max(min_cz, min(max_cz, sample_cz))
        try:
            rows = connection.execute(
                "SELECT sy, dominant_category, air_fraction, water_fraction, protected_blocks "
                "FROM section_summary WHERE cx=? AND cz=?",
                (int(sample_cx), int(sample_cz)),
            ).fetchall()
        except sqlite3.Error:
            return target_y
        allowed = set(dep.host_categories)
        candidates: list[tuple[float, float]] = []
        for sy, category, air_fraction, water_fraction, protected_blocks in rows:
            if str(category) not in allowed:
                continue
            if float(air_fraction) > 0.45 or float(water_fraction) > 0.55 or int(protected_blocks) > 256:
                continue
            center_y = int(sy) * 16 + 7.5
            candidates.append((abs(center_y - target_y), center_y))
        if not candidates:
            return target_y
        candidates.sort(key=lambda item: item[0])
        # Keep some vertical variation inside the compatible section instead of
        # snapping every generated feature to the exact section midpoint.
        chosen = candidates[min(len(candidates) - 1, int(self.rng.integers(0, min(3, len(candidates)))) )][1]
        return chosen + float(self.rng.uniform(-5.5, 5.5))

    def _depth_y(self, dep: DepositProfile, row: int, col: int, shape_kind: str) -> float:
        surface = float(np.asarray(self._array("surface_height"))[row, col])
        lo, hi = sorted((float(dep.depth_min), float(dep.depth_max)))
        u = float(self.rng.random())
        if dep.depth_reference == "absolute_y":
            y = lo + (hi - lo) * u
        elif dep.depth_reference in {"world_fraction", "world_height_fraction"}:
            world_min, world_max = self.height_range
            fraction = np.clip(lo + (hi - lo) * u, 0.0, 1.0)
            y = world_min + fraction * (world_max - world_min)
        else:
            depth = lo + (hi - lo) * u
            y = surface - depth
        # Fold sedimentary seams and structurally controlled veins with the inferred
        # geology instead of leaving them as perfectly horizontal Minecraft layers.
        if shape_kind in {"seam", "vein", "stockwork", "lens"}:
            warp = float(np.asarray(self._array("structural_warp_blocks"))[row, col]) if "structural_warp_blocks" in self.arrays else 0.0
            y += warp * (0.55 if shape_kind == "seam" else 0.22)
        wx = float(self.origin[0] + col * self.step + self.step * 0.5)
        wz = float(self.origin[1] + row * self.step + self.step * 0.5)
        y = self._adjust_y_to_host_section(dep, wx, wz, y)
        return float(np.clip(y, self.height_range[0] + 2, self.height_range[1] - 3))

    def _common_stroke(self, dep: DepositProfile, points: list[tuple[float, float, float]], *, shape: str, size: float, axis_lock: str = "None", strength: int | None = None) -> dict[str, Any]:
        if not points:
            return {}
        half = max(1.0, size * 0.5)
        xs, ys, zs = zip(*points)
        return {
            "points": [[round(x, 2), round(y, 2), round(z, 2)] for x, y, z in points],
            "bbox": [
                int(math.floor(min(xs) - half)), int(math.floor(min(ys) - half)), int(math.floor(min(zs) - half)),
                int(math.ceil(max(xs) + half)), int(math.ceil(max(ys) + half)), int(math.ceil(max(zs) + half)),
            ],
            "action": "Replace blocks",
            "material": dep.material,
            "shape": shape,
            "size_blocks": max(1, int(round(size))),
            "strength_pct": int(dep.strength_pct if strength is None else strength),
            "axis_lock": axis_lock,
            "mirror": "None",
            "host_only": bool(dep.host_only),
            "protect_surface": bool(dep.protect_surface),
            "surface_margin": int(dep.surface_margin),
            "replace_only": list(dep.replace_only),
            "generated_geology": True,
            "deposit_id": dep.id,
        }

    def _make_feature_strokes(self, dep: DepositProfile, row: int, col: int, score: float, feature_index: int) -> tuple[dict[str, Any], list[dict[str, Any]]]:
        wx = float(self.origin[0] + col * self.step + self.step * 0.5)
        wz = float(self.origin[1] + row * self.step + self.step * 0.5)
        kind = dep.shape
        y = self._depth_y(dep, row, col, kind)
        size = float(self.rng.uniform(min(dep.size_min, dep.size_max), max(dep.size_min, dep.size_max)))
        length = float(self.rng.uniform(min(dep.length_min, dep.length_max), max(dep.length_min, dep.length_max)))
        thickness = float(self.rng.uniform(min(dep.thickness_min, dep.thickness_max), max(dep.thickness_min, dep.thickness_max)))
        angle = float(self.rng.uniform(0.0, math.tau))
        strokes: list[dict[str, Any]] = []

        if kind == "seam":
            spacing = max(4.0, size * 0.55)
            n = max(2, int(length / spacing) + 1)
            layers = max(1, int(round(thickness)))
            points: list[tuple[float, float, float]] = []
            for i in range(n):
                t = (i - (n - 1) * 0.5) * spacing
                x = wx + math.cos(angle) * t
                z = wz + math.sin(angle) * t
                base_y = y + self._sample_field("structural_warp_blocks", x, z, 0.0) * 0.18
                for dy in range(layers):
                    points.append((x, base_y + dy - (layers - 1) * 0.5, z))
            strokes.append(self._common_stroke(dep, points, shape="Disc", size=size, axis_lock="Y"))
        elif kind == "vein":
            n = max(3, int(length / max(3.0, size * 0.75)) + 1)
            dip = float(self.rng.uniform(-0.42, 0.42))
            pts = []
            for i in range(n):
                t = (i - (n - 1) * 0.5) * (length / max(1, n - 1))
                bend = math.sin(i * 0.85 + feature_index) * size * 0.45
                x = wx + math.cos(angle) * t - math.sin(angle) * bend
                z = wz + math.sin(angle) * t + math.cos(angle) * bend
                yy = y + dip * t + self._sample_field("structural_warp_blocks", x, z, 0.0) * 0.12
                pts.append((x, yy, z))
            strokes.append(self._common_stroke(dep, pts, shape="Tunnel brush", size=max(2.0, thickness)))
        elif kind == "stockwork":
            for branch in range(3):
                branch_angle = angle + (branch - 1) * 0.72 + float(self.rng.uniform(-0.18, 0.18))
                n = max(3, int(length / max(4.0, size)) + 1)
                pts = []
                for i in range(n):
                    t = (i - (n - 1) * 0.5) * (length / max(1, n - 1))
                    yy = y + (i - n * 0.5) * thickness * float(self.rng.uniform(-0.35, 0.35))
                    pts.append((wx + math.cos(branch_angle) * t, yy, wz + math.sin(branch_angle) * t))
                strokes.append(self._common_stroke(dep, pts, shape="Tunnel brush", size=max(2.0, thickness), strength=max(1, int(dep.strength_pct * 0.7))))
        elif kind == "pipe":
            # A pipe is represented as sparse mineralization through a larger
            # vertical mantle-derived body. The low default strength for diamond
            # profiles prevents a solid cylinder of diamonds.
            n = max(4, int(length / max(4.0, size * 0.35)) + 1)
            pts = [(wx, y + (i - (n - 1) * 0.5) * (length / max(1, n - 1)), wz) for i in range(n)]
            strokes.append(self._common_stroke(dep, pts, shape="Tunnel brush", size=size))
        elif kind == "placer":
            directions = np.asarray(self._array("flow_direction")) if "flow_direction" in self.arrays else None
            surface = np.asarray(self._array("surface_height"), dtype=np.float32)
            rr, cc = int(row), int(col)
            pts = []
            max_steps = max(2, int(length / self.step))
            for _ in range(max_steps):
                sx = self.origin[0] + cc * self.step + self.step * 0.5
                sz = self.origin[1] + rr * self.step + self.step * 0.5
                sy = float(surface[rr, cc]) - max(1.0, min(4.0, dep.depth_min))
                pts.append((sx, sy, sz))
                if directions is None:
                    break
                d = int(directions[rr, cc])
                if d < 0 or d >= len(self.OFFSETS):
                    break
                dr, dc = self.OFFSETS[d]
                nr, nc = rr + dr, cc + dc
                if not (0 <= nr < surface.shape[0] and 0 <= nc < surface.shape[1]):
                    break
                rr, cc = nr, nc
            strokes.append(self._common_stroke(dep, pts, shape="Disc", size=max(size, self.step * 1.5), axis_lock="Y"))
        elif kind == "lens":
            # Multiple overlapping blobs create a flattened irregular lens.
            pts = []
            n = max(2, int(length / max(5.0, size)))
            for i in range(n):
                t = (i - (n - 1) * 0.5) * min(size, length / max(1, n - 1))
                pts.append((wx + math.cos(angle) * t, y + math.sin(i * 1.7) * thickness * 0.25, wz + math.sin(angle) * t))
            strokes.append(self._common_stroke(dep, pts, shape="Blob", size=size))
        else:  # blob / disseminated / unknown custom shape fallback
            strokes.append(self._common_stroke(dep, [(wx, y, wz)], shape="Blob", size=size))

        strokes = [s for s in strokes if s]
        feature = {
            "id": f"{dep.id}:{feature_index:05d}",
            "deposit_id": dep.id,
            "label": dep.label,
            "material": dep.material,
            "shape": dep.shape,
            "center": [round(wx, 2), round(y, 2), round(wz, 2)],
            "score": round(float(score), 5),
            "size": round(size, 2),
            "length": round(length, 2),
            "thickness": round(thickness, 2),
            "stroke_count": len(strokes),
        }
        return feature, strokes

    def run(self) -> ResourceGenerationReport:
        started = time.monotonic()
        self._emit(0, "Loading whole-world geological model…")
        fields = self._factor_fields()
        enabled_filter = set(self.options.enabled_deposits or ())
        deposits = [
            d for d in self.profile.deposits.values()
            if d.enabled and (not enabled_filter or d.id in enabled_filter)
        ]
        if not deposits:
            raise RuntimeError("No geological deposits are enabled in the profile.")

        plan_dir = self.root / "resource_plans"
        plan_dir.mkdir(parents=True, exist_ok=True)
        paint_layers: dict[str, dict[str, Any]] = {}
        feature_plan: list[dict[str, Any]] = []
        counts: dict[str, int] = {}
        stroke_counts: dict[str, int] = {}
        suitability_stats: dict[str, Any] = {}

        total = len(deposits)
        for dep_i, dep in enumerate(deposits):
            base_pct = 5 + int(88 * dep_i / max(1, total))
            self._emit(base_pct, f"Scoring {dep.label} provinces…")
            score = self._score(dep, fields)
            desired = self._desired_count(dep, score.shape, int(np.count_nonzero(fields["valid"] > 0.5)))
            centres = self._select_centres(dep, score, desired)
            if self.options.write_suitability_arrays:
                self._write_suitability(dep.id, score)
            suitability_stats[dep.id] = {
                "desired": desired,
                "selected": len(centres),
                "threshold": dep.score_threshold,
                "score_max": float(np.max(score)) if score.size else 0.0,
                "score_mean": float(np.mean(score)) if score.size else 0.0,
            }

            layer_name = f"Geology • {dep.label}"
            layer_strokes: list[dict[str, Any]] = []
            for feature_i, (row, col, suitability) in enumerate(centres):
                if feature_i % 64 == 0:
                    self._emit(
                        base_pct + int(80 / max(1, total) * feature_i / max(1, len(centres))),
                        f"Building {dep.label}: {feature_i:,}/{len(centres):,} deposits",
                    )
                feature, strokes = self._make_feature_strokes(dep, row, col, suitability, feature_i)
                feature_plan.append(feature)
                layer_strokes.extend(strokes)
            counts[dep.id] = len(centres)
            stroke_counts[dep.id] = len(layer_strokes)
            if layer_strokes:
                paint_layers[layer_name] = {
                    "name": layer_name,
                    "enabled": True,
                    "preview_visible": True,
                    "settings": {
                        "action": "Replace blocks",
                        "material": dep.material,
                        "shape": "Sphere",
                        "size_blocks": int(round((dep.size_min + dep.size_max) * 0.5)),
                        "strength_pct": dep.strength_pct,
                        "spacing_pct_radius": 25,
                        "falloff": "Constant",
                        "axis_lock": "None",
                        "mirror": "None",
                        "host_only": dep.host_only,
                        "protect_surface": dep.protect_surface,
                        "surface_margin": dep.surface_margin,
                        "align_mode": "Manual / World axes",
                        "brush_roll_deg": 0.0,
                        "brush_offset_blocks": 0.0,
                    },
                    "strokes": layer_strokes,
                }

        plan_id = hashlib.sha256(
            json.dumps({"seed": self.seed, "profile": self.profile.fingerprint(), "counts": counts}, sort_keys=True).encode("utf-8")
        ).hexdigest()[:16]
        plan_path = plan_dir / f"resource_plan_{plan_id}.json"
        plan_doc = {
            "schema": "worldgeolabs.geological-resource-plan.v1",
            "created_unix": time.time(),
            "analysis_manifest": str(self.manifest_path),
            "profile": str(self.profile.path),
            "profile_id": self.profile.profile_id,
            "profile_fingerprint": self.profile.fingerprint(),
            "seed": self.seed,
            "population_scale": float(self.options.population_scale),
            "effective_step": self.step,
            "origin": list(self.origin),
            "height_range": list(self.height_range),
            "deposit_counts": counts,
            "stroke_counts": stroke_counts,
            "features": feature_plan,
        }
        temp = plan_path.with_suffix(".json.tmp")
        temp.write_text(json.dumps(plan_doc, indent=2), encoding="utf-8")
        os.replace(temp, plan_path)

        self.manifest["arrays"] = self.arrays
        self.manifest["geology_profile"] = str(self.profile.path)
        self.manifest["geology_profile_id"] = self.profile.profile_id
        self.manifest["geology_profile_fingerprint"] = self.profile.fingerprint()
        self.manifest["resource_deposits"] = self.profile.serializable_deposits()
        self.manifest["latest_resource_plan"] = str(plan_path)
        summary = dict(self.manifest.get("summary") or {})
        summary["resource_deposit_counts"] = counts
        summary["resource_stroke_counts"] = stroke_counts
        summary["resource_suitability"] = suitability_stats
        self.manifest["summary"] = summary
        manifest_temp = self.manifest_path.with_suffix(".json.tmp")
        manifest_temp.write_text(json.dumps(self.manifest, indent=2), encoding="utf-8")
        os.replace(manifest_temp, self.manifest_path)

        self._emit(100, f"Geological resources ready: {sum(counts.values()):,} deposits")
        self.close()
        return ResourceGenerationReport(
            plan_path=plan_path,
            manifest_path=self.manifest_path,
            profile_path=self.profile.path,
            elapsed_seconds=time.monotonic() - started,
            seed=self.seed,
            deposit_counts=counts,
            stroke_counts=stroke_counts,
            paint_layers=paint_layers,
            summary={
                "total_deposits": int(sum(counts.values())),
                "total_strokes": int(sum(stroke_counts.values())),
                "suitability": suitability_stats,
            },
        )
