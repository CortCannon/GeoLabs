# WorldGeoLabs v0.16.15 — Startup Mesh Visibility Hotfix

## Problem

After v0.16.13/v0.16.14, selected-area meshes could appear for one frame and then disappear after the world finished loading.

The load log showed successful world indexing, datapack height detection, mesh building, staging, and GPU upload. That meant the world reader and GL upload path were working. The failure happened after startup preload, when normal UI/session reset pushed a new preview settings dictionary.

Even when previews were off, that dictionary replacement was treated as a full voxel preview-signature change. The renderer then dropped all resident voxel meshes immediately after startup upload, causing the terrain to flash and vanish.

## Fix

- StreamManager now keeps resident mesh state intact when the renderer-visible preview signature is unchanged.
- GLViewport now compares stable preview signatures before requesting a full preview mesh drop.
- Preview settings dictionary changes that do not affect rendering no longer clear visible meshes.
- Local dirty-box paint updates still invalidate only the touched chunk columns/sections.
- True preview state changes still trigger full voxel preview refresh when necessary.

## Expected Result

The selected terrain should no longer flash and disappear after preload. Startup mesh upload should remain visible unless an actual renderer-visible preview/cutaway/material setting hides it.
