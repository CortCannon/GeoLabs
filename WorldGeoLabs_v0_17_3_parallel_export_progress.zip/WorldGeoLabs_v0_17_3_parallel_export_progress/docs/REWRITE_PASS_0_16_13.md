# WorldGeoLabs v0.16.13 — Section Dirty Rendering Pass

This pass starts the renderer/edit architecture shift discussed after v0.16.12.

## Goals

- Stop paint strokes from causing a full preview/world remesh.
- Introduce a 16 x 16 x 16 render-section model separate from Anvil chunk-column storage.
- Compute dirty regions in 3D section space, not only 2D chunk-column space.
- Keep the selected area as an edit boundary, not as the loaded/rendered area.

## Key Changes

### Local preview settings update

Paint stroke commits now push the new preview settings together with the dirty block bbox. Older builds pushed the full preview settings first, which changed the global preview signature and made the renderer invalidate every voxel mesh before the later local invalidation could help.

Now a paint stroke does:

1. Record stroke payload.
2. Convert the stroke bbox plus brush padding into touched 16 x 16 x 16 render sections.
3. Convert those sections to the currently supported chunk-column invalidation set.
4. Push preview settings with the dirty bbox.
5. Drop/rebuild only the touched local voxel meshes.

### RenderSectionKey model

Added `mcgeo/rendering/render_sections.py` with `RenderSectionKey(cx, sy, cz)`.

This is the new internal editor/render unit:

```text
16 blocks X
16 blocks Y
16 blocks Z
```

Minecraft Anvil files still use chunk columns for storage, but renderer/edit invalidation now has a 3D brick vocabulary.

### Section-aware mesh builder hook

`build_chunk_mesh(..., section_y=...)` can now build a single 16-block-tall voxel section. This is the foundation for the next pass where the stream manager will schedule actual voxel section meshes instead of whole chunk-column voxel meshes.

In this build, dirty tracking is section-based, while the active GPU invalidation path still falls back to touched chunk columns for compatibility with the current GL mesh dictionary.

### Huge-area startup protection

Blocking selected-area voxel preload now skips huge selections above the configured render-all limit. This prevents a large 16,384 x 16,384 project from accidentally starting a blocking preload over the entire selection.

## Performance Metrics Added

The performance snapshot now reports:

- last dirty 16 x 16 x 16 render sections
- last dirty chunk columns

## Remaining Work

The next renderer pass should move the active streaming working set fully from 2D chunk-column keys to 3D section keys:

- stream voxel detail by `RenderSectionKey(cx, sy, cz)`
- keep surface overview as 2D chunk/tile keys
- prioritize sections around camera Y, brush Y, slice plane, and active dirty edits
- upload/drop GPU meshes by section key instead of chunk-column key
- add a true low-detail overview tile/quadtree layer for the full 16k map
