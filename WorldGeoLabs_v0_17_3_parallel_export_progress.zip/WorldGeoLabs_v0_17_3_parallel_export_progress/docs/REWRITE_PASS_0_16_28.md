# WorldGeoLabs 0.16.28 — DH SQLite Windows lifecycle fix

The 0.16.27 Distant Horizons self-test exposed a Windows-only file locking issue.
Python sqlite3 connection context managers commit/rollback but do not close the connection.

This pass:

- wraps all read-only DH SQLite connections in `contextlib.closing`;
- explicitly closes the synthetic test database connection;
- preserves read-only `mode=ro` access for real Distant Horizons databases;
- prevents temporary test cleanup failures (`WinError 32`) and stale live renderer handles.
