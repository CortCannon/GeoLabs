# WorldGeoLabs 0.16.27 — Distant Horizons large-world context

## Goal

Make 16k-class WorldPainter worlds practical to navigate and edit without decoding/meshing a large ring of real Anvil chunks every time the camera moves.

## Rendering architecture

- Added a second, read-only far-terrain path backed by Distant Horizons `DistantHorizons.sqlite`.
- DH FullData becomes a coarse navigation/background mesh only.
- Real Anvil voxel meshes remain authoritative in the editable working radius.
- The DH background is shader-clipped beneath the working area and disabled in x-ray.
- Far clip distance scales with the opened world extent.

## Streaming behavior

- When a DH tile successfully validates, `StreamManager` switches to `external_far_lod` mode.
- External far-LOD mode stops scheduling the old per-chunk Anvil surface ring.
- Detailed Anvil terrain is kept in a bounded near ring.
- The detailed ring uses a hysteretic working-area anchor, recentering only after the camera moves through the inner half of the ring instead of rebuilding a strip every chunk boundary.
- If DH is absent or incompatible, the previous surface-ring streamer remains the automatic fallback.

## DH compatibility and safety

- DH SQLite is opened `mode=ro` with `query_only=ON`; GeoLabs never modifies it.
- Requires a compatible `FullData` table and currently supports DataFormatVersion 1.
- Supports DH compression mode 3 (XZ) and mode 4 (Zstandard).
- Added `zstandard` to setup dependencies.
- Chooses a bounded coarse FullData level and can decimate its 64x64 cells further for a bounded GPU mesh.
- DH does not become authoritative until the first tile successfully decodes.
- Total decode failure automatically retains the legacy Anvil surface renderer.
- `WGL_DISABLE_DH_LOD=1` forces fallback mode.

## Diagnostics

- Added `mcgeo.rendering.tests_distant_horizons`.
- Real-world diagnostics report DH database discovery and compatibility.
- Existing Anvil exporter, bit-storage, and Geological Analysis tests remain passing.
