# WorldGeoLabs v0.16.22 — WorldPainter Import Foundation

## Added

- Optional **Open World + WorldPainter** startup and File-menu workflow.
- Paired Minecraft/WorldPainter project state saved in `.mcgeo.json`.
- Neutral `worldgeolabs.worldpainter.v1` analysis-package reader.
- Folder, `.zip`, and `.wglwp` package support.
- Java bridge discovery, execution, fingerprinting, and disk cache.
- Metadata alignment checks for dimensions, build height, and project bounds.
- Clear fallback: the Minecraft world still opens when WorldPainter import is unavailable.
- Bridge/package protocol documentation and an example package.

## Source-of-truth rule

WorldPainter data is an analysis accelerator and terrain-intent source.
Minecraft Anvil blocks/NBT remain the exact source of truth for editing and
incremental export.

## Not implemented yet

This pass does not include a compiled WorldPainter bridge or tiled height,
water, terrain, biome, and layer readers. Those require the matching
WorldPainter Java libraries and form the next analysis milestone.
