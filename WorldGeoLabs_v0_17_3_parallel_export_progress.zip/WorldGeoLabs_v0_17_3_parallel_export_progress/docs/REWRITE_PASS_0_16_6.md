# WorldGeoLabs 0.16.6 — Cleanup + UI pass

This pass intentionally avoids another deep 3D paint placement rewrite. The current paint cursor still needs a dedicated interaction redesign, but piling more quick fixes onto it was making behavior worse. This build focuses on structural cleanup and UI quality so the next paint rewrite has a cleaner base.

## Structural cleanup

- Added `mcgeo/ui/widgets/workspace_shell.py`.
  - Owns the central viewport card, workflow header, status chips, and primary workflow buttons.
  - Keeps `main_window.py` focused more on orchestration instead of raw central-layout construction.
- Added `mcgeo/ui/theme.py`.
  - Centralizes app-local Qt stylesheet rules.
  - Removes the need to scatter style decisions across widgets.
- Added package marker files:
  - `mcgeo/ui/__init__.py`
  - `mcgeo/ui/widgets/__init__.py`
  - `mcgeo/rendering/__init__.py`
  - `mcgeo/world/__init__.py`

## UI/workflow improvements

- Central workspace header is now a dedicated widget with:
  - world status chip
  - area + preview status chip
  - active tool status chip
  - primary workflow buttons: Open World, Project Area, Create Feature, Paint
  - workflow hint: Open World → Select Area → Create Feature → Preview → Apply Copy
- Added centralized dark desktop-tool styling for:
  - workspace cards
  - viewport card
  - status chips
  - buttons
  - tabs
  - group boxes
  - list/edit controls
- Added `View > Reset Window Layout`.
  - Restores the intended dock arrangement without needing to manually drag panels back.
- Added `Tools > Show Scene / View Tools`.
  - Quickly returns the right panel to cutaway/transparency/preview controls.

## Paint panel cleanup

- Renamed depth buttons to `Y+` / `Y-` so they describe what they actually change.
- Added `Reset brush controls` in Paint > Placement.
  - Turns surface snap off.
  - Clears axis lock and mirror.
  - Returns alignment to manual.
  - Resets roll and Y offset.
  - Keeps overlay visible.
- Updated placement/shortcut text to avoid promising behavior that is still under redesign.

## Known issue intentionally not hidden

3D paint placement is still not correct. Recent attempts exposed that the current cursor model is too fragile. The next real fix should be a clean interaction rewrite, probably with explicit cursor modes:

1. Surface pick mode — brush follows visible block face.
2. Plane mode — mouse moves X/Z on a user-visible Y plane.
3. Free volume/gizmo mode — brush is moved with a persistent 3D transform, not constantly recomputed from hover state.

That rewrite should happen after the viewport interaction ownership is separated further from `gl_viewport.py`.
