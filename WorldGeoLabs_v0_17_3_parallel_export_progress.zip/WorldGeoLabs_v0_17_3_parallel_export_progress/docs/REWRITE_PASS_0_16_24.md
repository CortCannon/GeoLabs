# WorldGeoLabs v0.16.24 — Geological Analysis Foundation

## Purpose

This pass moves WorldGeoLabs beyond manual painting and establishes the
analysis foundation required for realistic automated caves and mineral
deposits.

## Added

- New **Geological Analysis** workspace tab, toolbar action, and Analysis menu.
- Whole-world or selected-area analysis.
- WorldPainter overview as the preferred broad terrain source.
- Minecraft Anvil verification for:
  - actual surface blocks,
  - soil/regolith depth,
  - host rock,
  - water,
  - block categories,
  - protected/constructed material,
  - existing ores.
- 16×16×16 section summaries stored in SQLite.
- Disk-backed raster arrays for:
  - surface height,
  - water level,
  - slope,
  - aspect,
  - D8 flow direction,
  - flow accumulation,
  - WorldPainter terrain IDs,
  - WorldPainter geological categories,
  - Minecraft surface categories,
  - host-rock categories,
  - soil depth,
  - combined geology.
- 2D previews for the generated analysis datasets.
- Analysis layers added to the GIMP-style layer stack.
- Cache reuse based on world, WorldPainter, configuration, bounds, and
  resolution fingerprints.
- Editable Minecraft 1.21.1 geological block-category TOML.
- Editable per-world WorldPainter terrain-to-geology mapping.
- Unknown-block report for expanding the configuration safely.
- Region-batched Anvil scanning, avoiding one region-file reopen per chunk.

## Large-map defaults

For a 16,384×16,384 map:

- WorldPainter surface grid defaults to 8-block spacing.
- Minecraft verification defaults to one sampled chunk per 4×4 chunk group.
- Users can choose every-chunk verification for maximum detail.
- The full volume is never loaded into memory.
- Surface arrays are memory-mapped to disk.
- Vertical geology is summarized in a SQLite section database.

## Source-of-truth behavior

WorldPainter supplies broad height, water, coordinates, terrain intent, and
layer metadata. Minecraft Anvil remains authoritative for actual blocks and
NBT.

## Not yet included

- Ore or cave generation.
- 3D rendering of analysis rasters in the OpenGL viewport.
- Fault extraction and geological province generation.
- Full hydrological conditioning such as depression filling.
- Dense every-section scanning unless the user selects detailed verification.

The next milestone should use these datasets to build geological provinces,
fault/fracture fields, aquifers, and editable deposit/cave generator profiles.
