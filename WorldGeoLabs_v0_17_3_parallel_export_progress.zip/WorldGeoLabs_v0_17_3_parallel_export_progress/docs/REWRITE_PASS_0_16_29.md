# WorldGeoLabs 0.16.29 — Distant Horizons FullData V2 support

A real Minecraft 26.2 / Distant Horizons world exposed that current DH databases use
`DataFormatVersion=2`.  The previous reader only supported format 1 and silently fell back
to expensive Anvil surface streaming, which defeated the large-world rendering design.

This pass:

- supports DH FullData formats 1 and 2;
- implements DH V2 staged VarInt decoding (counts, ID/flags, heights, predictive bottom-Y, lights);
- reads North/South/East/West adjacent edge blobs so 64x64 tiles remain complete;
- supports current DH compression mode values: raw (0), LZ4 frame (1), legacy Zstd stream (2), XZ/LZMA2 (3), and Zstd block/frame (4);
- keeps the DH database strictly read-only;
- retains Anvil surface fallback only when a DH row genuinely cannot be decoded;
- extends the DH self-test to independently validate legacy format 1 and modern format 2.

When the first real DH tile validates, GeoLabs disables far Anvil surface streaming and
uses DH as the static navigation context while keeping only the local real-chunk working area.

## Large-world navigation change

When a compatible Distant Horizons database is active, the detailed Anvil voxel area is now
**pinned** instead of following the camera. Camera movement therefore uses only the already-built
DH background and does not cause new real Minecraft chunks to be decompressed and meshed.

Use **Move Working Area** on the main toolbar (or **Ctrl+Shift+M**) when you want to load real
editable blocks around the current camera target. Performance > Live stats reports the pinned
working-area chunk. The DH shader cutout and terrain-peel topmap follow that same anchor.

The real-world diagnostics path (`python -m mcgeo.diagnostics --world <world>`) now decodes sample
rows from the world's actual DistantHorizons.sqlite so format/compression compatibility can be
verified before launching the renderer.
