# WorldGeoLabs 0.16.31 — Dual Edit Modes + 3D Work Box

This pass changes the large-world workflow from one always-on voxel bubble into two explicit editing modes.

## LOD Edit

- Distant Horizons remains read-only and is used as the whole-world navigation surface.
- No real Anvil voxel meshes are streamed while LOD Edit is active.
- Surface-snap painting uses the decoded DH CPU surface cache instead of opening `.mca` chunks.
- Existing paint strokes are shown as coarse wire-volume overlays, including underground strokes, so large-scale edits remain visible without block-for-block rendering.
- Applying an edit still uses the normal WorldGeoLabs Anvil exporter; the DH database is never edited.

## Detailed Edit

- Exact Minecraft blocks are loaded only inside a movable 3D work box.
- X/Z size is controlled by `Detailed box X/Z radius` in chunks.
- Vertical size is controlled independently by `Detailed box height` and `Detailed box center Y`.
- `Move Working Area` moves the box in X/Z and Y to the camera target.
- The mesher requests only the intersecting 16-block-high Minecraft sections rather than the entire world column from min Y to max Y.
- The Anvil reader now also skips block-state expansion outside that section range. The `.mca` chunk payload still has to be decompressed/read as a unit, but GeoLabs no longer turns every out-of-box section into 4096 Python block indices.

For a 128-block-tall work box, only 8 vertical sections per chunk are meshed. On a -512..2032 world this replaces the old 159-section full-column span with only the sections actually being edited.

## Distant Horizons detail control

Performance > Rendering now exposes `LOD area detail`:

- 16 blocks/cell
- 32 blocks/cell
- 64 blocks/cell
- 128 blocks/cell
- 256 blocks/cell

Changing the value rebuilds the read-only DH background at the requested display sampling level. Finer values cost more startup decode time, CPU mesh generation, VRAM, and draw bandwidth.

## Current scope

LOD Edit coarse preview is implemented for manual paint strokes. The same overlay path is intended for Geological Analysis, caves, ores, and Hydrology feature layers, but those generator-specific coarse renderers are still a subsequent subsystem pass.
