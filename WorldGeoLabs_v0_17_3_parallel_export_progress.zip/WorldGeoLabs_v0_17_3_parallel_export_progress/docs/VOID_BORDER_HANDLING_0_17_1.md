# WorldGeoLabs 0.17.1 — Void-border handling

Minecraft/WorldPainter exports can contain `.mca` placeholders around an intentionally void border. These may be zero bytes, shorter than the 8192-byte Anvil header, header-only with no chunk slots, or contain absent chunk slots inside an otherwise valid region.

WorldGeoLabs now treats those locations as **outside the editable/analyzable world**:

- world bounds are derived from actual present chunk slots rather than region filenames;
- Geological Analysis writes a `minecraft_presence` raster and masks WorldPainter/Minecraft inputs outside real chunks;
- whole-world resource populations are computed from present terrain area only;
- Anvil streaming/readers return no chunk for void/unusable regions instead of raising analysis-wide errors;
- warmup/overview passes ignore void region files;
- export never creates chunks in absent slots or converts a zero-byte/header-only border region into terrain;
- diagnostics report usable, void, and invalid region counts.

The source world is not modified by this classification. Placeholder files can remain on disk; GeoLabs simply ignores them.
