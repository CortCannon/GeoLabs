# WorldGeoLabs v0.16.18 — X-ray Seam/Grid Hotfix

This pass fixes the visible lack of change after v0.16.17.

## What was wrong

The v0.16.17 mesh builder added neighbor-aware chunk sampling, but the greedy meshing loop still guarded calls to `at()` with local coordinate checks. Because of that, the neighbor-aware lookup was never actually used for X/Z border samples, so chunk-border faces were still emitted and x-ray still showed chunk boxes.

The remaining green grid also came from surface/navigation LOD meshes being drawn during x-ray. Even at reduced alpha, those top-surface tiles made the renderer structure visible.

## Changes

- Greedy voxel meshing now always routes both face-side samples through `at()`.
- `at()` handles local blocks, X/Z neighbor chunks, and Y-adjacent section samples.
- Internal chunk-border faces should now be suppressed when the adjacent chunk has solid terrain.
- Surface/navigation LOD meshes are skipped entirely while x-ray is enabled.
- Voxel meshes remain visible and use the x-ray shell fade.

## Expected result

The selected-area outer walls should remain visible, but the interior green chunk grid and chunk-box walls should be greatly reduced.
