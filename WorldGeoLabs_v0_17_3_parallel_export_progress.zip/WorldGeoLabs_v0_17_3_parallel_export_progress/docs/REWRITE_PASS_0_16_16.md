# WorldGeoLabs v0.16.16 — Stream Key Visibility Hotfix

This hotfix addresses the remaining blank viewport behavior after v0.16.13-v0.16.15.

## Symptom

The terrain appeared briefly, then disappeared. Painting caused edited terrain to appear briefly, then disappear again.

## Root cause

The stream manager and OpenGL viewport each defined a `ChunkKey` dataclass. They both contain `cx` and `cz`, but Python dataclass equality requires matching classes. The GL pruning code compared GL-side keys directly against stream-manager keys, so all meshes were treated as outside the active working set and pruned on the next stream tick.

## Fix

`GLViewport._prune_meshes_to_stream_working_set()` now normalizes both sides to plain `(cx, cz)` integer tuples before deciding what to drop.

This preserves the large-area streaming design while stopping valid resident meshes from being deleted immediately after upload.
