# WorldGeoLabs v0.16.19 — Layer-Scoped Undo/Redo Pass

## Goal

Add a first undo/redo system for paint editing that respects the GIMP-style layer model.
Undo and redo are intentionally scoped to the selected paint layer, so a stroke on one layer does not rewind or replay strokes on another layer.

## Changes

- Added toolbar and Edit menu actions for Undo and Redo.
- Added shortcuts:
  - `Ctrl+Z` = undo last stroke on the selected paint layer.
  - `Ctrl+Y` = redo last undone stroke on the selected paint layer.
  - `Ctrl+Shift+Z` = alternate redo shortcut.
- Added per-layer redo stacks in `MainWindow`.
- New strokes clear redo history only for that same paint layer.
- Removing, duplicating, renaming, loading, and resetting paint layers now keeps undo/redo stacks consistent.
- Undo/redo uses the same local dirty-bbox refresh path as paint strokes, so it should remesh only the changed stroke area instead of rebuilding the whole map.
- Paint info shortcut text now mentions undo/redo.

## Current scope

This pass focuses on paint stroke history only. It does not yet undo layer operations such as layer rename, delete, duplicate, visibility toggle, generator parameter edits, or project-level changes.

## Design note

This is deliberately not a single global history stack. The active paint layer owns its own undo/redo stream so the user can work like a layered image editor: select a layer, undo changes within that layer, switch to another layer, and undo that layer independently.
