# WorldGeoLabs v0.16.10 — Tall World Height Bounds Fix

## Problem

The viewport status bar showed a loaded world as `y -64..320` even for custom/tall worlds. The renderer could still stream and draw chunk sections outside vanilla height, but editor logic used the indexed `height_range` for:

- free 3D brush clamping
- brush quantization
- voxel picking
- surface/volume paint placement
- view/cut helpers

Because `mcgeo/world/world_open.py` always returned the vanilla `(-64, 320)` range, the brush could not move or paint outside that range.

## Fix

World indexing now detects height bounds instead of hardcoding vanilla values.

Detection order:

1. Optional environment override:
   - `WGL_WORLD_MIN_Y`
   - `WGL_WORLD_MAX_Y`
2. `level.dat` dimension metadata:
   - `Data/WorldGenSettings/dimensions/minecraft:overworld/type/min_y`
   - `Data/WorldGenSettings/dimensions/minecraft:overworld/type/height`
3. Nearby chunk section scan:
   - scans section `Y` values from nearby existing chunks
   - default cap: `WGL_HEIGHT_SCAN_CHUNKS=768`
4. Vanilla fallback:
   - `-64..320`

## Expected Result

A tall world such as `Y -512..+2032` should now show:

`World: <name> | y -512..2032`

The free 3D brush, hover payload, painting, and voxel picking should then be allowed throughout the real tall-world height range.

## Notes

If a datapack world does not embed its custom dimension type in `level.dat` and the scanned chunks do not contain sections at the true top/bottom, set:

```bat
set WGL_WORLD_MIN_Y=-512
set WGL_WORLD_MAX_Y=2032
python -m mcgeo
```

or increase section scanning:

```bat
set WGL_HEIGHT_SCAN_CHUNKS=4096
python -m mcgeo
```
