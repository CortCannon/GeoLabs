# WorldGeoLabs v0.16.9 — Free 3D Cursor Alignment Hotfix

This hotfix addresses two problems found immediately after the v0.16.8 free paint controller pass.

## Fixed controls conflict

- Shift remains reserved for Axiom-style camera descent.
- Brush Y/depth movement is now handled by Alt+Wheel, `[ / ]`, PageUp/PageDown, or the Y+/Y- buttons in the Paint > Placement tab.
- The Paint panel shortcut text has been updated so it no longer tells the user to use Shift+Wheel for brush height.

## Fixed brush/screen cursor mismatch

The v0.16.8 controller moved the brush with incremental screen-space deltas. That was stable, but after orbiting or flying the camera, a zero mouse delta could leave the brush at the previous world point instead of directly under the OS cursor.

The free cursor now reprojects the current mouse ray onto a camera-facing 3D plane through the persistent brush gizmo. This keeps the brush visually aligned with the mouse while avoiding the old horizontal Y-plane behavior that caused edge/depth locking.

## Expected behavior

- Shift moves the camera down and no longer changes brush height.
- Alt+Wheel moves the brush Y level.
- `[ / ]` and PageUp/PageDown still move the brush Y level.
- After moving/orbiting the camera, the brush should realign under the mouse on release or on the next hover update.
- Exact surface snap remains optional and should stay off for free underground painting.
