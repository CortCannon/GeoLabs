# WorldGeoLabs v0.16.20 — Incremental Map Export Pass 1

This pass adds the first real map export/apply pipeline.

## Goals

- Stop treating export as a full world re-export.
- Export only files that contain changed paint data.
- Keep the original world safe by default.
- Use the existing layer workflow: only visible/enabled paint layers are exported.

## What changed

- Added `mcgeo.world.exporter`.
- Added incremental paint-layer export from preview strokes to real Anvil chunk block states.
- Added timestamped world-copy export mode.
- The copy path prefers hardlinks for unchanged files, then atomically replaces changed region files in the exported copy.
- Added advanced in-place mode with confirmation.
- The Apply dialog is now an Export / Apply dialog instead of review-only.
- Export report shows changed blocks, touched chunks, and rewritten region files.

## Export scope

This milestone writes visible/enabled Paint layers only.

Generator preview layers such as caves and ores are still preview-only in this pass. Heightmap recalculation is also a future pass, so this version is best suited for underground edits such as ore painting, internal block replacement, and carving below the surface.

## File write strategy

Minecraft storage is still Anvil region files:

```text
region/r.<rx>.<rz>.mca
```

The exporter computes which chunk columns are touched by paint strokes, groups them by region file, modifies only those chunks, and rewrites only region files that actually contain changed blocks.

For safe copy export:

1. Create a timestamped world folder next to the original.
2. Hardlink unchanged files where possible.
3. Apply block changes to the destination copy.
4. Atomically replace only changed `.mca` files in the copy.

This avoids regenerating or re-exporting the whole map.

## Known limitations

- Paint layers only; generator previews are not exported yet.
- Does not recalculate Minecraft heightmaps yet.
- Does not create brand-new chunk sections in missing/empty vertical sections yet, to avoid malformed biome-less sections.
- Existing chunks are modified; missing chunks are skipped.
