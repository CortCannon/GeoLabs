# WorldGeoLabs v0.16.25 — Recovery + Safe Export Hardening

## Goal

Establish a trustworthy baseline before adding new geology/hydrology generators.
The required round trip is now:

**read world → preview edits → export independent copy → rewrite touched regions → verify changed chunks → reopen output**.

## Changes

- Replaced the old hardlink-based default world clone with a **true independent file copy**.
  - The previous hardlink optimization was unsafe for a playable output: Minecraft could later mutate an unchanged hardlinked file and affect the source world.
  - `session.lock` is intentionally not copied; Minecraft creates a fresh lock for the output world.
- Export now runs on a Qt worker thread so copying a large WorldPainter world no longer blocks the UI event loop.
- Every rewritten region is validated before atomic replacement.
- Every changed chunk is reopened and byte-verified after the region write.
- Added exporter round-trip self-test using a synthetic modern Anvil chunk.
- Added Geological Analysis smoke test.
- Added `mcgeo.diagnostics` for non-GUI environment/world checks.
- Added Windows setup/run/diagnostic launchers.

## Intentionally not added yet

- Hydrology generation.
- Generator-preview export.
- Heightmap/light recalculation.
- Creation of missing chunk sections.

Those should be added only after this recovery build proves reliable on a real exported WorldPainter world.
