# WorldGeoLabs cleanup / rewrite pass 0.16

This pass is focused on making the project easier to keep moving forward without continuing to stack fixes on top of old painter assumptions.

## Main architectural changes

### New `mcgeo.viewport` package

The first separation point is the viewport interaction layer:

```text
mcgeo/
  viewport/
    cursor_state.py
```

`BrushCursorState` now owns persistent 3D cursor state that used to be spread through `GLViewport`:

- hover world position
- quantized block coordinate
- cursor world position
- cursor depth/distance
- last solid/surface hit distance
- cursor normal / locked-normal state
- paint settings that need to survive quick keyboard/mouse adjustments

`StrokeRecorder` owns stroke sample spacing and sample capture.

The OpenGL widget still performs rendering, ray picking, and overlay drawing, but the tool state is no longer treated as renderer-owned state. This is an intentional stepping stone toward a cleaner `viewport/tools` architecture.

### New `mcgeo.project` package

Paint-layer defaults and project/session normalization were moved out of `MainWindow`:

```text
mcgeo/
  project/
    session.py
```

This removes duplicated layer schema logic from the UI layer and makes project save/load safer as feature layers grow.

## 3D painter/control fixes

The most important behavior fix in this pass:

- Paint stroke updates now resolve the brush sample from the current mouse ray at the persistent 3D cursor depth.
- The previous path could reuse the last fixed cursor point during a stroke, which made painting feel stuck or height/surface locked.
- Brush placement is explicitly free-3D by default.
- Surface snap is now treated as an optional assist, not the core placement mode.
- Cursor depth clamping is based on the selected edit volume and real world height range, not on heightmaps.

## UI/workflow cleanup

The Painter panel language was updated to make the workflow clearer:

- “Free 3D cursor” is the default placement mode.
- “Surface snap assist” is only an optional helper.
- Quick-key text now focuses on cursor depth, size, roll, and re-align behavior.
- The painter subtitle now describes real X/Y/Z preview edits instead of a surface-style painter.

## Paint workspace update in 0.16.x

The right-side paint UI is now organized as a dedicated Paint workspace instead of one long painter panel. It includes:

- Brush tab: presets, operation/action, shape, size, strength, spacing, falloff, and stamp/model entry points.
- Blocks tab: searchable common block palette, quick block picks, selected paint block, and a replace-rule hint stored with paint settings.
- Placement tab: free-3D cursor controls, snap assist, axis/symmetry placeholders, brush roll, and gizmo-depth controls.
- View-owned block transparency: ghost terrain now lives in Scene / Preview > Inspect / Cutaway instead of inside the Paint tab.
- Info tab: live hover/stroke feedback and shortcut reminders.

The transparency control is intentionally renderer-side only. It does not alter the world, layer data, or material visibility masks. As of 0.16.3 it is a general view/inspection setting rather than Paint-tab state. A later renderer pass should add per-material opacity so common host rocks can be ghosted while ores, caves, water, or preview edits remain high-contrast.

## Current boundaries

This is not the final complete rewrite. It is the first cleanup pass that removes one of the most important broken assumptions: that painter state belongs entirely to the OpenGL widget.

Recommended next cleanup targets:

1. Split `GLViewport` into:
   - render widget
   - picking service
   - camera controller
   - brush overlay renderer
   - tool input controller

2. Move paint layer stroke creation into an edit-layer command model.

3. Move dirty-region invalidation to the edit/preview pipeline instead of doing it in `MainWindow`.

4. Add true feature-layer classes for:
   - caves
   - ore bodies
   - geology/rock volumes
   - faults/intrusions
   - fluids/aquifers/lava pockets

5. Convert Apply from review-only to safe apply-to-copy with validation and changed-region reporting.

## Follow-up 0.16.2 — Painted block surface rendering

The previous mesh path only rendered solid-to-air boundaries. That is fast for normal terrain, but it hides ore/replacement blocks painted inside host rock because stone-to-ore is still solid-to-solid.

The voxel mesher now identifies active preview/paint target materials and emits material-boundary faces for those materials. Painted ores therefore show as full block surfaces in ghost/x-ray view. Greedy merging is disabled for those preview faces by default so the user can read the actual Minecraft block grid instead of seeing a single merged blob face.

Paint > Blocks now includes **Render painted blocks as real block surfaces**. This setting is pushed into renderer preview settings as `paint_preview_block_faces`. Terrain transparency is controlled separately from the View tab.
