# WorldGeoLabs 0.16.4 — Paint Depth Unlock Hotfix

This hotfix corrects the v0.16.3 free-3D cursor regression where the paint cursor could stop moving through depth.

## Problem

The 0.16.3 cursor anchoring pass made the free cursor initialize from the visible block under the mouse. That part was useful, but the implementation kept recomputing cursor distance from the current visible surface on every hover update. As a result, Shift+Wheel / bracket depth controls could be immediately overwritten by the next hover pick, making the brush appear locked in place.

## Fix

- Free 3D paint mode now keeps a persistent camera-ray distance.
- The visible surface is used only to initialize/reacquire the cursor distance.
- Depth controls directly modify the persistent cursor distance.
- Hover updates no longer collapse the cursor distance to the clamped point at edit-volume edges.
- Exact surface snap still follows the visible surface, but only when that mode is explicitly enabled.

## User behavior

- Leave **Exact surface snap** off for normal underground painting.
- Use **Shift+Wheel**, `[` / `]`, or PageUp/PageDown to move the brush closer/farther through the selected volume.
- Press `\` to reacquire from the visible block under the mouse and reset the local depth offset.

This is a focused hotfix. The larger next step should be a true viewport-space 3D transform gizmo or depth rail so movement can be controlled along camera ray, world Y, and local brush normal independently.
