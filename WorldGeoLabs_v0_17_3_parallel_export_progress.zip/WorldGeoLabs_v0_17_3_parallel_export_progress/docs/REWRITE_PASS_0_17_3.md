# WorldGeoLabs 0.17.3 — Parallel export + real progress

This pass targets the large-world export bottleneck after whole-world geology/resource generation.

## Export pipeline changes

- Builds the edit/chunk plan before copying the world.
- Copy mode now reports byte/file progress, throughput and ETA.
- Independent world copying uses a small I/O thread pool (Auto: up to 8 workers).
- `.worldgeolabs` analysis caches remain excluded.
- `DistantHorizons.sqlite` and its WAL/SHM/journal sidecars are excluded because they are derived LOD caches and become stale after terrain edits.
- Changed `.mca` region files are processed independently with a Windows-safe process pool. Auto uses all logical CPUs, capped by the number of changed region files.
- Each region worker opens the source region once instead of once per target chunk.
- Region rewrite is streamed to disk rather than building the complete `.mca` body in RAM.
- Unchanged chunks remain in their original compressed form; only changed chunks are recompressed.
- Temporary rewritten regions are verified before atomic replacement; the redundant second decompression verification pass was removed.

## UI

Export now uses a determinate 0–100 progress bar with stage detail:

1. Planning edits
2. Copying the world (files, bytes, MiB/s, ETA)
3. Applying edits (regions/chunks/changed blocks/workers/ETA)
4. Finalizing

The Apply dialog includes Region workers and Copy workers. Region workers default to all logical CPUs; copy workers default to a small I/O pool because world copy speed is normally storage-limited.

## Safety

Copy mode still creates independent files; hardlinks are not used. Void/absent regions and chunk slots remain protected.
