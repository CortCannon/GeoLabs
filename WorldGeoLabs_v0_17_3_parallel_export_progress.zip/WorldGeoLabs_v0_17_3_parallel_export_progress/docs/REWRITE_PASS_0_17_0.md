# WorldGeoLabs 0.17.0 — Whole-world geology + geological resources

This milestone turns Geological Analysis from a read-only terrain classifier into a configurable whole-world resource-planning system.

## Structural interpretation

After the existing height/slope/drainage/lithology pass, GeoLabs now derives disk-backed whole-map fields for:

- structural uplift / mountain-belt intensity
- sedimentary basin potential
- erosion / exposure
- fault and fracture corridors
- hydrothermal potential
- paleo-organic basin potential
- placer concentration potential
- orogenic intensity
- stable deep-crust / craton proxy
- folded-strata Y displacement

These are terrain-derived interpretation proxies, not claims that current terrain uniquely determines real geologic history.

## Editable geology model

`config/geology/world_geology_profile.toml` is the source of truth for resource generation. Users can change:

- population density and global population scale
- suitability threshold and minimum spacing
- deposit size, length, thickness, depth and shape
- Minecraft output material (vanilla or modded block ID)
- permitted host blocks
- terrain/history factor weights
- fold wavelength/amplitude and structural lineament settings

Any `[deposits.<custom_name>]` entry can define another resource without changing Python.

## Deposit shapes

The generator produces exportable GeoLabs paint layers using:

- folded seams
- veins
- stockworks
- vertical pipes
- drainage-traced placers
- lenses
- irregular blobs

Generated geology strokes are normal GeoLabs edit layers. Distant Horizons remains read-only.

## Whole-world export

Generated geology strokes are intentionally not clipped to the manual project/work box. They may span the entire analyzed world. The incremental Anvil writer still rewrites only touched region files and verifies changed chunks.

`replace_only` host-block lists are enforced by the exporter to avoid replacing arbitrary structures or surface blocks.

## Dual edit mode integration

- **LOD Edit** shows generated resource volumes as coarse underground overlays across the DH world.
- **Detailed Edit** resolves only deposits intersecting the local 3D section box into block-level preview meshes.
- A bounding-box rejection pass prevents thousands of distant resource strokes from being evaluated for every local chunk mesh.
