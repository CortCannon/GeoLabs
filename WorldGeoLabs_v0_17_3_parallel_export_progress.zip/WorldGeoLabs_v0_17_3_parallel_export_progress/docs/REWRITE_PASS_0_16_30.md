# WorldGeoLabs 0.16.30 — Surface-first DH rendering pass

- Raises DH whole-world target from 400k to 1M display cells (typically 64 -> 32 blocks/cell on Audor V62).
- Replaces disconnected flat DH plates with a continuous sloped heightfield mesh.
- Batches DH tiles (32/source tiles per GPU mesh by default) to cut Python/OpenGL draw-call overhead dramatically.
- When navigating away from the pinned real-block working area, the DH surface no longer punches a hole and real voxel meshes are skipped for that frame.
- This is an intermediate step toward the final surface-world + section-brick edit architecture. Full Anvil voxel columns are still used inside the active manual edit box.
