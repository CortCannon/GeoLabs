# WorldGeoLabs 0.16.3 — View Transparency + Paint Usability Pass

This pass focuses on the user-reported paint workflow issues after 0.16.2.

## Changes

### View-owned block transparency

Terrain transparency / ghost terrain is no longer owned by the Paint tab.

It now lives in:

```text
Scene / Preview > Inspect / Cutaway > Block transparency / inside view
```

This makes transparency a general viewport/inspection tool, usable with paint, cutaways, slicing, and normal navigation.

New View settings:

- `block_transparency_enabled`
- `block_transparency_opacity_pct`
- `block_transparency_mode`
- `block_transparency_paint_only`

The renderer now reads these through `set_view_settings()` instead of `set_paint_settings()`.

### Paint block selection cleanup

The Paint tab was reorganized so block selection is easier:

- quick-pick tabs for ores, terrain, and carve/fluids
- category filter
- search field
- selected block display
- typed/custom `minecraft:block_id` entry
- copy-current-block button

The old Paint-owned Inside View tab was removed.

### Paint cursor range / placement improvements

The brush depth range was increased from ±512 blocks to ±8192 blocks for tall worlds.

Free-3D painting now uses the visible block under the mouse as an anchor, then applies depth/offset from that anchor. This prevents the brush from feeling trapped on a fixed camera-center plane in the middle of the map while still allowing underground placement.

The backslash key now reacquires the visible block under the current mouse ray by clearing stale cursor depth/anchor state.
