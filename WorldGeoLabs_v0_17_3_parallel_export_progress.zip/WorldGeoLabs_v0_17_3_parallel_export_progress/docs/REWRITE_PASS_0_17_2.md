# WorldGeoLabs 0.17.2 — Parallel whole-world geological analysis

This pass targets the long-running whole-world geological analysis stage on large custom-height worlds.

## CPU utilisation

- Geological Minecraft verification now uses a Windows-safe `ProcessPoolExecutor`.
- `Analysis workers = Auto` uses all logical CPUs reported by the OS.
- The Geological Analysis panel exposes the worker count so users can reduce or increase it.
- Region files are sorted by size and distributed across two balanced jobs per worker.
- Worker-local SQLite shards avoid serialising millions of section-summary rows through multiprocessing IPC.

## Less work per chunk

- Analysis no longer expands every section into a 4,096-element Python block-index list.
- Packed Minecraft block-state longs remain packed until a NumPy palette histogram is required.
- Sparse surface verification scans only the requested X/Z column instead of building the render-oriented 256-column surface cache.
- Near-empty atmospheric sections are omitted from `sections.sqlite` on very tall custom worlds.

## WorldPainter overview

- WorldPainter overview tiles are copied into the analysis rasters with vectorised NumPy indexing rather than nested per-sample Python loops.

## Expected behaviour

The Minecraft verification stage should drive many/all logical CPU threads. Some later stages, especially dependency-ordered flow accumulation, remain partly serial and may temporarily show lower total CPU usage.

## Validation

- Existing analysis smoke test passes.
- Void-border handling test passes.
- Whole-world geology/resource generation test passes.
- New four-worker process-pool analysis test passes.
