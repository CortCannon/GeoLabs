# WorldGeoLabs v0.16.11 — Datapack Height Detection

## Goal

Fix tall-world height bounds when the world height is defined by a datapack instead of inline `level.dat` metadata.

The previous v0.16.10 build could still fall back to vanilla `-64..320` for WorldPainter/custom worlds whose vertical limits live in:

`world/datapacks/<pack>/data/<namespace>/dimension_type/*.json`

or inside a zipped datapack with the same internal layout.

## What changed

- Added generic datapack scanning in `mcgeo/world/world_open.py`.
- Supports both folder datapacks and `.zip` datapacks.
- Does not assume a datapack name, namespace, or naming style.
- Looks for any path shaped like:
  - `data/<namespace>/dimension_type/<name>.json`
  - or a zip/folder wrapper before that path.
- Reads `min_y` + `height` from the dimension type JSON.
- Prefers dimension types referenced by `level.dat` when available.
- Otherwise prefers:
  1. `minecraft:overworld`
  2. any overworld-like type
  3. the tallest custom/non-vanilla dimension type
- Added `RegionFile` import so chunk-section fallback does not fail if datapack/level metadata is missing.

## Example verified

The uploaded sample datapack:

`worldpainter_-512_to_2032.zip`

contains:

`data/minecraft/dimension_type/overworld.json`

with:

```json
{
  "min_y": -512,
  "height": 2544,
  "logical_height": 2544
}
```

The scanner resolves this as:

`-512..2032`

because `-512 + 2544 = 2032`.

## Expected user-facing result

After opening a world with this datapack in its `datapacks` folder, the bottom status bar should show:

`World: <map name> | y -512..2032`

The paint cursor, brush clamp, selection bounds, and voxel picking should then use that full height range instead of vanilla `-64..320`.
