# WorldGeoLabs v0.16.14 — Visibility / Focus Hotfix

This hotfix fixes a blank viewport regression reported after v0.16.13.

## Problem

After datapack height detection unlocked tall worlds such as `-512..2032`, the camera focus path used the full build-height midpoint as the target Y. For that range the midpoint is Y=760, which can put the camera target far above normal terrain and make the loaded scene appear blank even though chunk meshes were built and staged.

The section-dirty pass also stopped publishing top-height data for full-column voxel meshes, which reduced the information available to terrain-aware peel/topmap view logic.

## Fix

- `GLViewport.focus_chunk()` now samples local Anvil terrain surface height and focuses near the actual surface.
- Fallback focus Y avoids tall-world midpoint and clamps a normal editing altitude inside the legal build range.
- Full-column voxel meshes once again include 16x16 top-height data. Single 16x16x16 section meshes intentionally do not publish full-column top data.
- Empty mesh uploads are logged as skipped and no longer counted as visible GPU uploads.

## Result

Opening/selecting an area in a tall world should bring the terrain back into view instead of aiming at empty sky around the build-height midpoint.
