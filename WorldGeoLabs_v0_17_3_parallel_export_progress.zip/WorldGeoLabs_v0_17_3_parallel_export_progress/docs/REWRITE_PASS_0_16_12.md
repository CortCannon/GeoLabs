# WorldGeoLabs v0.16.12 — Large Area Streaming Renderer Foundation

This pass starts the renderer rework needed for very large edit areas such as
16,384 × 16,384 blocks.

## Why this was needed

A 16,384 × 16,384 area is 1,024 × 1,024 chunks, or 1,048,576 chunks total.
The old selected-area workflow could try to keep the entire allowed edit area as
full voxel meshes. That approach cannot scale to million-chunk projects.

## New behavior

WorldGeoLabs now treats the selected area as an edit boundary, not as a command
to build every chunk at full detail.

The renderer uses a bounded working set:

- Near ring: detailed voxel meshes for editing and underground inspection.
- Surface ring: top-surface-only meshes for wider navigation context.
- Huge selected areas skip full startup voxel preloading.
- Small selected areas can still be preloaded/rendered as before.
- GL meshes outside the active streaming working set are pruned so GPU memory
  does not grow forever as the camera moves.

## New tuning

The Performance dialog now exposes:

- Near ring (voxel detail)
- Surface ring (navigation LOD)
- Huge-area streaming status
- Selected chunk count
- Full-res area limit

Environment overrides:

- `WGL_STARTUP_VOXEL_PRELOAD_LIMIT` — selected-area chunk limit for startup voxel preload. Default: `2048`.
- `WGL_RENDER_ALL_CHUNK_LIMIT` — chunk limit for keeping a whole selected area resident as voxel meshes. Default: `2048`.
- `WGL_REGION_WARMUP_FILE_LIMIT` — selected-area region-file warmup limit. Default: `512`.

## What this does not solve yet

This is the first renderer architecture step, not the final whole-world renderer.
The app still does not render a million chunks at once as actual block geometry.
The next major milestone should add a coarse overview terrain tile layer / quadtree
so the entire 16k map can be visible at very low detail while the active area
streams at high detail.
