# WorldGeoLabs v0.16.17 — X-ray Rewrite Pass 1

Focus: make terrain transparency behave like an inspection view instead of simply drawing every terrain mesh with flat alpha.

## Changes

- Added neighbor-aware voxel meshing across X/Z chunk borders.
  - This suppresses false chunk-wall faces when adjacent chunk columns are solid.
  - Transparent/x-ray views should no longer reveal every chunk as a box.
- Preserved true selection/world boundary faces with a per-chunk neighbor mask, so selected-area cut walls should remain visible instead of becoming open holes.
- Added shader-side shell-style x-ray fade.
  - Terrain near the surface envelope remains readable.
  - Deep filler terrain fades down so the volume is less muddy.
- Surface/navigation LOD meshes are drawn much fainter while x-ray is enabled.
  - This reduces the green top-tile/chunk-grid pattern seen in transparent mode.
- The existing opacity slider still works, but the selected mode now changes draw behavior:
  - Ghost terrain: broad clean shell view.
  - Deep X-ray: stronger interior fade.
  - Edit focus: lowest bulk-terrain clutter.

## Not yet included

- Full order-independent transparency.
- Dedicated ore/cavity overlay mesh.
- Cross-chunk greedy merging for surface overview tiles.
- True per-section GPU keys.

This pass is intentionally conservative: it preserves the working v0.16.16 stream visibility fix while cleaning the x-ray render path.
