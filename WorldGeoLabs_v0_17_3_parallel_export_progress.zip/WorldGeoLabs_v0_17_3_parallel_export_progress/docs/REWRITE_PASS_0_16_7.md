# WorldGeoLabs v0.16.7 — Axiom-Style Controls Pass

This pass starts moving WorldGeoLabs toward an Axiom-like editor feel, focused on viewport controls and movement rather than another risky paint-depth rewrite.

## Goals

- Make the viewport feel closer to Minecraft Axiom Editor Mode.
- Keep the existing selected-area, preview-first WorldGeoLabs workflow.
- Add a first-class controls/movement UI instead of burying shortcuts inside Paint help text.
- Add enhanced fly movement for quickly moving around large selected areas.

## Implemented

### Controls tab

Added **Scene / Preview → Controls** with:

- Input profile selector: `Axiom-style` or `Legacy WorldGeoLabs`.
- Enhanced fly movement toggle.
- Flight speed slider/spinbox with Slow / Normal / Fast presets.

### Axiom-style mouse mapping

When `Axiom-style` is active:

- `LMB drag` rotates the camera.
- `Ctrl + LMB drag` focuses/orbits around the block or brush under the cursor.
- `RMB` uses the active Paint/tool action.
- `Ctrl + RMB drag` pans.
- `MMB` picks the block under the cursor into Paint.
- `Ctrl + MMB drag` adjusts brush radius.

### Enhanced flight

The viewport can translate its camera target with editor-style movement:

- `W/S`: forward/back along view direction.
- `A/D`: strafe left/right.
- `Space`: up.
- `Shift`: down.
- Flight speed comes from the Controls tab.
- `Ctrl` temporarily slows movement; `Alt` temporarily speeds movement.

## Notes

This is a control/movement pass, not the final 3D paint placement redesign. The paint cursor still needs a deeper dedicated interaction system, but this build should make navigation, block picking, and Paint tool usage closer to Axiom before the next paint-core rewrite.
