# WorldGeoLabs v0.16.5 — Paint Cursor Unlock Hotfix

This pass fixes the regression from the previous depth-anchor attempts where the paint cursor could become stuck on one side of the selected area or locked at one depth.

## What changed

- Replaced the camera-distance free cursor with a stable horizontal Y-plane cursor.
- Mouse movement now chooses X/Z on the active paint plane.
- Shift+Wheel, `[`, `]`, PageUp, and PageDown move the active paint plane up/down through world Y.
- Visible block picking is no longer used every hover frame in free paint mode.
- The visible block under the mouse is now used only for exact surface snap or when pressing `\` to reset/reacquire the Y plane.
- Removed the extra camera-ray offset application that could double-apply depth and make the cursor appear frozen.

## Why this is safer

The old free cursor stored a distance along the current camera ray. On large/tall worlds, that ray point could fall outside the selected edit volume and then get clamped to a boundary, making the cursor feel stuck on one side. The new cursor uses a simple editing plane instead:

- pointer = X/Z
- depth/height control = Y
- explicit reset key = reacquire from visible terrain

This is less fancy, but it is much more predictable and should be easier to build on.
