# WorldGeoLabs v0.16.23 — WorldPainter wpscript Bridge

## Fix

v0.16.22 exposed the paired-source UI but required a bridge JAR that was not
included. v0.16.23 removes that practical dead end.

## New behavior

- Automatically finds WorldPainter's installed `wpscript` launcher.
- Loads `.world` files through the official WorldPainter scripting API.
- No separate custom bridge JAR is normally required.
- Extracts project/dimension metadata.
- Extracts tiled overview samples containing:
  - surface height,
  - water level,
  - WorldPainter terrain identifier.
- Extracts used-layer metadata and terrain/custom-material metadata.
- Caches the result under the Minecraft world's `.worldgeolabs` directory.
- Keeps the old custom-JAR backend only as a fallback.

## Scale

Overview extraction defaults to an 8-block sample spacing so 16,384×16,384
projects remain practical. The sample spacing is configurable through
`WGL_WORLDPAINTER_SAMPLE_STEP`.

## Still next

The following pass should consume the overview tiles as visible WorldGeoLabs
analysis layers and perform sampled height alignment against the Minecraft
Anvil surface.
