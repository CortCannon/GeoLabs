# WorldGeoLabs v0.16.21 — Cleanup + Performance Stabilization Pass

## Goal

This pass is a maintenance build after the 3D paint, x-ray, undo/redo, and incremental export milestones.  The goal is to reduce loose ends and remove unnecessary work without changing the user-facing workflow.

## Cleanup

- Removed generated `__pycache__` / `.pyc` files from the shipped zip.
- Updated package version to `0.16.21-cleanup-performance-pass`.
- Updated README status text so Apply/Export is no longer described as review-only.
- Reduced repeated StreamManager log spam for unchanged render-all, ring, and schedule settings.

## Rendering performance

- Added cached desired-streaming-set computation in `StreamManager`.
  - The previous streaming update rebuilt the full desired chunk set every tick.
  - The new cache reuses the desired set while target chunk, bounds, rings, and render-all mode are unchanged.
  - This matters for small selected areas kept fully resident and for large areas with wide surface rings.
- `set_target_chunk()` now ignores no-op target updates, avoiding unnecessary cache churn during stationary camera frames.
- Added adaptive redraw pacing in `GLViewport`.
  - Active input, painting, streaming uploads, and mesh builds keep the viewport at the target FPS.
  - Idle scenes fall back to a slower redraw heartbeat instead of constantly repainting at 60 FPS.
  - `WGL_IDLE_REDRAW_MS` can tune idle redraw rate; default is 125 ms.

## Export performance

- Incremental export now re-encodes only chunk sections that actually changed.
  - Tall worlds can have 150+ vertical sections per chunk.
  - A small ore/paint stroke should not repack every section in the column.
- Export chunk planning no longer double-pads strokes by the full brush size.
  - `_stroke_bbox()` already includes brush radius.
  - The extra full-size padding made large brushes touch many unnecessary chunks/region files.

## Notes

This pass intentionally avoids a large behavior rewrite.  It keeps v0.16.20's working export path and v0.16.18/v0.16.19's render/edit fixes intact while making the app less wasteful and cleaner to continue building on.

## Next cleanup candidates

- Move more input handling out of `GLViewport` into dedicated controllers.
- Finish true GPU/render-section keys for 16×16×16 streaming instead of chunk-column compatibility invalidation.
- Add export support for generator preview layers and heightmap recalculation.
- Split the large `main_window.py` and `gl_viewport.py` files into smaller modules.
