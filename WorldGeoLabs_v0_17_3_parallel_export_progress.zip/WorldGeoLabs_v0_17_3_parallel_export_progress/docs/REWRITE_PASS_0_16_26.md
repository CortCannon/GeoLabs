# WorldGeoLabs 0.16.26 — Minecraft Java 26.2 storage compatibility

- Added namespaced dimension storage discovery introduced in Minecraft Java 26.1 and used by 26.2.
- Overworld now resolves `dimensions/minecraft/overworld/region` before legacy `region`.
- Nether and End discovery supports both modern namespaced folders and legacy DIM-1/DIM1.
- `AnvilWorld`, world indexing, geological fingerprints, diagnostics, and incremental export all share the same dimension resolver.
- Tall-world metadata can be read from `data/minecraft/world_gen_settings.dat`, with a compatibility fallback for server layouts that placed it under the Overworld dimension.
- Legacy WorldPainter/Minecraft exports remain supported.
- Added modern-layout exporter round-trip coverage.
