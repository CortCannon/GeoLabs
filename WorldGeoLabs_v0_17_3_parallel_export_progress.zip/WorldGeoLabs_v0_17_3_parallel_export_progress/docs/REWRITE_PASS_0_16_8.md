# WorldGeoLabs v0.16.8 — Free 3D Paint Controller Pass

This pass focuses on the current main blocker: 3D painting feeling locked to a height, side, or depth.

## Implemented

### Dedicated free paint controller

Added `mcgeo/viewport/paint_controller.py` with `FreePaintController`.

The controller keeps the brush as a persistent world-space gizmo instead of deriving the edit point from a terrain hit every mouse frame.

### Removed free-mode surface re-snapping

Free paint no longer ray-picks terrain every hover frame. Terrain picking is now only used when:

- exact surface snap is enabled, or
- the free cursor needs an initial seed point, or
- the user explicitly reseeds the cursor with `\`.

This prevents normal mouse movement from silently turning the tool back into a surface painter.

### Replaced horizontal Y-plane locking

The previous free-paint path projected the cursor onto a horizontal Y plane. When the camera ray missed the selected volume, clamping could pin the cursor to one side of the edit area.

The new free cursor uses a camera-facing screen plane through the persistent cursor. v0.16.9 changes this from incremental mouse deltas to direct mouse-ray reprojection so the brush stays visually under the OS cursor after camera orbit/flight.

### True Y movement

Alt+Wheel, `[ / ]`, and PageUp/PageDown now move the persistent cursor in world Y instead of changing a hidden ray depth or surface-relative offset. Shift is reserved for Axiom-style camera descent.

### UI wording update

The Paint > Placement tab now describes the brush as a persistent free-3D gizmo, with `\` labeled as an explicit cursor reseed.

## Expected behavior

- Paint mode starts with a free 3D brush cursor.
- Mouse movement moves the cursor inside the selected volume without automatic surface snap.
- Alt+Wheel / `[ / ]` / PageUp/PageDown move the cursor up/down.
- RMB paints at the current 3D cursor in Axiom-style mode.
- Exact surface snap still exists, but only when the checkbox is enabled.

## Remaining work

This is the first controller-level rewrite pass, not the final full tool architecture. The next cleanup should continue moving input/tool ownership out of `GLViewport` and into a formal `ToolController` / input profile layer.
