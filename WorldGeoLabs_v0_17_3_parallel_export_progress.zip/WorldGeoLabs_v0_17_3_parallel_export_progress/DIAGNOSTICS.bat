@echo off
setlocal
cd /d "%~dp0"
set PY=py -3
if exist ".venv\Scripts\python.exe" set PY=".venv\Scripts\python.exe"

echo === WorldGeoLabs environment ===
%PY% -m mcgeo.diagnostics

echo.
echo === Anvil exporter round-trip (legacy + Minecraft 26.2 storage) ===
%PY% -m mcgeo.world.tests_exporter_roundtrip
if errorlevel 1 goto :fail

echo.
echo === Parallel exporter + progress test ===
%PY% -m mcgeo.world.tests_parallel_export
if errorlevel 1 goto :fail

echo.
echo === Void-border region handling test ===
%PY% -m mcgeo.world.tests_void_regions
if errorlevel 1 goto :fail

echo.
echo === Geological analysis smoke test ===
%PY% -m mcgeo.analysis.tests_analysis_smoke
if errorlevel 1 goto :fail

echo.
echo === Parallel geological analysis test ===
%PY% -m mcgeo.analysis.tests_parallel_analysis
if errorlevel 1 goto :fail

echo.
echo === Whole-world geology/resource generation test ===
%PY% -m mcgeo.geology.tests_resource_generation
if errorlevel 1 goto :fail

echo.
echo === Distant Horizons LOD read/mesh test ===
%PY% -m mcgeo.rendering.tests_distant_horizons
if errorlevel 1 goto :fail

echo.
echo === Detailed 3D work-box section test ===
%PY% -m mcgeo.rendering.tests_work_box
if errorlevel 1 goto :fail

echo.
echo Core self-tests completed successfully.
echo To test one of your real worlds, run:
echo   .venv\Scripts\python.exe -m mcgeo.diagnostics --world "C:\path\to\world"
pause
exit /b 0

:fail
echo.
echo A core self-test failed. Copy this window's output and send it to ChatGPT.
pause
exit /b 1
