@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo WorldGeoLabs has not been set up yet.
  echo Running setup first...
  call SETUP_WORLDGEOLABS.bat
  if errorlevel 1 exit /b 1
)
".venv\Scripts\python.exe" -m mcgeo
if errorlevel 1 (
  echo.
  echo WorldGeoLabs exited with an error.
  echo Run DIAGNOSTICS.bat and send the output to ChatGPT.
  pause
)
