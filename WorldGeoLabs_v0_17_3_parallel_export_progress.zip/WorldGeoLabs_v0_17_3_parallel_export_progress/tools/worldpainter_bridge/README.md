# WorldPainter Bridge

WorldGeoLabs now uses WorldPainter's own **wpscript** launcher by default.
That is preferable to a separately bundled JAR because the installed
WorldPainter runtime is the one that understands the user's `.world` format.

## Automatic detection on Windows

WorldGeoLabs checks:

```text
C:\Program Files\WorldPainter\wpscript.exe
C:\Program Files (x86)\WorldPainter\wpscript.exe
%LOCALAPPDATA%\Programs\WorldPainter\wpscript.exe
```

It also checks the system `PATH`.

For a non-standard installation, set:

```bat
set WGL_WPSCRIPT=C:\path\to\WorldPainter\wpscript.exe
```

The bundled script is:

```text
tools/worldpainter_bridge/export_worldpainter.js
```

It loads the `.world` project read-only through WorldPainter's official
scripting API and creates a cached `worldgeolabs.worldpainter.v1` package.

## Overview resolution

The default extraction spacing is one sample every 8 blocks. Override it with:

```bat
set WGL_WORLDPAINTER_SAMPLE_STEP=4
```

A value of 4 gives more detail but produces a larger cache and takes longer.

## Optional legacy JAR backend

`WGL_WORLDPAINTER_BRIDGE_JAR` is still supported as a fallback, but it is no
longer the preferred setup.
