/*
 * WorldGeoLabs WorldPainter extractor.
 *
 * Run by WorldPainter's official wpscript launcher:
 *   wpscript export_worldpainter.js input.world output_dir [sample_step]
 *
 * The script only reads the project. It does not modify or save the .world file.
 */

var File = Java.type("java.io.File");
var FileWriter = Java.type("java.io.FileWriter");
var BufferedWriter = Java.type("java.io.BufferedWriter");
var FileOutputStream = Java.type("java.io.FileOutputStream");
var BufferedOutputStream = Java.type("java.io.BufferedOutputStream");
var DataOutputStream = Java.type("java.io.DataOutputStream");
var GZIPOutputStream = Java.type("java.util.zip.GZIPOutputStream");
var LinkedHashMap = Java.type("java.util.LinkedHashMap");

function fail(message) {
    throw new Error(message);
}

function jsonEscape(value) {
    if (value === null || value === undefined) {
        return "";
    }
    var s = String(value);
    var out = "";
    for (var i = 0; i < s.length; i++) {
        var c = s.charAt(i);
        var code = s.charCodeAt(i);
        if (c === "\\") out += "\\\\";
        else if (c === "\"") out += "\\\"";
        else if (c === "\n") out += "\\n";
        else if (c === "\r") out += "\\r";
        else if (c === "\t") out += "\\t";
        else if (code < 32) {
            var hex = code.toString(16);
            while (hex.length < 4) hex = "0" + hex;
            out += "\\u" + hex;
        } else out += c;
    }
    return out;
}

function q(value) {
    return "\"" + jsonEscape(value) + "\"";
}

function writeText(file, text) {
    var parent = file.getParentFile();
    if (parent !== null) parent.mkdirs();
    var writer = new BufferedWriter(new FileWriter(file));
    try {
        writer.write(String(text));
    } finally {
        writer.close();
    }
}

function safeName(value) {
    return String(value).replace(/[^A-Za-z0-9._-]+/g, "_");
}

function anchorName(anchor, dimensionName) {
    var text = "";
    try {
        text = String(anchor.getDefaultName());
    } catch (ignored) {
        text = String(dimensionName);
    }
    var lower = (text + " " + String(dimensionName)).toLowerCase();
    if (lower.indexOf("nether") >= 0) return "minecraft:the_nether";
    if (lower.indexOf("end") >= 0) return "minecraft:the_end";
    return "minecraft:overworld";
}

function addUnique(map, key, value) {
    if (!map.containsKey(String(key))) {
        map.put(String(key), String(value));
    }
}

if (arguments.length < 2) {
    fail("Expected: input.world output_dir [sample_step]");
}

var inputFile = new File(String(arguments[0])).getAbsoluteFile();
var outputRoot = new File(String(arguments[1])).getAbsoluteFile();
var sampleStep = arguments.length >= 3 ? parseInt(String(arguments[2]), 10) : 8;
if (!inputFile.isFile()) fail("WorldPainter project not found: " + inputFile);
if (!(sampleStep >= 1 && sampleStep <= 128)) sampleStep = 8;
outputRoot.mkdirs();

print("WorldGeoLabs: loading " + inputFile);
var loadedWorld = wp.getWorld().fromFile(inputFile.getAbsolutePath()).go();
if (loadedWorld === null) fail("WorldPainter returned no world");

var worldName = String(loadedWorld.getName());
var dimensions = [];
var terrainMap = new LinkedHashMap();
var layerMap = new LinkedHashMap();

var dimIterator = loadedWorld.getDimensions().iterator();
while (dimIterator.hasNext()) {
    wp.checkForInterrupt();
    var dimension = dimIterator.next();
    var dimName = String(dimension.getName());
    var anchor = dimension.getAnchor();
    var dimId = String(anchor.toString());
    var safeDimId = safeName(dimId);
    var lowestTileX = dimension.getLowestX();
    var highestTileX = dimension.getHighestX();
    var lowestTileY = dimension.getLowestY();
    var highestTileY = dimension.getHighestY();
    var tileSize = 128;

    var overviewDir = new File(outputRoot, "overview/" + safeDimId);
    overviewDir.mkdirs();
    var tileRecords = [];

    var tileIterator = dimension.getTiles().iterator();
    var tileCounter = 0;
    while (tileIterator.hasNext()) {
        wp.checkForInterrupt();
        var tile = tileIterator.next();
        var tileX = tile.getX();
        var tileY = tile.getY();
        var relativePath = "overview/" + safeDimId + "/tile_" + tileX + "_" + tileY + ".bin.gz";
        var tileFile = new File(outputRoot, relativePath);
        var data = new DataOutputStream(
            new GZIPOutputStream(
                new BufferedOutputStream(
                    new FileOutputStream(tileFile)
                )
            )
        );
        try {
            // Header: magic/version, tile coordinates, sampling step, sample count.
            data.writeInt(0x57474C57); // WGLW
            data.writeInt(1);
            data.writeInt(tileX);
            data.writeInt(tileY);
            data.writeInt(sampleStep);
            var samplesPerAxis = Math.floor((127 / sampleStep)) + 1;
            data.writeInt(samplesPerAxis);
            for (var localY = 0; localY < 128; localY += sampleStep) {
                for (var localX = 0; localX < 128; localX += sampleStep) {
                    data.writeFloat(tile.getHeight(localX, localY));
                    data.writeInt(tile.getWaterLevel(localX, localY));
                    var terrain = tile.getTerrain(localX, localY);
                    var ordinal = terrain === null ? -1 : terrain.ordinal();
                    data.writeShort(ordinal);
                    if (terrain !== null) {
                        addUnique(terrainMap, String(ordinal), String(terrain.name()));
                    }
                }
            }
        } finally {
            data.close();
        }
        tileRecords.push(
            "{\"x\":" + tileX +
            ",\"y\":" + tileY +
            ",\"path\":" + q(relativePath) + "}"
        );

        try {
            var usedLayers = tile.getLayers().iterator();
            while (usedLayers.hasNext()) {
                var layer = usedLayers.next();
                var layerId = String(layer.getId());
                var layerJson =
                    "{\"id\":" + q(layerId) +
                    ",\"name\":" + q(layer.getName()) +
                    ",\"description\":" + q(layer.getDescription()) +
                    ",\"data_size\":" + q(layer.getDataSize()) +
                    ",\"discrete\":" + String(Boolean(layer.discrete)) +
                    ",\"priority\":" + String(layer.getPriority()) +
                    ",\"class\":" + q(layer.getClass().getName()) + "}";
                addUnique(layerMap, layerId, layerJson);
            }
        } catch (layerError) {
            // Some old/custom tile implementations may not expose every layer cleanly.
        }

        tileCounter++;
        if ((tileCounter % 128) === 0) {
            print("WorldGeoLabs: extracted " + tileCounter + " tiles from " + dimName);
        }
    }

    var indexJson =
        "{\n" +
        "  \"schema\": \"worldgeolabs.worldpainter.overview.v1\",\n" +
        "  \"dimension_id\": " + q(dimId) + ",\n" +
        "  \"sample_step\": " + sampleStep + ",\n" +
        "  \"record\": [\"height_f32\", \"water_i32\", \"terrain_i16\"],\n" +
        "  \"tiles\": [" + tileRecords.join(",") + "]\n" +
        "}\n";
    var indexRelative = "overview/" + safeDimId + "/index.json";
    writeText(new File(outputRoot, indexRelative), indexJson);

    var datasets =
        "{\"overview\":" + q(indexRelative) +
        ",\"height\":\"" + jsonEscape(indexRelative) +
        "\",\"water\":\"" + jsonEscape(indexRelative) +
        "\",\"terrain\":\"" + jsonEscape(indexRelative) + "\"}";

    var roleText = "";
    var invert = false;
    var anchorDim = 0;
    var anchorId = 0;
    try { roleText = String(anchor.role); } catch (ignoredRole) {}
    try { invert = Boolean(anchor.invert); } catch (ignoredInvert) {}
    try { anchorDim = Number(anchor.dim); } catch (ignoredDim) {}
    try { anchorId = Number(anchor.id); } catch (ignoredId) {}

    dimensions.push(
        "{" +
        "\"id\":" + q(dimId) +
        ",\"name\":" + q(dimName) +
        ",\"anchor\":" + q(anchorName(anchor, dimName)) +
        ",\"min_y\":" + dimension.getMinHeight() +
        ",\"max_y\":" + dimension.getMaxHeight() +
        ",\"origin_x\":" + (lowestTileX * tileSize) +
        ",\"origin_z\":" + (lowestTileY * tileSize) +
        ",\"tile_size_blocks\":" + tileSize +
        ",\"bounds_blocks\":[" +
            (lowestTileX * tileSize) + "," +
            (((highestTileX + 1) * tileSize) - 1) + "," +
            (lowestTileY * tileSize) + "," +
            (((highestTileY + 1) * tileSize) - 1) +
        "]" +
        ",\"datasets\":" + datasets +
        ",\"metadata\":{" +
            "\"anchor_role\":" + q(roleText) +
            ",\"anchor_dimension\":" + anchorDim +
            ",\"anchor_id\":" + anchorId +
            ",\"inverted\":" + String(invert) +
            ",\"tile_count\":" + dimension.getTileCount() +
        "}" +
        "}"
    );
}

var version = "installed";
try {
    var metadata = loadedWorld.getMetadata();
    if (metadata !== null) {
        var value = metadata.get("org.pepsoft.worldpainter.version");
        if (value !== null) version = String(value);
    }
} catch (metadataError) {}

var worldInfo =
    "{\n" +
    "  \"schema\": \"worldgeolabs.worldpainter.v1\",\n" +
    "  \"project_name\": " + q(worldName) + ",\n" +
    "  \"worldpainter_version\": " + q(version) + ",\n" +
    "  \"dimensions\": [" + dimensions.join(",") + "],\n" +
    "  \"metadata\": {" +
        "\"source_file\":" + q(inputFile.getAbsolutePath()) +
        ",\"extractor\":\"WorldPainter wpscript\"" +
        ",\"sample_step\":" + sampleStep +
    "}\n" +
    "}\n";
writeText(new File(outputRoot, "world_info.json"), worldInfo);

var terrainEntries = [];
var terrainValues = terrainMap.values().iterator();
var terrainKeys = terrainMap.keySet().iterator();
while (terrainKeys.hasNext() && terrainValues.hasNext()) {
    var terrainKey = terrainKeys.next();
    var terrainName = terrainValues.next();
    terrainEntries.push("{\"ordinal\":" + terrainKey + ",\"name\":" + q(terrainName) + "}");
}

var mixedEntries = [];
for (var mixedIndex = 0; mixedIndex < 96; mixedIndex++) {
    try {
        var mixed = loadedWorld.getMixedMaterial(mixedIndex);
        if (mixed !== null) {
            mixedEntries.push(
                "{\"slot\":" + (mixedIndex + 1) +
                ",\"name\":" + q(String(mixed.getName())) +
                ",\"description\":" + q(String(mixed)) + "}"
            );
        }
    } catch (mixedError) {}
}
writeText(
    new File(outputRoot, "materials.json"),
    "{\"terrains\":[" + terrainEntries.join(",") + "],\"custom_materials\":[" + mixedEntries.join(",") + "]}\n"
);

var layerEntries = [];
var layerValues = layerMap.values().iterator();
while (layerValues.hasNext()) layerEntries.push(String(layerValues.next()));
writeText(
    new File(outputRoot, "layers.json"),
    "{\"layers\":[" + layerEntries.join(",") + "]}\n"
);

print("WorldGeoLabs: created analysis package at " + outputRoot);
