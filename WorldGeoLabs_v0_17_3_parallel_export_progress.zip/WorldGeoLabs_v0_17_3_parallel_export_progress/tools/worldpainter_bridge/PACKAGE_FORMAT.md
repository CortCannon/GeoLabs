# `worldgeolabs.worldpainter.v1`

Minimum `world_info.json`:

```json
{
  "schema": "worldgeolabs.worldpainter.v1",
  "project_name": "Example Map",
  "worldpainter_version": "unknown",
  "dimensions": [
    {
      "id": "surface",
      "name": "Surface",
      "anchor": "minecraft:overworld",
      "min_y": -512,
      "max_y": 2032,
      "origin_x": 0,
      "origin_z": 0,
      "tile_size_blocks": 128,
      "bounds_blocks": [0, 16383, 0, 16383],
      "datasets": {
        "height": "height_tiles/index.json",
        "water": "water_tiles/index.json",
        "terrain": "terrain_tiles/index.json",
        "biomes": "biome_tiles/index.json",
        "layers": "layer_tiles/index.json"
      }
    }
  ]
}
```

Dataset paths are intentionally opaque to the Python UI at this stage. The
next analysis pass will add tiled raster readers and a disk-backed cache.
