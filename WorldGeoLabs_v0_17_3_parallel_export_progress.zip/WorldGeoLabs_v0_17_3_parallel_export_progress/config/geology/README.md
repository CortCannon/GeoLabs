# Geological configuration

WorldGeoLabs now separates two editable geology profiles:

- `minecraft_26_2_block_categories.toml` — maps Minecraft blocks to interpreted rock/material categories.
- `world_geology_profile.toml` — controls whole-world structural interpretation, deposit formation rules, resource population, size, depth, host blocks, and suitability weights.

The resource file is intentionally data-driven. Any `[deposits.<name>]` section can use a vanilla or modded block ID as its material. Multiple deposit definitions may use the same block to represent different formation processes (for example hydrothermal gold and placer gold).

Terrain-history fields available to deposit weights include:

- `uplift`, `basin`, `erosion`, `fracture`, `hydrothermal`
- `paleo_organic`, `placer`, `orogenic`, `stable_craton`
- `elevation`, `slope`, `low_slope`, `lowland`, `flow`, `base`

Positive weights favor high values. Negative weights favor low values. For example `orogenic = -0.5` discourages a deposit in strongly deformed mountain belts.

Supported generated shapes:

- `seam` — broad folded sedimentary layers
- `vein` — structurally controlled linear mineralization
- `stockwork` — several crossing vein families
- `pipe` — vertical mantle/intrusive body with sparse mineralization
- `placer` — shallow deposits traced downstream using analyzed flow direction
- `lens` — irregular elongated lenses
- `blob` — generic irregular body

`replace_only` is an important safety control. Geological export only replaces those Minecraft host blocks for that deposit when the list is non-empty.

## Rebuild behavior

Changing deposit population, size, depth, host blocks, materials, or suitability weights only requires **Generate Geological Resources** again.

Changing `[structure]` values (fold wavelength/amplitude, fault spacing/width, terrain smoothing, slope reference) changes the structural analysis fields themselves. After changing those settings, run **Geological Analysis** again with **Force rebuild** before regenerating resources.
